# Axiom Indexer 2.5.0 RC5

This record declares the exact coordinated candidate. It does not assert
publication, Product acceptance or consumer adoption by its own existence.

| Coordinate | Value |
|---|---|
| release version | `2.5.0-rc.5` |
| product-local cut | `v2.5.0-rc.5` |
| Project Release Namespace | `axiom_indexer` |
| Project Subtree root | `axiom_indexer` |
| qualified immutable tag ref | `refs/tags/axiom_indexer/v2.5.0-rc.5` |
| qualified version-line selector | `refs/tags/axiom_indexer/v2.5.0` |
| qualified RC branch | `refs/heads/rc/axiom_indexer/2.5.0` |
| qualified release branch | `refs/heads/release/axiom_indexer/2.5.0` |
| matched Source STDO cut | `refs/tags/specification_methodology/v2.5.0-rc.5` |
| public Source STDO basis | `stdo://releases/v2.5.0-rc.5/` |

## Exact Source STDO

The matched source is commit `c7888bb2dc9aee1f5a217985f6d1547cfe6465f0`, annotated tag object
`d4b7c7724944e02ce25c6e6ce69722491c349924`, repository tree `cb87e3e0bfaf033ee3cfa6b260d0d9ead0312b08`, STDO subtree tree
`40dc632ee5185b2b29cfce43ef8b06f223ea27ea`, standards tree `b04dee86bd8d4f272d215801257ddd7ae5d5d782`.
Its installed manifest is `3fb89aeb80c65403debf1eba1705fde614556520bf1ce1a08a39033b6d98a50f`;
52 standards members have aggregate
`22c3fb78e2c6817b080986c9f265237429043a2af2ff4769b12eed5a499d11eb`. The child tag object, carrier commit
and subtree identity are frozen externally by the release qualification;
this note cannot self-embed those future identities.

## Exact Product Inventory

Exactly 7 entries. File digests cover bytes;
symlink digests cover their UTF-8 targets without a terminal newline. The
aggregate sorts paths and emits SHA-256, two spaces, type, two spaces, path,
newline: `41350ccf7b10173f36cab011cb85e9c0b552c9af6d6efe2f2f2782125df00c19`.

| Type | Member | SHA-256 |
|---|---|---|
| symlink | `.agents/skills/axiomatize-corpus` -> `../../skills/axiomatize-corpus` | `94f7720145baa135bb3d88ec352b4fe32e9841fcfc9a23dbf00ea54ab0fa7c40` |
| symlink | `.claude/skills/axiomatize-corpus` -> `../../skills/axiomatize-corpus` | `94f7720145baa135bb3d88ec352b4fe32e9841fcfc9a23dbf00ea54ab0fa7c40` |
| file | `build_tenants/core/code/ac.py` | `87c43389c619d9ca0e2d930a10e471a17545be9a0394d1c0f47db7e8e2c6d931` |
| file | `skills/axiomatize-corpus/SKILL.md` | `0b9443403d8d8ee56aad5ec1059d288dc2666c247191bb92b18258bc2758894d` |
| file | `skills/axiomatize-corpus/agents/openai.yaml` | `409721119552f3e1ffded2a2aed5f81a92b40389c81f77c0792f305e507be990` |
| file | `skills/axiomatize-corpus/references/output-contract.md` | `c124264d1fc564a8a054bba46b5c188c4e770da51862b4c2122e3c616efb1b6b` |
| file | `skills/axiomatize-corpus/references/program.schema.json` | `43326dbab520bd2d56fbdf605211f66499de1969b13e2e0226868bd6af9777a7` |

Authority documents, release metadata, bindings and proof remain external to
this Product member set. Installation retains the exact external dependency
and cohort records needed to verify these members; it does not copy a mutable
checkout as Product truth.

## Selected Claims And Predecessor Dispositions

The immediate published predecessor is `axiom_indexer/v2.5.0-rc.4`, tag
`4750e09639c118f1097d4ea046fe23d26713f96b`, commit
`a953ad4634fbfaefb8bdffaccdf4eff651a1e3a2`. Its exact record remains at that tag;
the accepted v0.1.0 RC1 baseline and its acceptance remain unchanged history.

- `AXIOM-2.5-RC5-C01`: explicitly authored frame indexes select declared
  dependency closure; both views preserve identities, qualifications,
  residual uncertainty and source routes, with unchanged materialized content.
- `AXIOM-2.5-RC5-C02`: missing, stale, ambiguous or aliased inputs produce
  deterministic diagnostics without unsafe output effects.
- `AXIOM-2.5-RC5-C03`: original resolution, validation and exact text joining
  remain available; no semantic inference, applicability decision or executor
  is introduced.
- `AXIOM-2.5-RC5-C04`: exact RC5 mechanics and native authoring contracts form
  the separately owned dependency consumed by STDO Representation RC5.

RC4 C01 and C05 are **conserved**, with the successor's exact suffix. C02's
seven-member byte-conservation claim is **superseded** by the selected new
projection capability and the inventory above. C03/C04 retain their bounded
original behavior and are **superseded** only for the explicitly added optional
frame-index authoring/projection interface. RC1's earlier functional claims,
pure-join law and exclusions remain **conserved** through those relations.

The exact mechanics passed 31 normal and 31 optimized regression cases and
independent assessment in `dogfood/t009-frame-projection/run-002/`. Release
qualification rechecks member conservation and the installed consumer path;
test counts supply no semantic qualification. No complete admitted M_b, GTL,
automatic frame selection, semantic acceptance, prompt orchestration or runtime
is claimed. No new open-source licence is selected by this release.

Publication follows the exact shared cohort content/ref/remote gates.
Product acceptance remains a separate exact-cut owner judgment.
