## UAT-02-C — Inspect Before A Candidate Exists

Initial state: P0's helper/owner declarations and Public baseline are present.
There are no candidate helper bytes or applicable candidate projection.
The supplied access record is diagnostic-only; EH is absent.

Task: "The export helper needs tidying. What can you establish now?"

Access and effects: inspect declarations and available evidence. No source
edit, projection-generating construction or operation is granted.

Return: known facts, unresolved facts, their effect on the requested work and
the smallest useful resolving input. Do not manufacture candidate bytes.
