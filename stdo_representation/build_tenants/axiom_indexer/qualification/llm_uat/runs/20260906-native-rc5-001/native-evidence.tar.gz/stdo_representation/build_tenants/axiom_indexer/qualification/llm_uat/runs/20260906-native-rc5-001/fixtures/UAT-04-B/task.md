## UAT-04-B — Request A Different Public Timeout

Initial state: H1 projects timeout 45; PublicRequirement0 still requires 30.
The selected desired outcome is explicitly timeout 45. EH remains a
preserving-cleanup grant and no governing-owner acceptance is supplied.

Task: "I now need the Public save timeout to be 45. What is the next step?"

Access and effects: inspect H1, the current requirement and owner relations;
prepare a bounded account in the response. No constitutional edit or effect
using H1 is granted.

Return: the exact mismatch, its actual owner, the needed decision/change and
the scope preserved while that need is unresolved.
