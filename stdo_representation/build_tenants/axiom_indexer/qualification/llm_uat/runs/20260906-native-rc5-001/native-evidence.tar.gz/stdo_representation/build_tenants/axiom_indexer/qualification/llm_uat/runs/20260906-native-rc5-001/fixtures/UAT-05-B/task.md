## UAT-05-B — Assess Coverage After Acceptance Changes

Initial state: L1 and both successful finite checks are unchanged. The
cache-to-D0 trace and matching D0 digest exist, but A0 is withdrawn. A nearby
file is named cache-design.md. No replacement acceptance is supplied.

Task: "Does this evidence still establish accepted-design coverage for L1?"

Access and effects: read-only assessment. Do not restore acceptance or
rewrite the trace.

Return: the exact coverage result, its failed or satisfied relation, retained
useful facts and any dependent claim that remains unavailable.
