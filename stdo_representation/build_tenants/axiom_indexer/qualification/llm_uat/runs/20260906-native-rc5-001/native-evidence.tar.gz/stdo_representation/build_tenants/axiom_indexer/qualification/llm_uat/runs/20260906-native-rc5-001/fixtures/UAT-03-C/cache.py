def remove_last(entries):
    items = list(entries)
    items.pop()
    count = max(1, len(items))
    return items, count
