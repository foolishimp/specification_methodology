## UAT-06-C — Resume After Design Acceptance Is Withdrawn

Initial state: an interrupted L1 work record retains valid finite observations
and unchanged Public values. Since that record, A0 is withdrawn; the
candidate and trace bytes are unchanged. The earlier local classification
depends on current A0. Unrelated diagnostic Q7 evidence is unchanged.

Task: "Resume the cache job from its current owning record."

Access and effects: inspect current acceptance, retained results and
dependencies. No replacement acceptance, further repair or closure mutation
is granted.

Return: reusable facts, affected stale conclusions, preserved unrelated work
and the actual condition needed to continue.
