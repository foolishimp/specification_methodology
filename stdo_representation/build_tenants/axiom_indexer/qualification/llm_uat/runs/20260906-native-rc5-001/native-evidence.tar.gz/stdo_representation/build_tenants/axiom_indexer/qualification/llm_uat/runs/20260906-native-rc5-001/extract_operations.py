"""Exact raw-line-linked operation projection; supplies no semantic grading."""
from pathlib import Path
import hashlib,json
H=Path(__file__).resolve().parent
out=H/'operation-projections';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
index=[]
for manifest in sorted(H.glob('completed-increment-*.json')):
 for c in json.loads(manifest.read_text())['contexts']:
  target=out/(c['name']+'.json')
  if target.exists():continue
  d=Path(c['directory']);raw=d/'stdout.jsonl';operations=[];pending={}
  for number,line in enumerate(raw.read_text().splitlines(),1):
   try:r=json.loads(line)
   except ValueError:continue
   if c['host']=='codex':
    i=r.get('item',{});kind=i.get('type')
    if r.get('type')=='item.completed' and kind not in (None,'reasoning','agent_message'):
     value=dict(i);text=value.pop('aggregated_output',None)
     if text is not None:value.update(output_sha256=sha(text.encode()),output_characters=len(text),output_excerpt=text if len(text)<=1600 else text[:1100]+'\n[excerpt; full result at raw line]\n'+text[-500:])
     operations.append({'raw_line':number,'event':value})
   else:
    message=r.get('message',{})
    if not isinstance(message,dict):continue
    content=message.get('content',[])
    if not isinstance(content,list):continue
    for item in content:
     if not isinstance(item,dict):continue
     if item.get('type')=='tool_use':
      op={'tool_use_raw_line':number,'id':item.get('id'),'name':item.get('name'),'input':item.get('input')};operations.append(op);pending[item.get('id')]=op
     elif item.get('type')=='tool_result':
      op=pending.get(item.get('tool_use_id'))
      if op is None:op={'id':item.get('tool_use_id')};operations.append(op)
      text=item.get('content');text=text if isinstance(text,str) else json.dumps(text)
      op.update(tool_result_raw_line=number,is_error=item.get('is_error',False),output_sha256=sha(text.encode()),output_characters=len(text),output_excerpt=text if len(text)<=1600 else text[:1100]+'\n[excerpt; full result at raw line]\n'+text[-500:])
  value={'context':c['name'],'raw_file':str(raw),'raw_sha256':sha(raw.read_bytes()),'kind':'Mechanical exact-command and raw-line projection; no source or semantic verdict','operations':operations,'snapshot_changes':json.loads((d/'execution-result.json').read_text())['snapshot_changes']}
  target.write_text(json.dumps(value,indent=2)+'\n');index.append({'context':c['name'],'path':str(target),'sha256':sha(target.read_bytes()),'operations':len(operations)})
n=len(list(out.glob('manifest-*.json')))+1;p=out/f'manifest-{n:03d}.json';all_files={q.name:sha(q.read_bytes()) for q in out.glob('*.json') if not q.name.startswith('manifest-')};p.write_text(json.dumps({'new_projections':index,'all_projection_files':all_files},indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p.read_bytes()),'count':len(all_files)}))
