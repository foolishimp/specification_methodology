## UAT-01-A — Start In The Selected Project

Initial state: P0 is explicitly selected. Its definition, current exact basis,
accepted frame basis, WHAT/HOW owners, local work carrier, native skill and
source/map/tool bindings are present and consistent. An unrelated project and
its dirty file are visible only as out-of-scope sentinel metadata. P0 already
has usable setup; no installation is pending.

Task: "Start with P0. I want to fix the cache count next. Show me the context
we are using and the first action available for that work."

Access and effects: inspect the selected context and local work contract.
Do not edit, install, adopt, or repair the cache yet.

Return: a compact usable-context account with concrete owner/source routes,
readiness, the permitted next action and supporting tool evidence.
