## UAT-03-A — Finish The Granted Cache Repair

Initial state: P0 still runs recount_before_delete; L1 does not exist yet.
The local one-run refresh repair grant, D0/A0, full Public projection procedure
and both admitted deletion inputs are available. The contract has no surviving
obligation, reserved ruling or independent-assessment condition.

Task: "Finish the cache-count repair under this run's contract and tell me
when the bounded job is done."

Access and effects: construct and apply the refresh-cell candidate in the
isolated P0 copy, perform focused checks, and update only this run's existing
result carrier.

Return: exact candidate and before/after observations, fulfillment of the
admitted conditions, and any unresolved condition.
