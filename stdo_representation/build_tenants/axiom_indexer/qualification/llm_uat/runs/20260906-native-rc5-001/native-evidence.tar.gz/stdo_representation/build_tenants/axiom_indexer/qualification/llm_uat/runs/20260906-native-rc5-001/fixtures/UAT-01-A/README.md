# P0 worksite

Read task.md and access.json for this request. Fixture owner records are under governing/, retained evidence under evidence/ and the current work carrier under records/. tools/domain_tool.py exposes the owner's cache, Public, root, validation, effect and syntax observations; use only the checks granted for this task. Native method/tool access is bound separately in native-context.json.
