## UAT-07-A — Combine Applicable Evaluations

Initial state: G1/B1 and the exact sandbox root-change grant are bound.
The Public result is satisfied. FR0 has a capable author-independent
satisfied result naming exactly G1/B1. Its declaration, predicate and
dependency joins are supplied. All other applicable conditions are satisfied.

Task: "Combine the evaluations for this selected root change and tell me
whether its declared conditions are satisfied. Prepare a bounded read-only
handoff request so a fresh consumer can recover this exact result."

Access and effects: Executive evaluation reads/checks existing results
without candidate effects. A separately declared request-Writer activation
permits only sandbox handoff/sections.json and handoff/request.txt, containing
caller-authored sections and the exact native join output. Do not invoke the
recipient, change the root or create another assessment.

Return: the applicable conjunction, exact result identities, material
constraints, any remaining condition and those two exact handoff artifacts.
