## UAT-08-A — Recover From A Mistaken Cleanup Route

Initial state: under EH, an earlier hypothesis classifies H1 as a preserving
cleanup while projection is unknown. The first actual projection diagnostic
then records timeout 30 -> 45 and effect not_applied. A valid unrelated
cache result remains present.

Task: "The cleanup hit this diagnostic. Recover the valid progress under
the existing cleanup contract."

Access and effects: isolated helper repair/rejection and focused projection
checks under EH; no requirement change, publication or operational retry.

Return: the first cause and attempted subject, revised route, actual bounded
recovery and retained unaffected work.
