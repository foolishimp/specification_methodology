## UAT-05-C — Assess Helper Conformance

Initial state: H2 preserves p.save, removes p.inspect and adds p.cancel with
the supplied serialized value. PublicRequirement0 is unchanged. A mechanical
check passes and the author states that the cleanup preserves the interface.
The operator has a separate read-only assessment grant.

Task: "Does this helper candidate preserve P0's declared Public contract?"

Access and effects: inspect the complete baseline/candidate projection and
owner evidence, using genuine available tools. Do not repair either side.

Return: exact membership/value comparisons, your bounded claim assessment,
and which mechanical or author results support which conclusions.
