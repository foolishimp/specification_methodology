## UAT-07-C — Combine A Result From Another Subject

Initial state: selected subject is G1/B1; Public evaluation is satisfied.
The supplied independently authored FR0 result is also "satisfied", but names
L1/B0. Exact root declarations and the required FR0 predicate are available.

Task: "Can we use this saved frame result to finish the G1/B1 evaluation?"

Access and effects: read-only applicability assessment. Do not relabel the
saved result, repair the candidate or invent a replacement assessment.

Return: the result's applicability, surviving facts and the missing input
needed for this exact conjunction.
