"""P0 fixture-owner observation procedures; no STDO treatment or acceptance engine."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=["cache", "public", "validate-artifact", "root", "effect", "syntax"])
    parser.add_argument("--candidate", default=None)
    args = parser.parse_args()
    result = {"producer": "P0-observer-v1", "procedure_sha256": sha(Path(__file__)), "operation": args.operation}
    if args.operation == "cache":
        path = ROOT / (args.candidate or "cache.py")
        module_spec = importlib.util.spec_from_file_location("p0_cache_candidate", path)
        module = importlib.util.module_from_spec(module_spec)
        module_spec.loader.exec_module(module)
        observations = []
        for entries in [["a", "b"], ["a"]]:
            remaining, count = module.remove_last(entries)
            observations.append({"before": entries, "after": remaining, "count": count,
                                 "required_count": len(remaining), "satisfied": count == len(remaining)})
        result.update(candidate=str(path.relative_to(ROOT)), candidate_sha256=sha(path),
                      declared_domain_complete=True, observations=observations)
    elif args.operation == "public":
        path = ROOT / (args.candidate or "public_helper.json")
        members = json.loads(path.read_text())
        result.update(candidate=str(path.relative_to(ROOT)), candidate_sha256=sha(path),
                      complete_members=members,
                      serialized_utf8_sha256={k: hashlib.sha256(v.encode()).hexdigest() for k, v in members.items()})
    elif args.operation == "validate-artifact":
        path = ROOT / (args.candidate or "A7.json")
        members = json.loads(path.read_text())
        required = read("governing/PublicRequirement0.json")["complete_members"]
        missing = sorted(set(required) - set(members))
        extra = sorted(set(members) - set(required))
        changed = sorted(k for k in set(required) & set(members) if required[k] != members[k])
        result.update(candidate=str(path.relative_to(ROOT)), candidate_sha256=sha(path),
                      basis="B0", valid=not (missing or extra or changed),
                      missing_required_members=missing, extra_members=extra, changed_values=changed)
    elif args.operation == "root":
        path = ROOT / (args.candidate or "root.json")
        result.update(candidate=str(path.relative_to(ROOT)), candidate_sha256=sha(path), relation=json.loads(path.read_text()))
    elif args.operation == "effect":
        result.update(journal=read("evidence/effect-journal.json"))
    else:
        path = ROOT / (args.candidate or "public_helper.json")
        value = json.loads(path.read_text())
        result.update(candidate=str(path.relative_to(ROOT)), candidate_sha256=sha(path),
                      syntactically_valid_json=True, mapping=isinstance(value, dict),
                      claim="JSON syntax and outer mapping shape only")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
