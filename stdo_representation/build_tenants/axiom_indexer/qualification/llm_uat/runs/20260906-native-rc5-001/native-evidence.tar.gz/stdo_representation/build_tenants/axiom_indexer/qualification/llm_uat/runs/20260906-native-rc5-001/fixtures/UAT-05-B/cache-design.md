# Location only

The accepted design owner record is governing/D0.json; current acceptance is governed by governing/A0.json.
