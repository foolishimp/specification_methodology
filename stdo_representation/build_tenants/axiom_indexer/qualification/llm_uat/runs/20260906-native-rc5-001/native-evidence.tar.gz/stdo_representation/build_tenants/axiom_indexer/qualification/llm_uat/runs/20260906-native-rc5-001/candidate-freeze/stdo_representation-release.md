# STDO Representation 2.5.0 RC5

This record declares the exact coordinated candidate. It does not assert
publication, Product acceptance or consumer adoption by its own existence.

| Coordinate | Value |
|---|---|
| release version | `2.5.0-rc.5` |
| product-local cut | `v2.5.0-rc.5` |
| Project Release Namespace | `stdo_representation` |
| Project Subtree root | `stdo_representation` |
| qualified immutable tag ref | `refs/tags/stdo_representation/v2.5.0-rc.5` |
| qualified version-line selector | `refs/tags/stdo_representation/v2.5.0` |
| qualified RC branch | `refs/heads/rc/stdo_representation/2.5.0` |
| qualified release branch | `refs/heads/release/stdo_representation/2.5.0` |
| matched Source STDO ref | `refs/tags/specification_methodology/v2.5.0-rc.5` |
| public Source STDO basis | `stdo://releases/v2.5.0-rc.5/` |

## Exact Source STDO

The matched source is commit `c7888bb2dc9aee1f5a217985f6d1547cfe6465f0`, annotated tag object
`d4b7c7724944e02ce25c6e6ce69722491c349924`, repository tree `cb87e3e0bfaf033ee3cfa6b260d0d9ead0312b08`, STDO subtree tree
`40dc632ee5185b2b29cfce43ef8b06f223ea27ea`, standards tree `b04dee86bd8d4f272d215801257ddd7ae5d5d782`.
Its installed manifest is `3fb89aeb80c65403debf1eba1705fde614556520bf1ce1a08a39033b6d98a50f`;
52 standards members have aggregate
`22c3fb78e2c6817b080986c9f265237429043a2af2ff4769b12eed5a499d11eb`. The child tag object, carrier commit
and subtree identity are frozen externally by the release qualification;
this note cannot self-embed those future identities.

## Exact Product Inventory

Exactly 9 entries. File digests cover bytes;
symlink digests cover their UTF-8 targets without a terminal newline. The
aggregate sorts paths and emits SHA-256, two spaces, type, two spaces, path,
newline: `5a73c04c7f704d3ce9dc051ba1214bf4a177305daf59eb4800b51429853ac1e2`.

| Type | Member | SHA-256 |
|---|---|---|
| symlink | `.agents/skills/stdo-representation` -> `../../skills/stdo-representation` | `92c6b8eb455f6bd656501d9496179af39f331ebf5df7114ee5e53825d91a6ddb` |
| symlink | `.claude/skills/stdo-representation` -> `../../skills/stdo-representation` | `92c6b8eb455f6bd656501d9496179af39f331ebf5df7114ee5e53825d91a6ddb` |
| file | `build_tenants/axiom_indexer/representation/stdo-v2.5.0-rc.5/axiomatic-program.json` | `933f72d9f6c13969b3705d69ea555e713120fa3d7abef6b90629b4a91ca0fb74` |
| file | `build_tenants/axiom_indexer/representation/stdo-v2.5.0-rc.5/logical-constraint-map.json` | `b0f23d81162ce06bdf93bdc15799384b7c6cb9d16aad76ba28855772a2993e39` |
| file | `skills/stdo-representation/SKILL.md` | `79d9c2e0ce9d02435c755b9a598da66ef8f0c0937a72ac4bb481b4729ca8f86f` |
| file | `skills/stdo-representation/agents/openai.yaml` | `872aabc6e15b66dfcfe0f2d8c674a9d25511a94d74be781711304bc581619f5a` |
| file | `skills/stdo-representation/references/claude.md` | `584189012cb0c414392e381969a9b02eda2c3cae826cd310218d92a1a3212c20` |
| file | `skills/stdo-representation/references/codex.md` | `4ddbe37bda55a3c8f9e8545f391a906754067ffc49d2d6f0299eae2d41559497` |
| file | `skills/stdo-representation/references/frame-index-use.md` | `236c728b9ee1749f1b758f6ea5bb82de037737d0281c6979bd19eea7bcc203c6` |

Authority documents, release metadata, bindings and proof remain external to
this Product member set. Installation retains the exact external dependency
and cohort records needed to verify these members; it does not copy a mutable
checkout as Product truth.

## Exact Dependency And Generated Assets

| exact Axiom dependency | `refs/tags/axiom_indexer/v2.5.0-rc.5` |

Axiom version `2.5.0-rc.5`, 7 members,
aggregate `41350ccf7b10173f36cab011cb85e9c0b552c9af6d6efe2f2f2782125df00c19`. Its exact external
release record `axiom_indexer/releases/v2.5.0.md` has SHA-256
`1a7f439a0a19172c1b8cecf05aaa6d6b796fa21146c65ebe0202cbfefb70c883`.

| Role | Axiom member | SHA-256 |
|---|---|---|
| executable | `build_tenants/core/code/ac.py` | `87c43389c619d9ca0e2d930a10e471a17545be9a0394d1c0f47db7e8e2c6d931` |
| output_contract | `skills/axiomatize-corpus/references/output-contract.md` | `c124264d1fc564a8a054bba46b5c188c4e770da51862b4c2122e3c616efb1b6b` |
| schema | `skills/axiomatize-corpus/references/program.schema.json` | `43326dbab520bd2d56fbdf605211f66499de1969b13e2e0226868bd6af9777a7` |

| Representation artifact / external source evidence | SHA-256 |
|---|---|
| `build_tenants/axiom_indexer/representation/stdo-v2.5.0-rc.5/source-corpus.json` | `bd37ab41762017d96121439397d9bff6912eda5b84257873b9915f087f4d3342` |
| `build_tenants/axiom_indexer/representation/stdo-v2.5.0-rc.5/axiomatic-program.json` | `933f72d9f6c13969b3705d69ea555e713120fa3d7abef6b90629b4a91ca0fb74` |
| `build_tenants/axiom_indexer/representation/stdo-v2.5.0-rc.5/logical-constraint-map.json` | `b0f23d81162ce06bdf93bdc15799384b7c6cb9d16aad76ba28855772a2993e39` |
| `build_tenants/axiom_indexer/representation/stdo-v2.5.0-rc.5/validation-report.json` | `df48bdd227a45629de544042937e219163a0f17131961ddc0c7508b03e42850f` |

## Selected Claims And Predecessor Dispositions

The immediate published predecessor is `stdo_representation/v2.5.0-rc.4`,
tag `d85d25482f9d9132147bea189b0fe0aca1929dff`, commit
`a953ad4634fbfaefb8bdffaccdf4eff651a1e3a2`. Its record and the accepted
Representation RC1 baseline remain at their immutable identities.

- `STDO-REP-2.5-RC5-C01`: one LLM-authored source-linked program represents
  the selected RC5 source, preserving uncertainty and exact source re-entry.
- `STDO-REP-2.5-RC5-C02`: the exact Axiom dependency reproduces the map and
  both projection views over two overlapping explicitly authored update frames,
  retaining supporting premises, conditions, exceptions and residuals.
- `STDO-REP-2.5-RC5-C03`: the complete nine-member native package gives Codex
  and Claude the selected skill/host instructions, source and projection routes;
  actual bounded use is judged by retained source-grounded native observations.
- `STDO-REP-2.5-RC5-C04`: the same-version cohort binds every source member,
  Product member and external identity required by the installed native path.

RC4 C01, C03 and C06 are **conserved** for the exact successor. C02's RC4
compression is **superseded** by the RC5-grounded authored program. C04's
historical RC3-to-RC4 delta is **superseded** by the complete RC4-to-RC5 source
inventory and recorded source comparison. C05's native interface persists and
is **superseded** only by the declared frame-index guide and successor routes.
The accepted RC1 claim dispositions and semantic/runtime exclusions remain
**conserved** through those explicit successor relations.

## Qualification Boundary

The 97-statement authored program, 23 supporting links and two frame indexes
were independently compared with all 52 source files through T009. RC5
construction only replaces the source URI prefix and program identity; its
inverse transformation equals the reviewed authored predecessor. Exact-source
validation and all six views reproduce with the unchanged qualified mechanic.

Independent original-source oracles are frozen before the parallel native UAT.
The final result records each exact host, treatment, observed effect and
disposition, including failed predecessors and unavailable preparations.
Historical Claude FP04 overreach and its limited support remain observations;
a newer run never erases them. No universal LLM reliability, token/time budget,
automatic classification, source semantics, owner ruling or executor is claimed
by the indexing mechanics. UAT and installed E2E remain distinct evidence.

The exact candidate verdict and publication records remain outside these
self-reference-sensitive release bytes. Required source, native, installed,
member and remote gates must hold before the selected atomic publication.
Product acceptance and real consumer/fleet adoption remain separate.
