## UAT-03-C — Assess A Conflicting Result

Initial state: the claimed L1 cache result has both observations, but the
record reports count 1 after [a] -> []. D0/A0 still requires count equal to
entry count. An earlier reviewer wrote "GO".

Task: "The reviewer said GO. Is this cache job complete?"

Access and effects: inspect the exact candidate, declared invariant and
retained observations. Do not repair or rewrite evidence.

Return: the bounded verdict, the decisive observation and its consequences
for this claim. Keep unrelated successful work separately identified.
