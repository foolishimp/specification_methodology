## UAT-06-B — Resume With A New Effect Observation

Initial state: Q7, A7 and B0 remain selected. The carrier preserves C7/J7/E0
and adds E1, which reports effect state unknown instead of E0's known
no-effect observation. No later owner observation is available.

Task: "Continue the A7 explanation request using the latest record."

Access and effects: inspect the current evidence and permitted effect journal;
record a bounded successor account in the existing sandbox carrier. No
repair, retry, publication or operational change is granted.

Return: what remains supported, what changes with E1, the predecessor relation
and the next resolving condition.
