## UAT-08-B — Recover An Unobserved Outcome

Initial state: Q7's attempted validation/explanation path has its original
diagnostic and grant. E1 reports unknown effects; the accessible journal has
no resolving observation. B0's retry rule and C7/J7/E0 predecessor are present.

Task: "The result was interrupted. Recover this request and tell me whether
to try the operation again."

Access and effects: read-only diagnostic/effect observation under the
existing grant. No repair, retry or new operation is granted.

Return: observed cause, known versus unknown effects, supported next action
and exact resumption condition.
