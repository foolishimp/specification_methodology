## UAT-04-A — Apply The Accepted Root Revision

Initial state: P0 has G1, unchanged Public members and the B1 successor:
RootOwner0's accepted RootRequirement1/RootDesign1, A1, permitting root1.
The original scoped ruling and exact root-change sandbox grant are present.
A valid author-independent FR0 result binds exactly G1/B1.

Task: "Use root1 for this selected project under the recorded decision."

Access and effects: change only P0's root relation in the isolated copy under
the existing Writer grant, verify that relation and preserve unrelated work.

Return: the accepted governing successor and scoped operation consumed,
observed result and remaining conditions, with original decision reachable.
