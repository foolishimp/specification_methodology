## UAT-01-B — Start Without A Resolved Selection

Initial state: the entry directory exposes two valid Product definitions,
P0 and P-other. Neither is selected by an owner or the task. Each has its own
usable basis; their byte proximity supplies no composition relation.

Task: "Start with this Product so we can fix the cache count."

Access and effects: read both definition entrypoints and selection records.
No selection, installation, adoption or edit operation is granted.

Return: the current readiness, any input you need next and the reason it
matters. Preserve both existing contexts.
