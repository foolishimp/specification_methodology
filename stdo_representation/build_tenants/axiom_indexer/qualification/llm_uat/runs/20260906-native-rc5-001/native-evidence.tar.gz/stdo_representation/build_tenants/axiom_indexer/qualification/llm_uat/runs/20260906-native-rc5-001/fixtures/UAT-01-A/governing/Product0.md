# Product0

P0 owns its finite cache and exact Public interface. RootOwner0 owns the declared Product0-to-root relation. Unrelated projects are outside this Product.
