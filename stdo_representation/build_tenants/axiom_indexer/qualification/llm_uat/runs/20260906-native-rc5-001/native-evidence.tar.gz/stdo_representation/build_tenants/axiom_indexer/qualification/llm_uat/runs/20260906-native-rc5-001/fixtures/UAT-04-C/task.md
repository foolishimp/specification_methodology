## UAT-04-C — Change A Design-Selected Root

Initial state: in this MC06 variant, the exact accepted requirement permits
root0 and root1, while accepted RootDesign0 selects root0. G1 proposes root1;
Public values and a valid cache result are unchanged. No successor design
acceptance or root-change operation grant is present.

Task: "Use the other root for P0. What needs to change first?"

Access and effects: inspect current/desired relations and their owners;
read-only. Do not change the root, requirement or unrelated cache work.

Return: the bounded re-entry and evidence needed for the next action.
