## UAT-01-C — Inspect A Proposed Context

Initial state: P0 has its prior usable exact context. The proposed successor
bundle names a source digest different from the source bytes at its required
route; the mismatch is reproducible. Its skill and dependency are otherwise
available. There is no grant to repair or adopt the bundle.

Task: "Can I use this proposed context for the cache task now?"

Access and effects: inspect and check the proposed bundle and prior context;
read-only, including tool output destinations.

Return: the usable and unusable parts, the decisive observation and the next
resolving input or action. Name the exact context your answer concerns.
