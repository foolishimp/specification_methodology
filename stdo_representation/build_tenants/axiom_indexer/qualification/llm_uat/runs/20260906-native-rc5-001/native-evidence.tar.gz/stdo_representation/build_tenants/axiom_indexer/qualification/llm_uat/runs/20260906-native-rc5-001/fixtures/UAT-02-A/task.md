## UAT-02-A — Repair The Cache Count

Initial state: the shared P0 baseline, available L1 candidate, complete Public
serializer, D0/A0 trace, local one-run repair contract and focused observation
procedure are present. The admitted deletion inputs are [a,b] and [a].
The exact root relation remains root0.

Task: "After deleting the last cached entry the internal count is wrong; fix
it under the current contract."

Access and effects: the existing local Writer grant permits applying the
refresh-cell repair and focused checks only in the isolated P0 copy. All other
files and projects are outside that grant.

Return: the treatment used, actual bounded changes/checks and remaining work
or completion, with source and evidence routes.
