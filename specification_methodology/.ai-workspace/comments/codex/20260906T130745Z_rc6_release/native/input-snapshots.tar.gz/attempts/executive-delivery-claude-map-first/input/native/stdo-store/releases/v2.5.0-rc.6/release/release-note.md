# STDO 2.5.0 RC6

This note declares the sixth immutable candidate on the STDO `2.5.0` line.
The product-local cut name is `v2.5.0-rc.6`; the qualified immutable ref is
`refs/tags/specification_methodology/v2.5.0-rc.6` and the public basis is
`stdo://releases/v2.5.0-rc.6/`. The namespace and subtree are both
`specification_methodology`. Publication, exact-cut Product acceptance and
consumer adoption remain distinct; this subject declaration supplies none of
those results by itself.

## Predecessor And Selected Delta

The exact published predecessor is `specification_methodology/v2.5.0-rc.5`,
tag object `d4b7c7724944e02ce25c6e6ce69722491c349924`, commit
`c7888bb2dc9aee1f5a217985f6d1547cfe6465f0`, repository tree
`cb87e3e0bfaf033ee3cfa6b260d0d9ead0312b08`, Project Subtree tree
`40dc632ee5185b2b29cfce43ef8b06f223ea27ea`, standards tree
`b04dee86bd8d4f272d215801257ddd7ae5d5d782`, installed manifest
`3fb89aeb80c65403debf1eba1705fde614556520bf1ce1a08a39033b6d98a50f`.
Its release note, prior claim dispositions and all immutable predecessor
subjects remain at their original tags.

The bounded semantic delta is the optional engagement baseline's
`STDO_REFERENCE_FRAME_BASELINE.md#steel-thread-delivery`, committed in
`508ca2d2280870c198e58ca513fb8edd8bf72d39`. Executive establishes or extends
the smallest real runnable Product path early, selects increments by material
uncertainty, dependency/interface reach and failure impact, and uses early
integration evidence to prune incompatible choices. Focused deterministic
checks and judgment probes guide construction; substantial UAT qualifies a
bounded capability or release. Distinct testing claims, unexercised-path
obligations, independence, required repetitions, material invalidation and
existing operation grants remain with their owners.

The aggregate compression projects that guidance; the bootstrap changes only
its source digest. Exactly three standards members change and 49 remain
byte-conserved. The plugin's two version manifests and packaged installation
selectors advance to RC6; its five workflow skills and host metadata remain
byte-conserved. Manager `stdo-toolchain 0.1.3`, all 11 implementation files,
package configuration and license remain byte-conserved from RC5.

The complete coordinated successor uses suffix `2.5.0-rc.6`. Its Axiom and
Representation Products retain separate ownership. Their same-version
program/map and complete source-corpus bindings must be regenerated and
qualified from the exact RC6 Install; RC5 derived assets cannot stand in for
the changed source. Source Product/Intent/model/frame declarations and the
source project's operative RC4 Definition are excluded from the released
normative inventory and remain unchanged. Completed T030/T029 are not reopened.

## Claims And Successor Dispositions

| RC6 claim | Bounded claim and RC5 disposition |
|---|---|
| `STDO-2.5-RC6-C01` | RC5 C01 is superseded only by the explicit steel-thread sequencing extension above. Existing proportionate treatment, C/J/O, conditional frames, design coverage, closure, grant and independence meanings are conserved. |
| `STDO-2.5-RC6-C02` | RC5 C02's shared five-entrypoint functional claim is conserved. RC6 package identities and installation selectors replace the RC5 distribution identities; no new workflow or host-reliability claim is added. |
| `STDO-2.5-RC6-C03` | RC5 C03 is conserved with exact manager 0.1.3 bytes: selected complete updates, source/preimage refusal and bounded caught-failure recovery retain their prior contract and limitations. |
| `STDO-2.5-RC6-C04` | RC5 C04's exact-cohort identity is superseded by the complete RC6 corpus/plugin/Axiom/Representation binding. The complete-cohort, installed-path and guarded atomic publication requirements are conserved and require RC6 evidence. |

Earlier claims and exclusions retain their explicit RC5 dispositions. There
is no universal cost gate, automatic frame or semantic decision engine,
crash-atomic filesystem claim, implicit consumer adoption, or new repeated-J
reliability claim. Reused evidence preserves its exact earlier subjects and
limitations, including the historical unqualified FP04 prospective advice.

## Normative Standards Subject

Exactly 52 standards members; aggregate (SHA-256, two spaces,
`specification/standards/` plus member path and newline):
`7fef8c4de7a5f8b0ef2e02d5dbb33ef720f1c5402267875805feabe369e8ec7a`.

| Disposition | Member | SHA-256 |
|---|---|---|
| conserved | `specification/standards/AXIOMATIC_CALCULUS.md` | `cbe2edb928d3e75e23446f6d525baea664966e8d5920e6fa389cbaa4af8f1f8d` |
| conserved | `specification/standards/DESIGN_MODULE_METHOD.md` | `95374ea3f78c4d27e939a67c8b4aa3a071d745f29d4c773a7804896a335cb55f` |
| conserved | `specification/standards/GLOSSARY_GUIDE.md` | `da6d81df61d61e685bcf1ef69187839a52d72af7f1d61af050244f856efe0cd0` |
| conserved | `specification/standards/IDENTITY_METHOD.md` | `e65b875464cc93a3f9186d915ad88603755de34bac6f27072562ed34c13f64cd` |
| conserved | `specification/standards/ODD_METHOD.md` | `b33dd5b868e66e27c583b3237e93421ab12d502b38368bf075973c1bf7faef2d` |
| conserved | `specification/standards/POSTING_GUIDE.md` | `63ee8b6fde9803e38970e85fb2c4e0aa398632720b6a5f1cff8fb1291398c59a` |
| conserved | `specification/standards/README.md` | `7eb1ab99072963acf373af422cf698f1623dbd0628e7aff7a3ec5af4e72f8659` |
| conserved | `specification/standards/REFERENCE_FRAME_METHOD.md` | `6e9148d7c8eff847abf172315b0e282e4477f3d40866b28f7fef21c41cb067e7` |
| conserved | `specification/standards/RELEASE_METHOD.md` | `582bc15451855670495e559db3ae6a89ba37edaa3656f33499d02220cbdb141c` |
| conserved | `specification/standards/SPEC_METHOD.md` | `65d08af92cf850dcee4d1f012151baadcd5759c837a876c2dfb2161f1955fcc5` |
| changed | `specification/standards/STDO_REFERENCE_FRAME_BASELINE.md` | `3cfb24f507e6746d5263c7b866d2cd4dc4de2d9caf52bb7e90b9f66642208bf0` |
| conserved | `specification/standards/TICKET_METHOD.md` | `2dddefd1efaef26ef3c6c5232e67bee9a5755781d2f44570875228b9d8089b91` |
| conserved | `specification/standards/TRAVERSAL_OCCURRENCE_PROFILE.md` | `618bb7c8f9f1eab8283cf595ac9da3533f0f9cf80a684c6f42e09142da6590c1` |
| conserved | `specification/standards/UX_METHOD.md` | `a7cca45d6064d7fc864edd86e3913c9462cfe2a52ae3d1519c6a031713dccae7` |
| conserved | `specification/standards/WORLD_MODEL_METHOD.md` | `123ddcd05130aa95508c9fcfa194bf083caae3657baedaba0ce9214009453762` |
| conserved | `specification/standards/WRITING_GUIDE.md` | `29e50edc00997b76c20fad74724991b8cfffbe692ee6cabab208ad7a0c1b63fd` |
| conserved | `specification/standards/authority_compressions/README.md` | `ac695b50fbe503e65fd8cb50c69ebe14ec818cc19bdb24941f514cc3c403eb88` |
| conserved | `specification/standards/authority_compressions/axiomatic_calculus.compressed.md` | `30d8615f171298e8b40d112eff4fee56e302b63f9e5968272b7e7291f76c7bda` |
| conserved | `specification/standards/authority_compressions/design_module_method.compressed.md` | `db52b86a76fc8cbe664c1d95e6d0c54e139ad1b5dd5f161904b1c5a38a7ecb89` |
| conserved | `specification/standards/authority_compressions/odd_method.compressed.md` | `49968bace86260d6ffa25433598245ec89a23646b3743872aaf40bc99dbc1c6b` |
| conserved | `specification/standards/authority_compressions/spec_method.compressed.md` | `c31b7735d7a328b4516613ed4ea80e85870d96a0600a5b988be1325bc12b03d3` |
| changed | `specification/standards/authority_compressions/stdo_bootstrap.md` | `060b18aaaa81f7fe4670e5c0b8dedf21a71d130dc9edbe7933635ab665adfe13` |
| changed | `specification/standards/authority_compressions/stdo_compressed.md` | `c67213649da7ab2b2a7c7a785b071e76c804d974de20a4247c18a1233fcb47c5` |
| conserved | `specification/standards/authority_compressions/ticket_method.compressed.md` | `26f37b9b8d07a4e02c62dc17b61d72669b1c572cb3ac68c751dc01f682861f3b` |
| conserved | `specification/standards/authority_compressions/traversal_occurrence_profile.compressed.md` | `bfecda2c2e2f1c2f9e1ad97713d6a708227c2f47d4d95ce380d978b0df3877ce` |
| conserved | `specification/standards/authority_compressions/ux_method.compressed.md` | `f3323f1f4704360f59fea6d7a8a7ba92be3e1c7d0bc921725da97fdeaf44ad54` |
| conserved | `specification/standards/schemas/installed-release-manifest.schema.json` | `711a2eea44b995a043d4d9e02c8427723fc830de1a9f0f3c8c66e8ddb7aee4c2` |
| conserved | `specification/standards/schemas/product-definition.schema.json` | `e0a3b544dae6c83bf941096b440700d02fa988fd2767f3b4ab297a1a03f67abf` |
| conserved | `specification/standards/templates/AGENTS_TEMPLATE.md` | `e27610545d3b9648ca8655052a067b64f93941dd096afd8e8b25c8722b1cb20e` |
| conserved | `specification/standards/templates/CLAUDE_TEMPLATE.md` | `e27610545d3b9648ca8655052a067b64f93941dd096afd8e8b25c8722b1cb20e` |
| conserved | `specification/standards/templates/GOALS_TEMPLATE.md` | `2dc711293f5e7129389efe0e5c3ea86e111c528569e6b72dad983cdbc2c71c3d` |
| conserved | `specification/standards/templates/INTENT_TEMPLATE.md` | `85b1e6c83b30d619e9f7f8018315022b6963edaa03f908e7aac38a16d5bdab26` |
| conserved | `specification/standards/templates/PRODUCT_DEFINITION_TEMPLATE.json` | `e4189e5e51d525b7d7926ca88c9b9182b4686b8adf81108e72e24b847db94d34` |
| conserved | `specification/standards/templates/PRODUCT_TEMPLATE.md` | `0e5365e4c87faecbaccb20aa8a106364afcd07635ca52dffbbf4a223873256f9` |
| conserved | `specification/standards/templates/PROJECT_REFERENCE_FRAME_BASIS_TEMPLATE.md` | `82ffcba100061fa4d63ef8b282815add4f85ae499530ea7f56b38befd5a68d8c` |
| conserved | `specification/standards/templates/README.md` | `6e30d6e945a758bb4d34612c181a4ac694f9c19b8533b67d7ae0e73a57195a31` |
| conserved | `specification/standards/templates/build_tenants/TENANT_REGISTRY_TEMPLATE.md` | `8dd5d925a82f63683c9702a5fe8732eaa4afaead626ddfe49e270fb0a79e08a9` |
| conserved | `specification/standards/templates/build_tenants/common/README_TEMPLATE.md` | `e88790f0521229ca41cadc82af434908e5d8782748ccc93eb287d0e2fb5efae8` |
| conserved | `specification/standards/templates/build_tenants/common/design/README_TEMPLATE.md` | `7bfaf3873571c9d8a267aa8acc8e47522fc48cd90cfdef9d50216c9ae008e6bd` |
| conserved | `specification/standards/templates/build_tenants/common/design/adrs/ADR_TEMPLATE.md` | `07d28d93675b86b51953b84584aa7119cf80269354a76aa2356ff18397c7c4cd` |
| conserved | `specification/standards/templates/build_tenants/common/design/adrs/README_TEMPLATE.md` | `57fd95e135d36059611bca65bc091dafb94809ab521db834a4457513f91737e7` |
| conserved | `specification/standards/templates/build_tenants/variant/README_TEMPLATE.md` | `0236d71e75b917f4b008474478eda7662e62fc7b11cc7409b8299b2e26f3ef96` |
| conserved | `specification/standards/templates/build_tenants/variant/design/README_TEMPLATE.md` | `da70241069c9f98d09f6e179c2687966fca70a4546b9c52d2e8aee78644626e1` |
| conserved | `specification/standards/templates/build_tenants/variant/design/adrs/ADR_TEMPLATE.md` | `d2f77e99fcbafb0b3a2603e4c5854333ae22b65d78ed82a418f7a3b9ecbd988b` |
| conserved | `specification/standards/templates/build_tenants/variant/design/adrs/README_TEMPLATE.md` | `ae46291f42650da55c279b2aa09ac9ae1c91285b50ff73c0f4d2e538f68a3591` |
| conserved | `specification/standards/templates/build_tenants/variant/design/fp/INTENT_TEMPLATE.md` | `76e33d7a4a75d77644eec20f6d5d3611894320eab05e36580d29cf90c28a4490` |
| conserved | `specification/standards/templates/build_tenants/variant/design/fp/README_TEMPLATE.md` | `4542edc7e3a51bfba843530f1ee6b03fd3615f27a65d0f8815ae054225a5594c` |
| conserved | `specification/standards/templates/build_tenants/variant/design/fp/edge-overrides/EDGE_OVERRIDE_TEMPLATE.json` | `996e1f2cd55090519e7c487ec46333afd2994a546c15190bb11d862e3a0683c4` |
| conserved | `specification/standards/templates/build_tenants/variant/design/fp/edge-overrides/README_TEMPLATE.md` | `1432362afe35b5816259e6bef0163ffc38db6639557cd4541d2804ff04d02991` |
| conserved | `specification/standards/templates/docs/README_TEMPLATE.md` | `9c3425ff8b49c2b5573e9b8f0130b7a3e5f7d3ddcc01204aec363327e0872e7f` |
| conserved | `specification/standards/templates/requirements/README_TEMPLATE.md` | `4eacc1d3604e4859b60fc29c4bc6555fcd5de11d9ca1773258eedfb398e0f4a9` |
| conserved | `specification/standards/templates/requirements/STARTER_REQUIREMENTS_TEMPLATE.md` | `67e2061e7eb7757bdb71cff5775cfea90b33b5019ba31e1509e4d456cf66e5dd` |

## Subordinate Native Plugin

Exactly 17 plugin members, version `2.5.0-rc.6`; aggregate with
`./`-prefixed member names: `6772b66c68666b35596958b0544778c83efaa50bbc954a4b22bb299e9aa3d95e`.

| Disposition | Member | SHA-256 |
|---|---|---|
| changed | `plugins/spec/.claude-plugin/plugin.json` | `47608a57fdccca9e77cb53bc595dcd23cd07d13148aec74fb521c393bf1c6859` |
| changed | `plugins/spec/.codex-plugin/plugin.json` | `796a68c63c2ba89e460ef4219102b0a2174b5e62d6fcefe9a91190d5b5355c56` |
| conserved | `plugins/spec/LICENSE` | `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30` |
| conserved | `plugins/spec/claude-skills/refresh/SKILL.md` | `a501d0d6df6e6736a33180d876f8c83a157f5f0248f195d1687bce876f3a2b79` |
| changed | `plugins/spec/references/GETTING_STARTED.md` | `4397b57726d21570fad255ee3c326ed41bb8188e254e50eb387ebff819999cef` |
| conserved | `plugins/spec/references/PRODUCT_BASIS.md` | `4dcf0bb305732dcb280187804889426bd5abcd7188d9bb8df8b16af265a0b23f` |
| conserved | `plugins/spec/references/REFRESH.md` | `ced18a9ba499843f4321148d2d8df3ec0da7ebe8ecdb95ca282ff7dba5d53a8c` |
| conserved | `plugins/spec/skills/stdo-help/SKILL.md` | `3a77b5a010f4a30debce45e4b6cd846bc84a135358c0d7369178a9512d693ee2` |
| conserved | `plugins/spec/skills/stdo-help/agents/openai.yaml` | `af3add1ac0464524f1fbb33dd63c49787c1c905e883a3cbd0d48a8075474a20e` |
| conserved | `plugins/spec/skills/stdo-review/SKILL.md` | `801ae112fec10e6d57ea6b8373ed99524dcc1ce4ce1c6d6c5bbbf91eed356e12` |
| conserved | `plugins/spec/skills/stdo-review/agents/openai.yaml` | `e736f9789012d0365e5dec0973cd394a48009aa06548b83cea5912643eb7d9d4` |
| conserved | `plugins/spec/skills/stdo-status/SKILL.md` | `eef2081ec8a3db8a4f76db6408aa563c34c26b1e65e24417967956cc65655678` |
| conserved | `plugins/spec/skills/stdo-status/agents/openai.yaml` | `b8a9e5843fcb27d5a774ae34ebabe91b039d1999af1b4efd57dcdc5a16383e37` |
| conserved | `plugins/spec/skills/stdo-ticket/SKILL.md` | `f5f7244f6a19a75bf6c2a4ce8a2215f0161199026828e9a44583d7f827ac1731` |
| conserved | `plugins/spec/skills/stdo-ticket/agents/openai.yaml` | `0ca0733a5bf692cf9b9318c1eb1a64d66262b60b2357b59e24fa4d6dfc4d0d99` |
| conserved | `plugins/spec/skills/stdo-work/SKILL.md` | `562fbff7b3dbd4b7d6786aeae0aabf655f87a5c0925b9a19d582e2de1c7b9073` |
| conserved | `plugins/spec/skills/stdo-work/agents/openai.yaml` | `88995a63dc11355deb2f72948a84702f555cc52a4398843f391c7901c0bf7d3f` |

## Manager Package Inputs

The manager is subordinate tooling, not a normative standards member. Its
unchanged version is `0.1.3`; an exact RC6 Git installation selects the same
package source and configuration as RC5.

| Disposition | Member | SHA-256 |
|---|---|---|
| conserved | `src/stdo_toolchain/__init__.py` | `6aedfaba148f01687554dc159d548063d6d179409a53d4af82c854efcd599b14` |
| conserved | `src/stdo_toolchain/cli.py` | `f9d3b63eddac620269be7d2d0e9debcf31bc0ebcbea8b860ef59e03bb278bebf` |
| conserved | `src/stdo_toolchain/cohort_assets.py` | `0ab00000697afb5bd5ab8bb71d56f310be466ac5a7782908f287374293747bff` |
| conserved | `src/stdo_toolchain/cohort_update.py` | `f7506470d64553470d42816d480b34d6ae06cf1eb48a214e577875be652e7aea` |
| conserved | `src/stdo_toolchain/constants.py` | `865976bc3726e27a3f48c6f895d9238b507d1ccf132cfc3cd3622e88db3313e1` |
| conserved | `src/stdo_toolchain/errors.py` | `2fcb25411f230ffdb1dfb38a1994b47e23b3516d79cfde7e5bc10d6580a01982` |
| conserved | `src/stdo_toolchain/git_source.py` | `4140970f7aea667be94300ce6f55fc8b241c454e317594d0290df30db7b4b974` |
| conserved | `src/stdo_toolchain/manifest.py` | `745b96f29ed5eb8c6aa4d3d1f48dbceb22ff104ec37e499504c1c0e993ee35e5` |
| conserved | `src/stdo_toolchain/product_definition.py` | `ce36a6071f40e91176115e9cbe481fd7ac1d83d496c896d36e636d139bab4f88` |
| conserved | `src/stdo_toolchain/store.py` | `24dd080d0daced716e1284733c30089cb4768983e174441aae8eebc0e8f4e74d` |
| conserved | `src/stdo_toolchain/util.py` | `51508fc8878db4211abb58265b4dd7824ed92d3125b98b8e392797ccbc68d7c0` |

`pyproject.toml` SHA-256: `cbb6fb14b6271f805a5bd3bd55591bf8bf5e886d471cb012948a4e79da6ec5c0`.
`LICENSE` SHA-256: `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30`.

## Qualification And Publication

The [RC6 work and evidence carrier](../.ai-workspace/comments/codex/20260906T130745Z_rc6_release/README.md)
binds source inventory, affected semantic/package qualification and subsequent
exact-cut results. [RC5 evidence](../.ai-workspace/comments/codex/20260906T083553Z_rc5_release/README.md)
is reused only for conserved claims with its original finite observations and
limitations; no source or mechanical result becomes new native evidence.

The release follows the explicit root `STACK_RELEASE.md` relation: freeze
commit A and its local annotated STDO tag, verify the exact Install, construct
and qualify commit B, qualify the complete local ref graph and frozen remote
leases, publish only the checked full-object argument vector in one atomic
transaction, and reacquire the public objects and bytes. This note does not
claim those pending results. Later bookkeeping cannot change immutable tags.
Actual Product acceptance and consumer adoption remain separately authorized.
