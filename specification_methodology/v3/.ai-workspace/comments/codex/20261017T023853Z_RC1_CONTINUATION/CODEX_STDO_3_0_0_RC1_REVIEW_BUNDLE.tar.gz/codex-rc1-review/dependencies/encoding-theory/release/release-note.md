# STDO 2.5.1 RC2

The product-local cut name is `v2.5.1-rc.2`; its immutable ref is
`refs/tags/specification_methodology/v2.5.1-rc.2` and public basis is
`stdo://releases/v2.5.1-rc.2/`. The version-line selector is
`refs/tags/specification_methodology/v2.5.1`.

Status: reviewed source candidate; publication is recorded separately in the
[RC2 release record](../.ai-workspace/comments/codex/20260930_stdo_251_rc2/README.md).
The immutable predecessor is `refs/tags/specification_methodology/v2.5.1-rc.1`, tag `b80e82e123f7f88eb0dffd9339f8ead9c733d153`,
commit `dc4742d08af0a1c42c437a4ce645ea7ca55f3a3a`. All prior immutable cuts remain preserved.

## Change and qualification

Universal Intake Triage explains triangulation: applicable reference frames
constrain candidate diagnoses through distinct material variables, relations and
evidence over one subject and basis. Combined results preserve uncertainty and
identify the smallest sufficient lawful repair. Repeating analysis supplies no
additional evidence. No mandatory reviewer count, new review round, automatic
constitutional repricing or extra mutation authority is introduced.

Four standards members change: SPEC_METHOD and its three affected compressions.
The bootstrap compression changes only its source binding and generation date.
Independent source/invariant review binds every changed member. The matched
Representation authors the focused semantic delta, rebinds all source members,
and mechanically regenerates the map/projections from this exact Install.
Its separate release note records native-use evidence and limitations.

RC1 claims C01-C03 and their unchanged evidence remain valid within their prior
scope; this paragraph clarifies C01. C04's exact cohort identity advances to RC2.
Plugin workflow bytes and manager 0.1.4 remain unchanged; only plugin version
metadata advances. The source project's authoring basis remains RC4. External
consumer adoption, ABG delivery and repeated-judgment reliability are unclaimed.

## Standards inventory

52 members; aggregate `3701f7477a8f644e3753f471ec094b1218906d22105d2ce827918c7b40295da4`.

| Disposition | Member | SHA-256 |
|---|---|---|
| conserved | `AXIOMATIC_CALCULUS.md` | `cbe2edb928d3e75e23446f6d525baea664966e8d5920e6fa389cbaa4af8f1f8d` |
| conserved | `DESIGN_MODULE_METHOD.md` | `5cb69556bba1171ec347cac96811c50071f0648a367103aa215070239b93785e` |
| conserved | `GLOSSARY_GUIDE.md` | `da6d81df61d61e685bcf1ef69187839a52d72af7f1d61af050244f856efe0cd0` |
| conserved | `IDENTITY_METHOD.md` | `e65b875464cc93a3f9186d915ad88603755de34bac6f27072562ed34c13f64cd` |
| conserved | `ODD_METHOD.md` | `b33dd5b868e66e27c583b3237e93421ab12d502b38368bf075973c1bf7faef2d` |
| conserved | `POSTING_GUIDE.md` | `63ee8b6fde9803e38970e85fb2c4e0aa398632720b6a5f1cff8fb1291398c59a` |
| conserved | `README.md` | `7eb1ab99072963acf373af422cf698f1623dbd0628e7aff7a3ec5af4e72f8659` |
| conserved | `REFERENCE_FRAME_METHOD.md` | `6e9148d7c8eff847abf172315b0e282e4477f3d40866b28f7fef21c41cb067e7` |
| conserved | `RELEASE_METHOD.md` | `582bc15451855670495e559db3ae6a89ba37edaa3656f33499d02220cbdb141c` |
| changed | `SPEC_METHOD.md` | `7f12d32ef4e5720d5d59ee5ace50de6c1a12cc56afa53dd67a8ee4c54f8fb8a4` |
| conserved | `STDO_REFERENCE_FRAME_BASELINE.md` | `29ac1367a77bf686e621a3e1b88bb39a0ba8e6c44b40e2b29904a7eb5606571d` |
| conserved | `TICKET_METHOD.md` | `f031ce7fb3b5b366ffaee5996ae76e861697ad86897cc04c06b67da249fe0eca` |
| conserved | `TRAVERSAL_OCCURRENCE_PROFILE.md` | `618bb7c8f9f1eab8283cf595ac9da3533f0f9cf80a684c6f42e09142da6590c1` |
| conserved | `UX_METHOD.md` | `a7cca45d6064d7fc864edd86e3913c9462cfe2a52ae3d1519c6a031713dccae7` |
| conserved | `WORLD_MODEL_METHOD.md` | `123ddcd05130aa95508c9fcfa194bf083caae3657baedaba0ce9214009453762` |
| conserved | `WRITING_GUIDE.md` | `29e50edc00997b76c20fad74724991b8cfffbe692ee6cabab208ad7a0c1b63fd` |
| conserved | `authority_compressions/README.md` | `ac695b50fbe503e65fd8cb50c69ebe14ec818cc19bdb24941f514cc3c403eb88` |
| conserved | `authority_compressions/axiomatic_calculus.compressed.md` | `30d8615f171298e8b40d112eff4fee56e302b63f9e5968272b7e7291f76c7bda` |
| conserved | `authority_compressions/design_module_method.compressed.md` | `a6edc3a5fdde1946e9e47f08841b34e1e0a6ea6b937a42e2a7d9b132f53692ee` |
| conserved | `authority_compressions/odd_method.compressed.md` | `49968bace86260d6ffa25433598245ec89a23646b3743872aaf40bc99dbc1c6b` |
| changed | `authority_compressions/spec_method.compressed.md` | `fe309ca1397ca7073ed9775bcb4da3c293678ce835fc26d4cd05bffd732091c0` |
| changed | `authority_compressions/stdo_bootstrap.md` | `f7bec3f86d9f24d1fb22acc553ade2eb0861105ec4cd2f1afa7290cc85c5b61a` |
| changed | `authority_compressions/stdo_compressed.md` | `3dfe3bf0913925f5daac497cef7920fdfd0a4f3d4afea1bfc996b0715119819e` |
| conserved | `authority_compressions/ticket_method.compressed.md` | `d7ad2a08f71a0f4f4ac9478e2f9f3c08ca22d947b27e30f08476dbbb926745d8` |
| conserved | `authority_compressions/traversal_occurrence_profile.compressed.md` | `bfecda2c2e2f1c2f9e1ad97713d6a708227c2f47d4d95ce380d978b0df3877ce` |
| conserved | `authority_compressions/ux_method.compressed.md` | `f3323f1f4704360f59fea6d7a8a7ba92be3e1c7d0bc921725da97fdeaf44ad54` |
| conserved | `schemas/installed-release-manifest.schema.json` | `711a2eea44b995a043d4d9e02c8427723fc830de1a9f0f3c8c66e8ddb7aee4c2` |
| conserved | `schemas/product-definition.schema.json` | `e0a3b544dae6c83bf941096b440700d02fa988fd2767f3b4ab297a1a03f67abf` |
| conserved | `templates/AGENTS_TEMPLATE.md` | `e27610545d3b9648ca8655052a067b64f93941dd096afd8e8b25c8722b1cb20e` |
| conserved | `templates/CLAUDE_TEMPLATE.md` | `e27610545d3b9648ca8655052a067b64f93941dd096afd8e8b25c8722b1cb20e` |
| conserved | `templates/GOALS_TEMPLATE.md` | `2dc711293f5e7129389efe0e5c3ea86e111c528569e6b72dad983cdbc2c71c3d` |
| conserved | `templates/INTENT_TEMPLATE.md` | `85b1e6c83b30d619e9f7f8018315022b6963edaa03f908e7aac38a16d5bdab26` |
| conserved | `templates/PRODUCT_DEFINITION_TEMPLATE.json` | `e4189e5e51d525b7d7926ca88c9b9182b4686b8adf81108e72e24b847db94d34` |
| conserved | `templates/PRODUCT_TEMPLATE.md` | `0e5365e4c87faecbaccb20aa8a106364afcd07635ca52dffbbf4a223873256f9` |
| conserved | `templates/PROJECT_REFERENCE_FRAME_BASIS_TEMPLATE.md` | `82ffcba100061fa4d63ef8b282815add4f85ae499530ea7f56b38befd5a68d8c` |
| conserved | `templates/README.md` | `6e30d6e945a758bb4d34612c181a4ac694f9c19b8533b67d7ae0e73a57195a31` |
| conserved | `templates/build_tenants/TENANT_REGISTRY_TEMPLATE.md` | `8dd5d925a82f63683c9702a5fe8732eaa4afaead626ddfe49e270fb0a79e08a9` |
| conserved | `templates/build_tenants/common/README_TEMPLATE.md` | `e88790f0521229ca41cadc82af434908e5d8782748ccc93eb287d0e2fb5efae8` |
| conserved | `templates/build_tenants/common/design/README_TEMPLATE.md` | `7bfaf3873571c9d8a267aa8acc8e47522fc48cd90cfdef9d50216c9ae008e6bd` |
| conserved | `templates/build_tenants/common/design/adrs/ADR_TEMPLATE.md` | `07d28d93675b86b51953b84584aa7119cf80269354a76aa2356ff18397c7c4cd` |
| conserved | `templates/build_tenants/common/design/adrs/README_TEMPLATE.md` | `57fd95e135d36059611bca65bc091dafb94809ab521db834a4457513f91737e7` |
| conserved | `templates/build_tenants/variant/README_TEMPLATE.md` | `0236d71e75b917f4b008474478eda7662e62fc7b11cc7409b8299b2e26f3ef96` |
| conserved | `templates/build_tenants/variant/design/README_TEMPLATE.md` | `da70241069c9f98d09f6e179c2687966fca70a4546b9c52d2e8aee78644626e1` |
| conserved | `templates/build_tenants/variant/design/adrs/ADR_TEMPLATE.md` | `d2f77e99fcbafb0b3a2603e4c5854333ae22b65d78ed82a418f7a3b9ecbd988b` |
| conserved | `templates/build_tenants/variant/design/adrs/README_TEMPLATE.md` | `ae46291f42650da55c279b2aa09ac9ae1c91285b50ff73c0f4d2e538f68a3591` |
| conserved | `templates/build_tenants/variant/design/fp/INTENT_TEMPLATE.md` | `76e33d7a4a75d77644eec20f6d5d3611894320eab05e36580d29cf90c28a4490` |
| conserved | `templates/build_tenants/variant/design/fp/README_TEMPLATE.md` | `4542edc7e3a51bfba843530f1ee6b03fd3615f27a65d0f8815ae054225a5594c` |
| conserved | `templates/build_tenants/variant/design/fp/edge-overrides/EDGE_OVERRIDE_TEMPLATE.json` | `996e1f2cd55090519e7c487ec46333afd2994a546c15190bb11d862e3a0683c4` |
| conserved | `templates/build_tenants/variant/design/fp/edge-overrides/README_TEMPLATE.md` | `1432362afe35b5816259e6bef0163ffc38db6639557cd4541d2804ff04d02991` |
| conserved | `templates/docs/README_TEMPLATE.md` | `9c3425ff8b49c2b5573e9b8f0130b7a3e5f7d3ddcc01204aec363327e0872e7f` |
| conserved | `templates/requirements/README_TEMPLATE.md` | `4eacc1d3604e4859b60fc29c4bc6555fcd5de11d9ca1773258eedfb398e0f4a9` |
| conserved | `templates/requirements/STARTER_REQUIREMENTS_TEMPLATE.md` | `67e2061e7eb7757bdb71cff5775cfea90b33b5019ba31e1509e4d456cf66e5dd` |

## Plugin inventory

17 members; aggregate `1f91bb41a3c21bf09a1b680fc0da59d8b2690189e7985e31c6600110f300b0dd`.

| Disposition | Member | SHA-256 |
|---|---|---|
| changed | `.claude-plugin/plugin.json` | `b67bcd1c104ac7ccf962e47bc45b274f58cb3045a2c6e63a8f280f932038e593` |
| changed | `.codex-plugin/plugin.json` | `8287f192470a23cea9a70fa95086962718b932f2e9c2bcb19f8a708f44612667` |
| conserved | `LICENSE` | `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30` |
| conserved | `claude-skills/refresh/SKILL.md` | `a501d0d6df6e6736a33180d876f8c83a157f5f0248f195d1687bce876f3a2b79` |
| conserved | `references/GETTING_STARTED.md` | `bfde7bb046086e99f77bcb84bbb432fb814c8a1b9962297c6834c28e68bbdcc6` |
| conserved | `references/PRODUCT_BASIS.md` | `4dcf0bb305732dcb280187804889426bd5abcd7188d9bb8df8b16af265a0b23f` |
| conserved | `references/REFRESH.md` | `ced18a9ba499843f4321148d2d8df3ec0da7ebe8ecdb95ca282ff7dba5d53a8c` |
| conserved | `skills/stdo-help/SKILL.md` | `3a77b5a010f4a30debce45e4b6cd846bc84a135358c0d7369178a9512d693ee2` |
| conserved | `skills/stdo-help/agents/openai.yaml` | `af3add1ac0464524f1fbb33dd63c49787c1c905e883a3cbd0d48a8075474a20e` |
| conserved | `skills/stdo-review/SKILL.md` | `99f3d12012c7c3a39fc6ac5b80f4cc54c40d2709c536ec17a535647608ecf4db` |
| conserved | `skills/stdo-review/agents/openai.yaml` | `e736f9789012d0365e5dec0973cd394a48009aa06548b83cea5912643eb7d9d4` |
| conserved | `skills/stdo-status/SKILL.md` | `eef2081ec8a3db8a4f76db6408aa563c34c26b1e65e24417967956cc65655678` |
| conserved | `skills/stdo-status/agents/openai.yaml` | `b8a9e5843fcb27d5a774ae34ebabe91b039d1999af1b4efd57dcdc5a16383e37` |
| conserved | `skills/stdo-ticket/SKILL.md` | `419f12c3339e70ab3c02aa391e619463ebd20f2602287e1028a91bfe2cdeff85` |
| conserved | `skills/stdo-ticket/agents/openai.yaml` | `0ca0733a5bf692cf9b9318c1eb1a64d66262b60b2357b59e24fa4d6dfc4d0d99` |
| conserved | `skills/stdo-work/SKILL.md` | `39d9f88af4b574c4e30f45adc3b19ed324c25ae453d7359112af71aa9d4d4d8f` |
| conserved | `skills/stdo-work/agents/openai.yaml` | `88995a63dc11355deb2f72948a84702f555cc52a4398843f391c7901c0bf7d3f` |

## Manager inventory

11 byte-conserved members; aggregate `020c28990d4d7a191c52b6cf664d8ee58bc8bf3fe9d16a68655a1076dc61a12f`.

| Disposition | Member | SHA-256 |
|---|---|---|
| conserved | `__init__.py` | `193971dce07c53da19c5eec3be30be4f435d6ac41946a5e2b0587ec6442642bb` |
| conserved | `cli.py` | `f9d3b63eddac620269be7d2d0e9debcf31bc0ebcbea8b860ef59e03bb278bebf` |
| conserved | `cohort_assets.py` | `0ab00000697afb5bd5ab8bb71d56f310be466ac5a7782908f287374293747bff` |
| conserved | `cohort_update.py` | `ce425f78a40b1d84f132a4674e942cfa2069c2d81667963731a76f8a551b8083` |
| conserved | `constants.py` | `865976bc3726e27a3f48c6f895d9238b507d1ccf132cfc3cd3622e88db3313e1` |
| conserved | `errors.py` | `2fcb25411f230ffdb1dfb38a1994b47e23b3516d79cfde7e5bc10d6580a01982` |
| conserved | `git_source.py` | `4140970f7aea667be94300ce6f55fc8b241c454e317594d0290df30db7b4b974` |
| conserved | `manifest.py` | `745b96f29ed5eb8c6aa4d3d1f48dbceb22ff104ec37e499504c1c0e993ee35e5` |
| conserved | `product_definition.py` | `ce36a6071f40e91176115e9cbe481fd7ac1d83d496c896d36e636d139bab4f88` |
| conserved | `store.py` | `24dd080d0daced716e1284733c30089cb4768983e174441aae8eebc0e8f4e74d` |
| conserved | `util.py` | `51508fc8878db4211abb58265b4dd7824ed92d3125b98b8e392797ccbc68d7c0` |
