# STDO Reference Frame Baseline

## Canonical Compression

`REFERENCE_FRAME_METHOD.md` defines the finite engagement atom. The selected
complete STDO cut defines specification, design, construction, assessment,
disposition, checkpoint, continuation, identity, and release law. This profile
maps three practical engagement frames onto those existing owners:


```text
existing project authority
  + selected complete STDO and Reference Frame Method basis
  + exact governed Product or Product-chain outcome and workspace basis
  + known evaluation inventory, dependencies, and residuals
  -> sufficient direct Worker activation, or materially required coordination
  -> where coordinated: Executive outcome/basis lock and finite ready frontier
  -> Worker and applicable specialist evaluations; Reviewer only where required
  -> closed results, applicable technical triage, and declared conjunction
  -> existing bounded decision authority, result recording, and next lawful action
  -> updated basis, coverage, residuals, and frontier
  -> repeat or stop
```

The [configuration relation](FOUNDATIONS.md#configuration) derives the need to
allocate bounded tasks from finite context, finite attention, dependencies,
capabilities and assurance requirements. It does not derive one hierarchy or
an exhaustive role inventory. This optional profile chooses three useful task
frames: construction, independent assessment where required, and coordination
where long-term delivery cannot be covered by the direct work frame. Their
labels are Worker, Reviewer and Executive. Other admitted configurations may
use a single sufficient frame, peers or adaptive allocation.

This profile consumes the [shared result algebra](FOUNDATIONS.md#result-algebra),
[conjunction](FOUNDATIONS.md#result-conjunction) and
[workspace/context relation](FOUNDATIONS.md#workspace-and-context). The
[transformation library](TRANSFORMATION_LIBRARY.md) supplies reusable
responsibilities. Exact operation grants and Product-owned adoption retain
their separate authority; the selected configuration cannot grant it.

The three available frames are overlapping evaluation contexts, not a hierarchy
or actor topology. The Worker supplies the candidate subject but never activates the
Reviewer. The Reviewer evaluates but does not implement. The Executive applies
only decision authority already granted by Product, Goals, requirements,
accepted design, ticket, identity, or release law. The Worker carries only the
construction or transformation authority in its admitted intake. No frame gains
admission, publication, mutation, or other operation authority from its label.

This profile also selects twelve generic specialist-frame families: Product,
Product Composition, Design, Design Component, Public Boundary, Entity,
Operator, Owner, Effect, Reuse/Foundation, Install, and Proof. They separate recurring evaluation
questions that otherwise collapse across constitutional `WHAT`, structural
`HOW`, identity, authority, effects, foundations, installed subjects, and
evidence. They are available frame families, not mandatory actors, stages,
components, services, files, or runtime types. An activation selects only the
families material to its exact evaluation and retains an explicit residual for
any material family it cannot cover.

This profile also selects four Product-testing specialist-frame families:
user acceptance, end to end, integration, and unit. They are activated inside
the same conditionally selected engagement relation; they are not new
roles, stages, authorities, or a testing hierarchy. Their ordinary evidence
topology is:

```text
Product and accepted design
  |- user-outcome claims -> user-acceptance frames
  |- runnable causal-path claims -> end-to-end frames
  |- composition-boundary claims -> integration frames
  `- module-owned laws -> unit frames

bound results -> declared conjunction -> Product or release disposition
```

The fan-out assigns claims to their congruent evidence frames; it is not an
authority hierarchy or a claim that one frame decomposes into another.
Evidence may relate through declared conjunction, translation, falsification,
and re-entry. A broader frame cannot make a module-owned law true, and any
number of narrower green frames cannot establish an unevaluated Product
composition or user outcome.

A project may adopt this profile or define another reference-frame
configuration. That choice is admitted by the existing project authority that
owns the affected decision. A local axioms file may carry the decision; the file
does not become a new constitutional owner merely by carrying it.

---

## Status And Authority Boundary

This document is an optional specialized role and evaluation profile. “Derived”
in its frame headings means an application of shared law with the additional
profile choices identified below, not a uniquely forced role inventory. It has no
independent ownership of STDO's execution protocol or of any Product binding.

The ownership layers are distinct:

- `REFERENCE_FRAME_METHOD.md` owns the pure frame principles;
- this profile owns the optional Executive, Worker, Reviewer, specialist, and
  testing mappings; and
- `SPEC_METHOD.md#collective-reference-frame-basis` owns the Product-binding
  relation, while each adopting Product authority owns its concrete Project
  Reference-Frame Basis.

| Relation | Normative owner | Use in this profile |
|---|---|---|
| shared result, conjunction, current state and acquired context | `FOUNDATIONS.md` | supplies the one core result and continuation contracts |
| frame declaration, activation, frame-specific result refinement, translation, coverage, and revision | `REFERENCE_FRAME_METHOD.md` | defines each engagement frame and the active configuration |
| bounded-frame conservation and execution intake | `DESIGN_MODULE_METHOD.md` `STDO-UP-017..019`; `SPEC_METHOD.md` `STDO-UP-020` | supplies the Worker activation basis |
| construction, self-review, assessment, disposition, checkpoint, and continuation | `SPEC_METHOD.md` `STDO-UP-020` | supplies the complete execution transition relation |
| author/implementer and independent-review separation | `TICKET_METHOD.md` `STDO-UP-007` | supplies Reviewer independence and exact-verdict traceability |
| exact assurance subject, evidence population, and generic-method freeze | `SPEC_METHOD.md` `STDO-UP-022` | supplies review-boundary and qualification constraints |
| module-derived unit proof | `DESIGN_MODULE_METHOD.md` Design-to-Module evidence route and Module-Derived Unit Test Rule | supplies the unit frame's module ownership basis while this profile limits its claim and evidence altitude |
| capability and foundation selection before material generic construction | `DESIGN_MODULE_METHOD.md` `STDO-UP-023` | supplies the Worker's proportional reuse comparison without treating reuse itself as authority transfer; any assigned foundation role preserves its declared relation and owner |
| Product testing taxonomy, claim, ordinary user path, and acceptance meaning | `SPEC_METHOD.md` Verification Layers, Testing Strategy Taxonomy, and Test Authority Rule; current Product, requirements, accepted design, and release authority where applicable | selects user outcomes, supported interfaces, material compositions, runnable Product subjects, harnessed or live execution mode, and required testing populations |
| generic Product, Product Composition, Design, Design Component, Public Boundary, Entity, Operator, Owner, Effect, Reuse/Foundation, Install, and Proof evaluation families | current Product and requirements; `SPEC_METHOD.md` composition law; accepted design; `DESIGN_MODULE_METHOD.md`; `IDENTITY_METHOD.md`; `RELEASE_METHOD.md`; applicable domain, effect, interface, dependency, and assurance owners | supplies recurring specialist evaluation families without transferring their owners or requiring one architecture |
| work selection and growth authority | current Goals, Product, requirements, and admitted ticket or equivalent work authority | selects the governed outcome and admits local frame configuration |
| design structure and local realization frame decisions | accepted design under its governing Product and requirements | supplies specialist frames and material relations |
| human and proxy identity | `IDENTITY_METHOD.md` plus project authority | binds the Executive actor and its decision envelope |
| Product and release acceptance | current Product and `RELEASE_METHOD.md` | retains direct acceptance where those owners require it |

The following arguments explain this optional profile's bindings. The
[Foundations commitments](FOUNDATIONS.md#foundational-commitments) retain their
standing and the owners above retain their decisions. The instance premises
are an adopted project configuration, a selected work boundary and actual
grants. The coordinated rows additionally assume material work or assurance
that cannot be covered by a sufficient direct activation. Those conditions,
not finite capacity alone, select the Executive relation.

| Profile family and consuming decision | Premises and pillar contribution | Consequence at the decision | Additional choice and owner |
|---|---|---|---|
| [Engagement Applicability](#engagement-applicability), used at direct entry or coordination selection | F4 retains task dependencies; F5 bounds actors; F6 bounds grants. Reference frames distribute sufficient attention; computational execution supplies actual capability and communication conditions. | A sufficient direct Worker activation needs no Executive appointment. Coordination is required only by the material insufficiency or assurance conditions of the selected work; a role name cannot create that need. | Spec construction/assessment/delegation and the Product-owned frame basis govern selection. This profile supplies the optional Executive arrangement; the Product may select another adequate configuration. |
| [Executive Attention, Evaluation, And Action](#executive-attention-evaluation-and-action), used to select the next activation | F1 supplies the outcome; F4 preserves dependencies; F5 bounds attention; F6 bounds action. Outcome-driven development contributes the continuing frontier; reference frames contribute bounded decisions. | A dependency-ready subset can guide the next decision without loading every candidate body. Excluded obligations remain open, and a closed failing evaluation cannot become completion merely because the attention loop ends. | This profile selects the three duties, drift locks and event-driven attention. The admitted mandate supplies priority, disposition and continuation; it supplies no Executive mutation permission. |
| [Product-Chain Basis](#product-chain-basis), Executive Drift Locks and Handoff Projection, used by Worker/Reviewer activation and result consumption | F2/F3 bind exact subject and current basis; F4 preserves the next consumer's material relations. Specification/project structure supplies the governing chain; information and identity preserve the meaning and coordinates of the handoff. | A compact return must retain enough evidence, failures, effects and invalidators for the next decision. A summary or renamed checkpoint cannot substitute another outcome, subject or authority. | Faithful projection and shared currentness own adequacy. This profile selects its handoff and lock fields; Product and work owners supply the actual basis and grant. |
| [Work result](#work-result) and Complete Engagement Transition steps 3–6, used by Executive evaluation | F2/F6 bind evidence to its predicate; F5 admits refusal or interruption. Information preserves original domain outcomes; computational execution preserves performance and effects; evidence/authority separate availability, assessment and acceptance. | `candidate_ready` answers availability. Required fitness and independence remain separate; an absent return cannot fabricate non-performance or an effect-free state. A review recommendation supplies no disposition. | Foundations owns the result algebra; this profile owns the reason-qualified work refinement and triage projection. Spec/Product/release/work owners select required review and the actual decision mandate. |
| [Coverage Application](#coverage-application), specialist/testing/interface frames and Missing-Frame And Re-Entry Application, used to bind the required engagement evaluations | F1 supplies the claim; F2/F4 require evidence for its material parts and joins; F6 governs exclusions. Functional design supplies composition boundaries, algebraic calculus result conjunction, and evidence/correction the claim-specific counterexample. | A local test cannot establish the authoritative installed or user path. Missing required coverage cannot pass; an irrelevant available family need not run. Diagnosis follows the failed relation, including basis, capability and evidence defects. | Frame Method owns applicability, coverage and diagnosis. This profile selects specialist and test claims and their evidence altitudes; domain owners supply actual paths, populations, operating models and acceptance conditions. |
| [Product-Owned Adoption Or Project-Defined Configuration](#product-owned-adoption-or-project-defined-configuration), used before applying profile duties | F2/F3 bind the selected configuration; F6 separates presence from authority. Specification/project structure supplies the adoption relation; evidence and authority preserve its standing. | Packaged presence makes this profile available, not adopted. Once its coordinated branch is selected, its role duties and prohibitions apply; selecting the profile does not waive the Executive mutation lock. | Product authority selects the configuration and actors. This profile supplies adoption additions and its own duties; another project configuration is evaluated under its own governing relation. |
| [Profile Qualification](#profile-qualification), used to claim this profile works under selected actor conditions | F2/F3 bind exact subject and basis; F5 limits the tested envelope. Reference frames contribute reconstructability and sufficient use; evidence/correction contributes adverse cases and invalidators. | A successful local activation cannot qualify every actor, configuration or task. Changed material support reopens the affected qualification; unknown context does not become a fit result. | This profile selects claim-scoped discriminators; the governing authority selects applicable proof and acceptance. Foundations owns reuse and Frame Method owns generic qualification. |
| Failure Classification, Anti-Patterns and [Closure](#closure), used at engagement disposition and checkpoint | F1 selects the outcome; F4 preserves required claims and failures; F6 reserves decisions. Outcome-driven development contributes completion/stop distinctions; evidence and authority preserve supported closure. | Work occurred, a review finished or a loop stopped does not establish every required predicate. A truthful stop retains unresolved obligations and actual effects. | Foundations owns result combination and Ticket owns work closure. This profile binds them to the engagement; Product/release owners retain reserved acceptance and the mandate determines the next permitted action. |

Every requirement in this profile is either:

1. an exact application of a cited owning STDO relation; or
2. a condition for claiming adoption of this optional profile.

Neither kind creates a second amendment path for the owning federal law. A
profile statement that contradicts its cited owner is a defective application
and requires revision; it supplies no alternative version of that owner's law.

Inclusion in an exact released standards cut or another admitted method basis
makes this profile available; it does not adopt it. Adoption requires a
separately accepted Product-owned Project Reference-Frame Basis. Mutable
authoring source, installed file presence, prompts, summaries, and commentary
neither select nor adopt it.

---

## Engagement Applicability

This profile applies `SPEC_METHOD.md#construction-assessment-and-delegation`
and the selected Product-owned frame configuration. One capable context with
sufficient work authority, intake and operation grant may enter directly as
Worker (Writer). It needs no Executive activation solely to appoint it.
Coordination activates when material contexts, authority, capability or
required independence cannot be covered by that sufficient direct activation.
A role or frame name alone creates no coordination or review obligation.

Apply [Configuration](FOUNDATIONS.md#configuration) to that choice using the
actual operations, dependencies, actor capability and assurance requirement.
The coordination question is whether the direct activation can cover those
relations lawfully, not whether an Executive or Reviewer is available. Shared
governing sources do not defeat required independent judgment, while a fresh
context does not remove an actor's authorship. The selected branch retains
those conditions in its intake and grants.

The direct route binds the same exact intake, operation territory, applicable
obligations, evidence, stop conditions and declared result consumer. It uses
the smallest existing carrier under `TICKET_METHOD.md`, retaining admission
distinct from drafting. A sufficient local outcome with no required independent
assessment or reserved acceptance may finish as Writer and record its satisfied
conditions there. It gains no review, ticket, diagram recreation or owner
ceremony solely from using this profile. Any required assessment or owner
decision remains required; newly discovered insufficiency withholds the
dependent effect and returns the affected question to its existing owner.

The Executive transition and handoff clauses below apply when that coordinated
branch is selected. Direct work returns its closed result to the declared work
authority or existing result carrier, preserving the same result algebra and
operation/decision separation. In either branch, apply
`REFERENCE_FRAME_METHOD.md#applicability-and-required-results` and reuse valid
C/J/O through their owning SPEC_METHOD and TICKET_METHOD clauses. None of these
routes alters a Product's exact adopted basis or supplies missing authority.

## Empirical Revision Boundary

Accumulated delivery practice and observed failure may inform frame selection,
qualification, and revision. Such evidence does not become STDO authority and
does not import the originating consumer's architecture, names, actors,
topology, runtime, artifacts, or work stages into this generic profile.

The profile's engagement relation requires:

- one bounded authority selects the active work and the finite frames needed to
  evaluate it;
- a Worker constructs one exact candidate, self-reviews, reports, and stops;
- where independent assessment is required, a separately activated Reviewer
  acquires sufficient exact live authority, subject and evidence, retaining
  valid computed facts while supplying its own judgment;
- an activated Reviewer returns evidence-bound severity and technical
  implications without becoming a second implementation loop;
- where coordination is required, Executive assigns priority and adjudicates
  the current Product mandate under an existing bounded grant; and
- inability to perceive a known violation is evidence of a missing,
  misactivated, oversized, or capability-incompatible frame.

Repeated resets, extended repair loops, moving review subjects, proof masking,
and duplicate authority are generic signals that a frame declaration,
activation, capability match, basis, or authority relation may be defective.
They justify reevaluation; they do not identify one universal architecture or
grant precedent semantic authority.

The same applies to repeated Product drift: a useful implementation,
specialization, scenario, dependency, installed builder, or downstream Product
does not become the Product being authored merely because it is visible to the
same actor or participates in one delivery chain.

---

## Profile Terms

### Engagement frame

An **engagement frame** is a `REFERENCE_FRAME_METHOD.md` frame whose evaluation
family concerns selection, construction, assessment, or disposition of governed
work. Executive, Worker, and Reviewer are this profile's engagement frames.

### Specialist frame

A **specialist frame** is an activated Product, requirement, design, identity,
release, domain, implementation, test, operational, historical, or capability
frame needed by one engagement evaluation. A method member, file, component, or
lens becomes a frame only when its evaluation, basis, material manifold,
authority, evidence, result algebra, and capability envelope are declared.

### Generic specialist-frame family

A **generic specialist-frame family** is a reusable evaluation-family
archetype in this profile. It identifies a recurring distinction that a
project must either instantiate it where material, have capable authority
establish it as non-material for the governed outcome, or retain it as an
explicit coverage residual.

The family does not select a concrete carrier, component, actor, architecture,
owner, or implementation. One project may instantiate several frames in one
family. One declared frame may cover several families only when its evaluation
and result relations preserve every material distinction rather than flattening
them behind one broad label.

### Testing frame

A **testing frame** is a specialist frame whose evaluation executes or observes
a declared subject to discriminate one exact claim through an explicit oracle,
evidence population, path boundary, and falsification condition. A test file,
suite, runner, fixture, scenario label, coverage percentage, or actor does not
become a testing frame merely by existing.

Testing-frame authority is bounded by the claim actually exercised. Test count,
assertion count, source coverage, runtime duration, and framework category do
not widen that boundary.

### Authoritative Product path

An **authoritative Product path** is the declared ordinary causal composition
from a supported user or Public entry through the exact selected interfaces,
owners, state transitions, effects, persistence and recovery boundaries, and
outcome projection required by the Product claim. Producing an expected output
through a bypass, obsolete executor, test-only seam, undeclared fallback, or
competing authority falsifies path conformance even when the output value is
equal.

### Material combinatorial complexity

**Material combinatorial complexity** is the claim-relative population of
independent dimensions and interactions whose combinations can change an
outcome, violate an invariant, select another authority path, or expose a
failure. At unit altitude it includes module-owned laws, including behavior at
the public module contract, and their algebraic operators, calculation regimes,
states, transitions, boundary classes, and failure cases. Cross-participant
interface, Product, persistence, configuration, and user-role combinations
belong to integration, end-to-end, or user-acceptance frames rather than being
mocked away and counted as unit evidence.

### Executive

**Executive** is the profile label for the frame that selects or confirms the
bounded activation configuration and consumes closed Worker and Reviewer
results under existing project decision authority. It maintains a sufficient
bounded delivery view of the long-term outcome, current MVP or release mandate,
unresolved obligations, dependencies and exact returned results needed to
assign priority, apply disposition and select the next authorised action.
The underlying workspace carries the durable frontier; the Executive need not
load the whole Product, every historical result or every worker's context.

It may be occupied by direct human authority or by a bounded proxy admitted
under `STDO-UP-020`, `IDENTITY_METHOD.md`, and the current project authority.
It is not a universal semantic owner, controller, manager service, or runtime
executive observer.

---

## Executive Attention, Evaluation, And Action

Executive is the profile frame for three inseparable duties over one governed
outcome:

1. **attention management** maintains the exact outcome and basis, Product-role
   map, evaluation inventory, dependency relation, unresolved frontier, actor
   envelopes, current MVP or release mandate, applicable triage policy, and
   residual boundary, then selects the smallest
   dependency-ready activation set sufficient for the next decision within the
   finite actor envelopes;
2. **evaluation orchestration** activates capable Workers, Reviewers, or
   specialists, preserves their exact subjects and bases, and consumes only
   closed results or declared translations; and
3. **authorized action selection** assigns priority, determines the effect on
   the current promotion boundary, applies an existing disposition, and issues
   only the next already-authorized activation or action.

Executive does not contain the complete workspace, perform every evaluation,
or acquire Product meaning, implementation, mutation, acceptance, publication,
or other operation authority from the role. A material effect remains owned by
the actor carrying its exact operation grant.

An actor occupying Executive must not modify candidate, Product or worktree
bytes or perform an implementation effect. Filesystem or tool access and an
edit being small, test-only, reversible or apparently obvious supply no
exception. Mutation requires a separately activated Worker or Writer relation
with the exact operation grant, subject and write territory. A same-actor role
transition is explicit and recorded in the existing work carrier before the
effect; the actor is no longer acting as Executive for that effect. Recording
or delegating after an Executive edit cannot authorize it retroactively.

The attention cycle is:

```text
U0 = every known material evaluation not closed on the current basis

while U is non-empty:
  select a finite dependency-ready subset M that fits the assigned actors
  activate each member of M against the exact outcome and basis
  keep assurance-independent evaluations free of unclosed peer results
  when no other authorized decision is ready:
    await decision-relevant input under Event-Driven Executive Attention
  record every closed result, technical triage, residual, and invalidation condition
  apply only declared conjunctions or translations
  assign priority and boundary effect only under the current Product mandate
  invalidate affected results when the subject or basis changes
  update U from coverage, dependencies, conflicts, and discovered materiality

stop only when every mandatory evaluation is closed, or governing authority
has explicitly retained every remaining residual consistently with the claim,
or an applicable stop returns every remaining obligation as open
```

These conditions govern ending the attention cycle, not satisfaction of the
Product outcome. A stop uses the [core stop rule](FOUNDATIONS.md#result-algebra)
on the exact interrupted predicate and cause, retaining open obligations,
actual performance and effects. Closed evaluations can include falsifications;
ending the loop cannot promote those results or residuals to satisfaction.

This relation requires no scheduler or frame engine. `M` may contain parallel
activations. Recursion follows declared evaluation dependencies and bounded
refinements; it does not nest or join undifferentiated copies of every frame.
The Executive acquires the portion of the durable frontier and closed results
material to its current decision. If that decision does not fit, it refines the
coordination question, obtains another bounded evaluation or returns the
applicable stop retaining the unresolved obligation; it cannot drop a material
dependency. Closed results retain source routes, blockers, uncertainty
and invalidators so long-term coordination does not require each evaluator's
private context. An omitted obligation remains open in the workspace.

Executive continuation applies [Recovery law](TRANSFORMATION_LIBRARY.md#recovery-law)
to the delivery view and durable frontier above, including after context loss.

Bind `U0` from the applicable obligations and their dependencies under
[Applicability And Required Results](REFERENCE_FRAME_METHOD.md#applicability-and-required-results),
not from the returns currently visible to Executive. Select `M` only after
those dependencies are supported. This is how the configuration preserves the
outer outcome while bounding attention: a missing result, unknown applicability
or uncertain material effect remains in the durable frontier even when another
independent activation can proceed. The latter activation still needs its own
sufficient grant and evidence.

Severity supplied by Reviewer is evaluation evidence. Priority, current-boundary
effect, `STDO-UP-020` disposition, and subsequent action are Executive decisions.
They remain distinct ledger entries even when a Product-defined policy maps one
to another.

Every result returns to Executive, a declared conjunction, or another frame
through an explicit `D` relation. No lateral handoff, child completion, model
response, tool output, or shared actor implicitly activates another frame or
authorizes continuation. A consumer receives the closed result and its source
routes, not the child's hidden reasoning context.

### Event-Driven Executive Attention

Executive attention is event-driven by default. Re-enter the attention cycle
for a decision-relevant closed result, material exception or changed basis,
owner request, or declared deadline or checkpoint. While Workers carry out
their bounded grants and no other authorized decision is ready, wait. Do not
repeatedly inspect unfinished work, replay unchanged judgments, or request
status without a decision need.

Retain the frontier, return conditions, and valid evidence and judgments.
Refresh affected support when a material observation changes its basis;
revalidate the [Executive drift locks](#executive-drift-locks) before activation
and disposition. Waiting does not waive current-workspace verification,
evidence validity, required independent assessment, closed-result consumption,
or any authority and closure duty.

When notification is unavailable or unreliable, or an actual supervision
obligation requires observation, use bounded fallback observation with a
declared purpose, cadence or checkpoint, evidence target, and stop or escalation
condition. Silence proves neither progress nor failure. Investigate a genuine
blocker or material risk and intervene when required, within existing grants;
unknown status alone does not establish a stalled Worker.

Repeated no-progress observations or returns without new decision-relevant
evidence require a bounded reassessment of the frame, grant, dependency or
evidence gap and a decision under existing authority. Do not continue polling
or repeat the same repair on an unchanged basis. Reduced reasoning churn is
not a lower-assurance path or permission to reduce required actor capability;
it introduces no universal cost, budget or accounting gate.

### Executive Drift Locks

Before activation and disposition, Executive applies
[Contract application](TRANSFORMATION_LIBRARY.md#contract-application) to its
proposed action or result reliance. Bind that decision through these locks:

- **outcome lock** — selected Goal, Product outcome, boundary, and lawful
  re-entry class, current MVP or release mandate, and triage policy remain
  unchanged;
- **basis lock** — subject, authority, dependency, configuration, topology,
  evidence, time, and candidate coordinates remain exact and current;
- **Product-role lock** — mutable Source Project, Product Definition,
  Release Cut, Product, Install, Artifact, and dependent Product identities
  remain distinct, and every Development Product role remains bound to its
  exact underlying Install;
- **authority lock** — semantic, evaluation, operation, decision, acceptance,
  and publication owners and grants remain unchanged; and
- **coverage-and-return lock** — every material evaluation and interaction is
  closed or explicit residual, and every consumed result followed its declared
  return relation.

Changed Product meaning requires its owning re-entry. Activation pressure uses
RF-012's admission/work distinction; consumed results use their exact predicate
and core mapping. Enlarging the Executive frame supplies no missing grant or
support.

### Product-Chain Basis

A governed outcome may concern one Product or an explicit directed chain of
Products. Its basis records the distinct role of every mutable Source Project,
current Product Definition, exact candidate checkpoint, Release Cut, Product,
Install, Artifact, Development Product, dependent Product, and composition
edge. Each Development Product role binds one exact underlying Install
identity. Each edge names its source and target roles, governing authority and
contracts, lifecycle, evidence boundary, refusal, and invalidation.

An installed Product may lawfully build its own successor or another Product.
That Development Product remains distinct from the mutable Source Project and
the Product being authored. Directory nesting, shared code, shared actors,
source imports, tool reachability, matching labels, or output equality creates
no Product identity, composition edge, or authority transfer.

Exact basis does not make a Source Project immutable. A Worker may
cumulatively mutate the exact Source Project and write territory named by its
operation grant. A Reviewer evaluates an exact candidate checkpoint produced
from that workspace. Repair advances the workspace, creates a new candidate,
and invalidates affected results. A released Product, Release Cut, or exact
Install remains immutable under its own lifecycle law; it does not impose
immutability on the Source Project constructing a successor.

### Worker

**Worker** is the profile label for `STDO-UP-020`'s bounded constructor role
when activated as a reference frame. It owns construction and self-review
inside its exact intake through the operation authority inherited from the
governing work relation. It does not acquire admission, publication, acceptance,
or continuation authority.

### Reviewer

**Reviewer** is the profile label for the independent live-surface evaluation
consumed by the `STDO-UP-020` assessment relation and governed by
`STDO-UP-007` and `STDO-UP-022` when activated as a reference frame. It
evaluates one exact subject and returns a closed result with evidence-bound
technical triage when a finding exists. It does not implement the repair,
assign priority, apply disposition, or activate the next frame.

### Technical triage, severity, priority, and boundary effect

Under [F2 and F6](FOUNDATIONS.md#foundational-commitments), evidence about a
failure does not supply a grant to select its response. Given this profile's
Reviewer/Executive separation, severity and authorized priority therefore remain
distinct. This profile chooses that allocation and the triage fields below;
Product authority separately chooses scales, cutoffs and non-waivable stops.

**Technical triage** is the Reviewer-owned assessment of one finding against
the exact evaluated claim and basis. Where supported by admissible evidence and
the actor capability envelope, it records:

- the affected claim and observed failure;
- severity under the Product-selected severity scale;
- causal assessment and confidence;
- blast radius and affected users, paths, or relations;
- available workaround or containment;
- repair complexity, regression risk, and material dependencies; and
- residual uncertainty and the evidence required to reduce it.

Missing causal or repair evidence remains explicit. Reviewer returns
`indeterminate` or `out_of_frame` pressure where the missing relation can change
the evaluation; it does not invent precision or send work laterally to Worker.

**Severity** grades consequence if the finding manifests. **Priority** orders
response relative to the complete Product outcome, likelihood and exposure,
current MVP or release mandate, reversibility, dependencies, cost of delay, and
available capacity. Reviewer grades severity. Executive assigns priority.

The Product-owned Project Reference-Frame Basis binds the severity scale,
priority scale, current-boundary decision cutoff, and non-waivable hard stops.
This profile imposes no universal numeric scale. Severity, priority, Reference
Frame Method result, and current-boundary effect remain distinct. None alone
makes a finding release-blocking.

**Current-boundary effect** is Executive's determination that the finding blocks
the current promotion boundary, requires narrowing, or may remain an explicit
residual. Executive then applies exactly one existing `STDO-UP-020`
disposition. A hard stop or falsified mandatory claim cannot be waived by
lowering priority. An observation outside the exact claim boundary cannot
create another review round merely by receiving a severe label.

The three boundary-effect labels are decision payloads. When their decision is
evaluated, bind “this boundary-effect determination for this finding and exact
promotion boundary was made under the current Product mandate by its bound
authority”. Evidence that it satisfies that decision contract maps to
`satisfied`; an established mandate, grant or hard-stop violation maps to
`falsified`; an undecided mandate/application maps to `indeterminate`; missing
evaluation scope/capability maps to `out_of_frame`; an unusable decision basis
maps to `invalid_basis`. Missing causes use the core missing-reason rule. A
lawful `blocks` decision can satisfy this predicate while the candidate claim
is falsified; neither label determines the other result.

### Work result

A **work result** is the closed Worker output to its declared consumer; in the
coordinated branch that consumer is Executive. It exists only after successful
Worker activation. An `activation_refusal` returns to the assigning authority
or declared result carrier and creates neither a Worker activation nor a
Worker result.

The work-result variants are finer domain outcomes, not another result algebra
or STDO semantic dispositions. Every result carries the shared core record,
the actual performance and effect state, and one exact predicate: “the requested
candidate and transition evidence are available on the activated basis within
the admitted grant's declared bounds”. The bounds include a delivery time only
where the grant requires it. A later delivery does not repair a missed bound
on the original predicate; changed bounds identify a successor claim. The refined
cases map as follows:

| Original work outcome and cause | Predicate and evidence condition | Core verdict |
|---|---|---|
| `candidate_ready` | the bound availability predicate is established, including its declared bounds | `satisfied` |
| `refused` | an established governing prohibition or owner-valid refusal defeats the bound availability predicate after lawful activation | `falsified` |
| `incomplete`, `undecided` | admissible evidence or unfinished bounded work cannot establish the bound availability predicate | `indeterminate` |
| `incomplete`, `postcondition_defeated` | an observed missing delivery, missed declared bound or missing required transition evidence defeats the bound availability predicate | `falsified` |
| `re_entry_requested`, `outside_frame` | a material relation, decision or capability needed to establish the claim lies outside the activated frame | `out_of_frame` |
| `re_entry_requested`, `basis_invalid` | the activated subject or basis cannot support the claim | `invalid_basis` |
| any variant lacking its required cause or its row's evidence condition | retain the raw outcome without inventing deciding support; independently admissible evidence on the same bound predicate remains available | apply the core missing-reason rule; the unsupported label supplies no verdict |

The cause makes the mapping exclusive; a generic re-entry request without it
is insufficient. `candidate_ready` establishes availability only, not fitness,
admission, acceptance or publication. A consumer cannot conjoin different
predicates merely because their verdicts agree. Known non-performance or an
uncertain effect remains explicit whatever the verdict.

The mapping is total over these declared cases after lawful activation. Payload wording,
stop timing, or actor preference cannot select another variant. A capability,
authority, stale-basis, ambiguous-basis, or topology mismatch known during
activation is an `activation_refusal`, not a synthetic Worker result.
Refusal identifies its reason and governing authority; incomplete work names
its stop basis; re-entry identifies the owning authority and material relation.

Consumers choose the representation. `STDO-UP-020` remains the owner of the
execution relation and its semantic dispositions.

The result references current computed classification, supporting evidence,
residual judgments and original rulings through their existing owning carriers.
It does not reconstruct unchanged C/J/O for each handoff. The consumer checks
applicability and concrete invalidators; changed evidence revises only affected
results, preserving originals and supported surviving claims under
`TICKET_METHOD.md#recorded-judgment-and-owner-ruling-continuity`.

### Exact candidate

An **exact candidate** is the subject identity required by `STDO-UP-020`
transition evidence and `STDO-UP-007` review traceability. Where
`STDO-UP-022` generic method qualification applies, its construction result is
frozen before material reference exposure as that clause requires. Elsewhere,
this profile stabilizes the review subject through an immutable identity or an
equivalent exact-subject relation sufficient for the claimed assessment.

This profile does not create a new constitutional lifecycle state named
`frozen`.

### Baseline-adoption projection

A **baseline-adoption projection** applies
[Faithful projection](TRANSFORMATION_LIBRARY.md#faithful-projection) from the
Product-owned [Project Reference-Frame Basis](SPEC_METHOD.md#collective-reference-frame-basis)
to this profile's engagement. Its material distinctions are the selected mapping,
outcome, actor envelopes, evidence coordinates and revision conditions in
[Adopt This Baseline](#adopt-this-baseline). Adoption remains that source
owner's decision.

---

## Non-Hierarchical Frame Configuration

The [F1, F4, F5 and F6 premises](FOUNDATIONS.md#foundational-commitments), applied
through [Configuration](FOUNDATIONS.md#configuration), require sufficient task
allocation that preserves the outcome, material dependencies, capability limits
and grants. When an adopting Product requires independent assurance, its
assurance owner adds that independence premise. These premises constrain the
Executive, Worker and Reviewer contracts below; they do not force three roles.
This profile chooses their labels, return flow, Executive mutation exclusion
and event-driven attention policy. Existing Product authority chooses adoption,
direct versus coordinated activation and actual grants.

The active configuration uses three distinct relation structures:

1. **authority precedence** determines which existing surface may select work,
   admit a frame configuration, dispose a result, or require re-entry;
2. **temporal and evidence flow** carries activation packets and closed results;
   and
3. **frame topology** records disjointness, overlap, conjunction, translation,
   or composition among the evaluations actually used, while evaluation and
   Reviewer-assurance independence remain separate activation relations.

These structures may align in one case. They are not one hierarchy.

Executive, Worker, and Reviewer commonly overlap on the selected STDO basis,
governed outcome, workspace checkpoint, affected relation set, candidate,
evidence, and residuals. Their overlap does not collapse evaluation or
authority:

- Executive evaluates activation, priority, boundary effect, and disposition;
- Worker evaluates and performs bounded construction;
- Reviewer evaluates the exact candidate claim and supplies technical triage
  where assessment is activated.

The active evaluation may be represented as:

```text
engagement frame
  + material specialist frame set
  + exact subject and basis
  + capable actor
  -> one activated evaluation
```

This notation requires no Cartesian-product schema or universal frame runtime.

---

## Derived Executive Frame

| Frame element | Derived application |
|---|---|
| evaluation family | Is the bounded outcome and execution basis authorized? Which frames and actors are capable? Is a returned result exact and current? What priority, current-boundary effect, `STDO-UP-020` disposition, and next action follow from the current Product mandate? |
| subject and basis | complete selected STDO cut; exact Goals/Product/requirements/design/work authority; current MVP or release mandate; current workspace and checkpoint; open findings and technical triage; Product-selected triage policy; proxy grant where used |
| material manifold | outcome, mandate, affected causal cone, evaluation inventory, frame configuration, actor envelopes, evidence obligations, returned results and technical triage, priority, boundary effect, re-entry owners, and already-authorized continuation boundary |
| coordinates | exact method, project, outcome, mandate, authority, checkpoint, candidate, evidence, finding, triage-policy, and actor identities |
| governing invariants | `RF-001..017`; `STDO-UP-017..020`; applicable identity, ticket, assurance, and release law |
| authority | existing Product/work frame-set and decision authority or its admitted bounded proxy; no operation authority or other authority arises from the Executive label |
| evidence | live authority surfaces, frame results, Reviewer technical triage, exact candidate identity, transition evidence, coverage residuals, and specialist-frame results |
| capability envelope | enough method, Product, release or MVP, authority, workspace, triage, and actor-selection competence to configure, prioritize, and dispose the bounded evaluation; implementation expertise may be delegated to specialist frames |
| exclusions | candidate/Product/worktree byte mutation and implementation effects while occupying Executive, implementation ownership, silently rewriting Reviewer evidence or severity, independent-review claims without a qualifying activation, semantic reconstruction owned elsewhere, and disposition outside the admitted grant |
| result | one Reference Frame Method result, assigned priority and current-boundary effect, plus an existing `STDO-UP-020` disposition where the basis is decidable |
| invalidation | material method, authority, outcome, mandate, triage policy, checkpoint, candidate, evidence, finding, capability, or topology change |

The Executive frame does not introduce `authorize` or `no_action` as peer
STDO dispositions. Activation is the `REFERENCE_FRAME_METHOD.md` function;
bounded candidate disposition remains exactly `accept`, `local_repair`,
`re_enter`, or `reject` under `STDO-UP-020`.

Priority and current-boundary effect are decision projections, not additional
Reference Frame Method results or `STDO-UP-020` dispositions. If Executive
cannot rely on the supplied severity or technical assessment, it reactivates a
capable evaluation or retains the uncertainty; it does not silently rewrite the
Reviewer result.

### Steel-Thread Delivery

Executive sequences delivery around a steel thread: the smallest real,
runnable path from a supported Product entry to a material outcome through
the selected composition. Establish that path early and expand it in bounded
increments. Where it already exists, extend or revalidate the affected
thread. Select increments by consequential uncertainty, dependency and
interface reach, and failure impact.

Early end-to-end and integration evidence prunes incompatible construction
choices before they spread. Use it to settle the exercised interfaces,
preserve working composition, and concentrate construction on unresolved
obligations. Each passing thread establishes only the relations and
conditions actually exercised; untested branches, interaction combinations,
refusal and recovery paths retain their material proof obligations. Revisit
settled construction decisions when material counterevidence invalidates
their basis.

During construction, use focused deterministic regression and targeted
judgment probes to resolve material uncertainty. Use unit evidence for
module-owned laws under the testing frames. Schedule substantial,
resource-intensive user-acceptance cycles near release or when a bounded
capability is considered complete enough to qualify. An early focused user
probe remains appropriate when it decides a material outcome uncertainty.

The [Product testing frames](#derived-product-testing-frame-set) retain their
distinct claims and govern the necessary scenarios, independent assessments,
and repetitions. Reuse qualified results while their exact subject and basis
remain valid; rerun affected assurance when a material change invalidates it.
Executive selects this sequence under the existing mandate and activates
construction through the existing operation grants.

---

## Derived Worker Frame

| Frame element | Derived application |
|---|---|
| evaluation family | Can the exact authorized outcome be constructed through the smallest coherent causal cone while preserving every affected governing relation and disposing competing paths? |
| subject and basis | `STDO-UP-020` sufficient execution intake plus the accepted `STDO-UP-017..019` design-to-execution basis where applicable |
| material manifold | affected entities, lifecycles, transformations, authorities, capabilities, algorithms, inputs, outputs, dependencies, interaction seams, failure boundaries, and proof obligations |
| coordinates | exact activation, source checkpoint, workspace, inputs, dependencies, configuration, actor envelope, outputs, candidate, and evidence identities |
| governing invariants | the complete selected STDO and project relations material to the affected cone; `STDO-UP-020` owns construction and self-review |
| authority | inherited bounded construction or transformation operation authority and self-review only; mutation is permitted only when the exact inherited owner grant names the subject and write territory; no admission, publication, independent acceptance, frame-set revision, or inferred next action |
| evidence | live implementation, tests and test source, analysis, generated artifacts, installed or operational behavior where claimed, reconstruction, mutations, and exact transition evidence |
| capability envelope | the declared method, domain, implementation, tool, access, and finite-context competence required by the causal cone |
| exclusions | upstream semantic change, unauthorized cone expansion, self-acceptance, hidden competing paths, and advancement after returning the work result |
| result | one Reference Frame Method result plus exactly one `candidate_ready`, `refused`, `incomplete`, or `re_entry_requested` profile work-result variant |
| invalidation | material intake, basis, checkpoint, dependency, configuration, capability, or topology change |

`candidate_ready` binds the exact candidate and the transition evidence required
by `STDO-UP-020`. It is not `accept`. Green tests are evidence only for the
relations their production and test semantics actually exercise.

The Worker label grants no mutation authority. An effectful Worker may mutate
only the exact subject and write territory named by its inherited construction
or transformation grant. Missing, ambiguous, or out-of-territory mutation
authority refuses the effect.

Read scope follows the complete causal cone and may exceed write territory
within the declared access grant. A narrow mutation grant does not justify
omitting a material producer, consumer or governing owner from inspection.
Return a required repair outside that territory to its owner; understanding the
relation grants no cross-boundary effect.

---

## Derived Reviewer Frame

| Frame element | Derived application |
|---|---|
| evaluation family | Is this the exact claimed subject and basis? Does it satisfy the applicable STDO and project relations without competing authority, proof masking, or an unevaluated composition boundary? For each finding, what evidence-bound severity and technical implications follow? |
| subject and basis | exact candidate, claim, governing STDO and project authority, scope, exclusions, evidence population, Product-selected severity scale, review carrier, and declared independence conditions |
| material manifold | claimed relations; causal producers and consumers; authority seams; competing paths; failure, recovery, installed, and reconstruction surfaces where claimed; test and fixture semantics; historical counterexamples; finding cause, blast radius, workaround, repair complexity, regression risk, and uncertainty where supportable |
| coordinates | exact candidate, source basis, authority revision, configuration, dependency, evidence population, severity scale, installed subject, review time, and Reviewer identity |
| governing invariants | `RF-001..017`; `STDO-UP-020`; `STDO-UP-007`; `STDO-UP-022`; applicable Product, design, identity, and release law |
| authority | bounded evaluation only; no construction, transformation, admission, publication, mutation, decision, disposition, or next-activation authority follows from review access |
| evidence | independently acquired live authority, candidate implementation, tests, artifacts, history, operational evidence, mutations, replay/reconstruction, and reproduced observations material to the claim and technical triage |
| capability envelope | declared method, domain, implementation, assurance, technical-triage, tool, access, context, counterexample-search, and independence competence |
| exclusions | candidate editing, repair implementation, priority assignment, release or MVP boundary disposition, next-action selection, Worker-summary substitution, assurance-owned semantic reconstruction, unbound evidence flattening, and silent scope expansion |
| result | one Reference Frame Method result plus findings, counterexamples, evidence-bound technical triage, and residuals sufficient for Executive to assign priority and apply the existing `STDO-UP-020` disposition where the basis is decidable |
| invalidation | material candidate, authority, basis, evidence population, severity scale, dependency, configuration, scope, or independence change |

`STDO-UP-007` determines when independent review is required and what makes it
traceable. `STDO-UP-022` determines exact assurance-boundary and qualification
freeze requirements. This profile adds neither a universal review round nor a
new independence test.

`STDO-UP-020` remains the owner of assessment and semantic disposition. This
profile uses an activated Reviewer result as independent live-surface evaluation
input and, in the coordinated branch, Executive as the authorized assessor or
proxy that applies the one existing disposition. It creates no second verdict or
disposition family.

Reviewer may assess likely repair complexity and regression risk without
becoming the repair owner. When cause, blast radius, workaround, or repair risk
cannot be supported inside the activation, the result records that uncertainty
instead of manufacturing a complete triage.

Tests are inside the Reviewer manifold when their code, fixtures, mutations,
environment, or interpretation can change the proof claim. A passing result is
not relied upon as a substitute for reviewing those semantics.

Each finding binds a violated property, supported entry or state, governing
operating/threat model and credible causal path. Apply those conditions to
retained guards and acceptance predicates as well as new findings. An excluded
threat alone gives no retention claim; a proposed wider threat model re-enters
its owner. Internal location alone does not establish trust, and hypothetical
hostility alone does not establish applicability. Retain the actual untrusted
input, mutable-state, authority and effect checks required by the supported
model. A suggested repair becomes an obligation only through its proper owner.

---

## Derived Generic Specialist Frame Set

F1–F4 require an evaluation to preserve the selected outcome, exact subject,
meaning and material joins; F5 bounds what one actor can cover; F6 prevents
broader coverage from absorbing another owner. Given Product work with those
material questions, separate bounded evaluations must retain their claim and
authority boundaries. This profile chooses the following twelve archetypes;
the cited domain owners supply their predicates and an adopting Product chooses
material instantiations. Neither Foundations nor adoption requires twelve
actors or components.

This profile declares the following generic frame families for Product work.
Each row is an evaluation archetype under `REFERENCE_FRAME_METHOD.md`, not a
complete frame declaration. An adopting project binds the exact subject,
basis, material manifold, coordinates, invariants, authority, evidence,
exclusions, result algebra, capability envelope, dependencies, and
invalidation conditions for every activated instance.

The family labels resolve inside
`urn:stdo:bounded-context:reference-frame-evaluation` under the selected STDO
basis. Under `SPEC_METHOD.md`'s Bounded-Context Semantic Resolution law,
`Product`, `Owner`, `Entity`, `Operator`, `Install`, and the other labels do not
become equal to same-spelled Product, authority, domain, or runtime concepts.
An explicit relation is required at every material cross-context seam.

| Frame family | Evaluation family and exact subject | Governing authority and permitted output | Immediate falsifier |
|---|---|---|---|
| **Product** | Does one exact current Product claim, outcome, boundary, and lifecycle govern the claimed Product subject without downstream reinterpretation? The basis is current Intent, Product, requirements, acceptance meaning, and exact Product coordinates. | Product and requirement authority retain meaning and acceptance. The frame returns only a bounded evaluation result and evidence. | Design, code, tests, a predecessor behavior, or local convention changes Product meaning or substitutes a different Product subject. |
| **Product Composition** | Does one exact directed relation between Products preserve the source and target roles, Product Definition, Release Cut, Product, and Install identities, each Development Product role binding, governing contracts, authority, lifecycle, evidence boundary, and invalidation law? A chain is evaluated through bounded edge activations and declared conjunction. | Each Product retains its own meaning. The authority and contracts cited by the composition relation own the edge. The frame returns evaluation evidence only. | Directory nesting, shared implementation, common actor, source import, tool reachability, matching output, or builder convenience creates or changes a composition relation; a Development Product is confused with the Product being authored; or one node silently redefines another. |
| **Design** | Does the accepted structural `HOW` satisfy the material constitutional `WHAT`, close the required design relations, and preserve their owners across the affected topology? | Accepted design under its governing Product and requirements owns structural decisions. The frame may identify satisfaction, contradiction, or a design re-entry gap; it cannot invent Product truth. | Implementation precedent resolves an open material design decision, design creates Product meaning, or a material relation or competing structure remains undeclared. |
| **Design Component** | Does one bounded design component and its direct causal dependency cone preserve its parent contract, internal relations, sibling seams, and required outputs? | The accepted design boundary owns only its bounded composition decision. Parent, sibling, Product, requirement, and runtime owners retain their relations. | The component omits a material far-side seam, absorbs a sibling or parent decision, or reports local closure while its direct composition is unresolved. |
| **Public Boundary** | Does one supported public entry or exit perform exactly its assigned validation, selection, transport, refusal, and projection relations while preserving the selected interior owners? | Product, interface, identity, security, and accepted-design authority define the boundary. The frame evaluates the boundary result or refusal and returns only its closed evaluation; it does not recreate interior semantics. | The public surface interprets owner meaning, sequences hidden domain decisions, exposes an interior carrier as Product truth, or admits an unsupported path. |
| **Entity** | Is one semantic, artifact, or runtime entity bound to its exact identity, kind, lifecycle, owner, representation, and applicable effect regime? | Product, domain, identity, requirement, and accepted-design authority define the entity. The frame returns an identity- and lifecycle-bound evaluation. | A filename, wrapper, ticket, object shape, cache, or process instance substitutes for stable entity identity, or distinct lifecycle coordinates are collapsed. |
| **Operator** | Is one material operation an irreducible declared relation over its admitted domain, inputs, outputs, refusals, algebra, effects, and lawful compositions? | Product, requirements, accepted Ontology and design, and the named operation owner define the relation. The frame evaluates it without creating another executable plan. | An endpoint, function, class, command, or file label is asserted to be the semantic atom; orchestration hides the real operator; or generic mechanics are rebuilt as domain law. |
| **Owner** | Does one semantic or authority-bearing relation preserve its owner, role kind, subject, scope, basis, lifecycle, refusal invariants, and permitted delegation? | The existing Product, requirement, identity, accepted-design, release, or other named authority owns the relation. The frame may evaluate authority congruence only. | Another surface recreates the judgment, source authorship is treated as authority transfer, or a proxy, foundation, frame, or actor widens the grant. |
| **Effect** | Does one action obey its declared pure, observational, artifact, or runtime effect regime, including commit, failure, retry, recovery, compensation, admission, and projection law where material? | The applicable Product, requirement, design, artifact, runtime, and admission owners retain their decisions. The frame returns an effect-bound result and evidence. | Distinct effect regimes are collapsed, a mutation bypasses its admitted owner, compensation is treated as semantic rollback, or a read becomes rival writable truth. |
| **Reuse/Foundation** | Has one material generic capability or dependency been normalized and compared against credible lawful foundations with any irreducible local remainder and authority-bearing role preserved? | `DESIGN_MODULE_METHOD.md` `STDO-UP-023` and the existing tradeoff owner govern selection. The frame cannot transfer semantic authority to a foundation. | Incumbent or local code wins without bounded comparison, a richer lawful foundation is reproduced, unknowns are scored favorably, or reuse acquires owner authority. |
| **Install** | Is the exact selected Product, release, artifact, dependency set, configuration, and callable entry resolved and exercised through its admitted installed coordinate independently of mutable source convenience? | Product, identity, release, dependency, packaging, and accepted-design authority define the installed subject. The frame returns installed identity, reachability, and refusal evidence. | Source-tree imports, ambient resolution, process registries, fixture bindings, rebuilt artifacts, or a moving workspace substitute for the claimed installed subject. |
| **Proof** | Does one exact claim have congruent subject, basis, path, population, oracle, evidence, falsifier, residual boundary, and invalidation law? | The claim owner defines meaning; applicable testing, assurance, review, Product, and release owners define evaluation and acceptance. The frame returns evidence and a closed evaluation result, not Product meaning or disposition. | A harness recreates owner meaning, evidence targets another subject or path, count or aggregate green substitutes for the claim, or proof tooling mutates the subject undetectably. |

These families are non-hierarchical and may overlap. Product does not outrank
Design by frame topology; Product authority already governs constitutional
meaning. Owner does not gain authority over Entity or Operator by being a
broader frame. Proof does not become Reviewer, acceptance, or disposition
authority. The existing authority graph remains controlling.

For each governed outcome, the known evaluation inventory dispositions every
family as one of:

- instantiated by one or more exact frame declarations or authoritative
  acquisition paths because the family is material;
- evidenced as non-material to the exact outcome by the authority capable of
  making that determination; or
- retained as an explicit uncovered, conditional, conflicted, or
  scope/capability residual (with any actual `out_of_frame` evaluation result
  referenced separately).

These are inventory treatments, not alternate evaluation verdicts. When
evaluating “every family is accounted for on this outcome and basis”, supported
material instantiation, supported non-materiality or an explicit justified
residual satisfies that family's accounting predicate. An established omission
or disproved treatment defeats it (`falsified`); undecided treatment or missing
reason is `indeterminate`; an unusable basis is `invalid_basis`; evaluation
scope/capability outside the frame is `out_of_frame`. Apply core conjunction to
the required family-accounting predicates and retain performance and effects.
Accounting for a residual does not establish adequate coverage or the family's
underlying Product claim. Those claims use
[Operational Full Coverage](REFERENCE_FRAME_METHOD.md#operational-full-coverage)
and each family's exact evaluation predicate, respectively.

Absence of a named file, component, runtime object, or actor is not evidence
that a family is non-material. Conversely, adopting this profile does not
require a project to create twelve components or activate twelve frames for
every task.

When a generic frame is recursively refined, each child declaration records
its parent contract, purpose, material entities, identity and lifecycle
relations, semantic owners, direct sibling seams, applicable invariants, and
prohibited competing paths. Refinement opens only for a material distinction
needed to close the parent evaluation. This is a frame dependency relation,
not an organizational or runtime hierarchy.

Coverage records the union of admissible observations. A composite claim uses
[Result Conjunction](REFERENCE_FRAME_METHOD.md#result-conjunction) over its
required family predicates and material seams. Cross-frame values, evidence
and operations use the other [frame relations](REFERENCE_FRAME_METHOD.md#using-frames-in-conjunction)
where needed. Each row's subject, authority and evidence conditions remain
required; no family is selected as dominant.

This generic set imports no consumer-specific frame, runtime role,
architectural topology, or renamed local substitute. A consumer may declare
such frames under its own Product or accepted-design authority when they are
material. They are not part of this baseline.

---

## Derived Product Testing Frame Set

F1 and F2 require evidence congruent with the claimed outcome; F3 binds the
actual subject; F4 prevents local proof from proving an unevaluated composition;
F6 preserves the claim owner's meaning. Therefore a testing result can support
only the path, population and oracle it actually evaluates. This profile chooses
four frame archetypes and their evidence boundaries. Spec's testing and
assurance owners, the Product and accepted design select the actual claims,
required populations and acceptance policy; the four-frame inventory is not a
consequence of F1–F6 alone.

When this profile supports Product promotion, closure, or release assurance,
testing is configured as a claim-relative specialist-frame set. The kind of
runner does not select the frame. The evaluated claim, subject, path,
population, oracle, and falsification boundary do.

Where the generic specialist set is adopted, testing frames supply
claim-congruent evidence to one or more Proof-frame evaluations. Proof is not a
testing hierarchy or aggregate-green frame: user-acceptance, end-to-end,
integration, and unit results retain their distinct claims and coordinates.

The ordinary configuration contains four distinct frames:

- user acceptance evaluates the Product outcome from the user's supported
  reference frame;
- end to end evaluates the complete runnable causal realization of that
  outcome;
- integration evaluates one material composition boundary and its interaction
  population; and
- unit evaluates one module-owned law. Internal combinatorial complexity
  determines the proportional size and strategy of that evidence, not whether
  the module-owned law is eligible for unit proof.

These frames may overlap and one execution may supply evidence to several of
them. Every result remains bound to its own claim. A label such as `UAT`, `E2E`,
`integration`, or `unit` has no assurance value without the corresponding frame
declaration.

Apply [Construction assurance](FOUNDATIONS.md#construction-assurance) to each
selected testing claim. The frame binds its requirement or refinement source,
asserted predicate, observation basis and required assurance through the
application below. These bindings add no test archetype or mandatory actor;
this profile's adoption, ordinary-path and exact-subject conditions still apply.

### Derived User-Acceptance Frame

| Frame element | Derived application |
|---|---|
| evaluation family | Can a declared user, with the user's admitted capability and information, obtain the exact Product-defined outcome through the supported ordinary Product surface? |
| subject and basis | exact deployed, installed, or otherwise runnable Product form named by the claim; current Product, requirement, UX, identity, policy, and acceptance authority; declared user role, environment, and harnessed or live sandbox mode under `SPEC_METHOD.md` |
| material manifold | user goal, supported entry surfaces, permissions, inputs, Product configuration, ordinary dependencies, any declared external-worker or transport substitution boundary, user-visible state and outputs, refusal and recovery behavior, and acceptance interval |
| coordinates | exact Product and artifact identity, install, user role, capability, configuration, dependency realization, harnessed or live mode, data, workspace, invocation, time, outcome, and scenario identity |
| governing invariants | applicable Product and requirement outcomes; supported-interface, identity, UX, safety, persistence, and release laws; `RF-001..017`; `STDO-UP-001`, `STDO-UP-008`, and `STDO-UP-022` |
| authority | bounded evaluation only; the user-acceptance frame does not mint Product meaning or acceptance authority, and an automated actor does not become the human or Product acceptance owner |
| evidence | actual supported-surface requests and responses, user-visible projections, durable side effects where claimed, refusals, recovery observations, scenario records, exact-subject identity, and declared live or substituted dependency identity |
| capability envelope | ability to operate the Product as the declared user would, perceive the material outcome and refusal surfaces, and distinguish hidden setup or unsupported assistance |
| exclusions | source imports, private APIs, direct Product-state injection, test-only endpoints, hidden administrator capability, undeclared fixtures or substitutes, a test double at a boundary claimed as real or live, compatibility bypasses, and internal success substituted for the user outcome |
| result | one Reference Frame Method result bound to the exact user-outcome claim, plus witnessed paths, counterexamples, residual user populations, and invalidation conditions |
| invalidation | material Product, supported interface, user role, capability, configuration, dependency or substitution mode, data contract, runnable subject, acceptance meaning, or ordinary-path change |

User acceptance is the primary Product-outcome evidence frame when the claim is
that a user can use the Product. It may be automated only when automation
faithfully occupies the declared user frame and does not gain a path or
capability unavailable to that user. Automation can execute acceptance
evidence; it cannot assume acceptance authority.

Where `SPEC_METHOD.md` admits harnessed sandbox UAT, a deterministic, fake,
recorded, or injected external worker or transport limits the result to the
composed Product relations actually exercised. It does not prove that the live
external boundary works. When a Product or release claim depends on real
external compute or transport, live sandbox UAT is mandatory for that claim;
unit, integration, semantic, end-to-end evidence that uses the substitute, and
harnessed UAT green are not sufficient.

### Derived End-To-End Frame

| Frame element | Derived application |
|---|---|
| evaluation family | Does the exact Product subject realize the claimed outcome through the complete authoritative Product path, including every material interface, owner, state transition, effect, persistence, continuation, recovery, and projection boundary? |
| subject and basis | exact deployed, installed, or otherwise runnable Product form, composition design, supported entry, selected owner and dependency set, ordinary runtime configuration, and Product claim |
| material manifold | complete causal producers and consumers from entry to outcome; interface contracts; authority transitions; state, event, persistence, process, continuation, retry, recovery, and projection relations; competing paths |
| coordinates | artifact and installed-tree identity, entry, operation, selected definition and owner, path and edge identities, process, event prefix, state, configuration, dependency, result, replay, and scenario identity |
| governing invariants | Product and accepted-design composition laws; exact-subject and assurance congruence; path singularity where required; lifecycle, authority, persistence, replay, recovery, and release law |
| authority | bounded evaluation only; observation may expose internal evidence but may not bypass, repair, replace, or reinterpret the Product path |
| evidence | supported entry invocation, observed semantic path and authority edges, owner receipts, durable events, state transitions, outputs, replay or reconstruction where claimed, installed artifact identity, and negative-path observations |
| capability envelope | ability to execute and observe the complete Product path without changing it, distinguish authoritative from rival paths, and reproduce material state and failure relations |
| exclusions | source-only substitutes for runnable-Product claims, direct invocation below the supported entry, test doubles at claimed real boundaries, test-only routing, hidden retries or repair, omitted persistence or fresh-process boundaries, and output equality without path evidence |
| result | one Reference Frame Method result bound to the exact end-to-end claim, with exercised composition edges, unexercised material paths, counterexamples, and residual combinations |
| invalidation | material artifact, install, dependency, configuration, interface, owner, path, lifecycle, persistence, recovery, projection, test semantics, or evidence-population change |

The expected output is necessary but not sufficient. Reaching it through a
forbidden or obsolete path falsifies the end-to-end claim. A test is not end to
end merely because it starts and finishes in one process, crosses many lines,
or carries an end-to-end label.

### Derived Integration Frame

| Frame element | Derived application |
|---|---|
| evaluation family | Do the actual participants at one declared material composition boundary satisfy their joint contract across the combinations of state, authority, configuration, timing, failure, and recovery that can change the boundary result? |
| subject and basis | exact interface or composition declaration, actual participating implementations or exact substitutes admitted by the bounded claim, governing Product/requirement/design law, and interaction population |
| material manifold | both sides of the boundary, shared carriers, preconditions, postconditions, authority and ownership, ordering, state, configuration, failure, retry, recovery, translation, and competing participants |
| coordinates | participant and version identities, interface and carrier revision, state, configuration, dependency, interaction case, input, output, failure, and evidence identity |
| governing invariants | declared interface and composition laws, complete participant admission, atomicity and reconstruction where applicable, and exact assurance boundary under `STDO-UP-022` |
| authority | bounded boundary evaluation only; no integration result establishes an unevaluated Product outcome or authorizes a substitute participant |
| evidence | actual exchanges, admitted carriers, state transitions, contract verdicts, failures, retries, recovery observations, interaction combinations, and participant identities |
| capability envelope | competence and access to exercise and observe the real composition seam, identify participant substitution, and vary every material interaction dimension |
| exclusions | mocks or stubs that hide the claimed real contract, one-sided contract assertions, happy-path-only exchange, helper-call equivalence, flattened versions or states, and projection of a boundary result to the whole Product without a governing relation |
| result | one Reference Frame Method result for the declared integration claim, with covered combinations, counterexamples, omitted interactions, and invalidation conditions |
| invalidation | material participant, interface, carrier, state, configuration, dependency, timing, failure, recovery, or interaction-population change |

A substitute or test double may support a deliberately narrower claim only when
its equivalence boundary and exclusions are explicit. Its result cannot be
promoted to evidence that the real participant or Product composition was
exercised.

### Derived Unit-Test Frame

| Frame element | Derived application |
|---|---|
| evaluation family | Does one module-owned law hold across its material combinations of algebraic operator, calculation regime, state, transition, public or private boundary class, and failure case? |
| subject and basis | one exact module boundary, accepted Ontology and design, active IACS or equivalent carrier inventory, module-owned requirements and public contracts, implementation, and a module-bounded decidable oracle |
| material manifold | module-owned public contracts, algebras, calculations, parsers, reducers, state machines, transition functions, combinators, admission predicates, conservation laws, invariants, numerical boundaries, and failures |
| coordinates | module and implementation revision, owned law, operator or function family, module state, input class, boundary class, expected relation, generated case, mutation, and result identity |
| governing invariants | `DESIGN_MODULE_METHOD.md` module ownership and unit-proof law; accepted Ontology, IACS, domain, sequence, state, algorithm, and error relations material to the module |
| authority | bounded local evidence only; a unit result has no Product, installed, integration, user-acceptance, architecture, path-selection, or release authority |
| evidence | law-derived examples, equivalence classes, finite exhaustive cases where available, property-based or generative cases, metamorphic relations, calculation or algebra oracles, boundary cases, and killed internal mutations |
| capability envelope | competence to derive an oracle independently from the owned law, identify the module-bounded combination population, and distinguish invariant violation from implementation restatement |
| exclusions | Product outcomes, cross-module composition, supported user paths, packaging or installation, real external participants, orchestration topology, mocked-away interface behavior, incidental branches, private helper layout, assertion count, and source coverage used as broader assurance |
| result | one Reference Frame Method result limited to the exact module-owned law and module-bounded population, with counterexamples, residual combinations, and invalidation conditions |
| invalidation | material Ontology, IACS, module boundary, owned law, algorithm, state space, numerical regime, implementation, oracle, generator, or module-bounded population change |

Unit testing is deliberately module-bounded. Every coded module requires the
module-derived unit lane owned by `DESIGN_MODULE_METHOD.md`; public module
contracts are valid unit-proof subjects. Internal combinatorial complexity
determines the proportional size and strategy of that evidence. Its highest
discriminating value is often in algebras, calculations, transformations,
parsers, reducers, state machines, decision tables, admission predicates,
conservation relations, and bounded algorithms with strong independently
derived oracles. A unit test whose oracle merely repeats the implementation or
whose cases follow incidental code branches provides weak or circular
evidence.

Modules whose material complexity lies primarily in composition, orchestration,
configuration, persistence, ownership, or user interaction require integration,
end-to-end, or user-acceptance evidence at that actual boundary. Mocking those
relations into a unit test does not convert their complexity into unit evidence.

This profile does not waive the module-derived unit lane. It binds that lane to
module-owned law and the smallest congruent evidence population. Low internal
combinatorial complexity justifies a small lane, not omission and not hundreds
of implementation-shaped tests. Unit-test volume has no independent closure
value.

No Product, user-outcome, installed-path, cross-module composition, or release
claim may be closed from unit evidence, regardless of test count, assertion
count, source coverage, mutation score, runtime, or historical pass rate.
Treating unit green as broader assurance is a frame error.

### Combinatorial Coverage And Testing-Value Index

Testing value is indexed first by the material combinations a frame can
discriminate for its exact claim. It is not indexed by test, assertion, file,
line, branch, mock, snapshot, or runner count.

For one claim, the testing-value index considers at least:

1. congruence between the claim and evaluated subject;
2. the number and materiality of independent claim dimensions;
3. the interaction strength actually covered among those dimensions;
4. authoritative-path exactness;
5. oracle independence and precision;
6. sensitivity to realistic faults, rival paths, and historical failures;
7. observability, reconstruction, and reproducibility of the result; and
8. explicit residual combinations and invalidation conditions.

No universal scalar is required. A project may define one only through Product,
requirement, or accepted-design authority and must retain the underlying
coverage coordinates rather than flattening them into a score.

At unit altitude, the relevant dimensions are module-bounded. Unit-testing
value normally rises with the internal combinatorial complexity of an algebra,
calculation, state machine, transition relation, or other module-owned closed
domain because local tests can cheaply discriminate many meaningful
combinations against a precise oracle.

At integration, end-to-end, and user-acceptance altitude, testing value can be
multiplicative rather than additive: each material interface composes
preconditions, postconditions, authority, state, configuration, failure, and
recovery with every other traversed boundary. The evidence value comes from
the interactions actually discriminated, not from merely touching many
interfaces on one sunny path.
This describes interaction coverage, not a probability or statistical
independence claim.

Material Product factors commonly include:

- user role and capability;
- supported operation and Product composition;
- selected definition, owner, implementation, and dependency;
- lifecycle and persisted state;
- configuration and version combination;
- process, continuation, retry, re-entry, and recovery mode;
- success, refusal, malformed result, partial failure, and competing-path case;
- fresh-process, replay, reconstruction, and migration condition; and
- user-visible outcome and projection.

The activated frame declares the finite interaction population and why its
covering set is adequate. Pairwise or other covering-array reduction is lawful
only where the basis explains why omitted higher-order interactions cannot
change the claim or retains them as residuals. High-consequence authority,
persistence, concurrency, recovery, migration, and historically failure-prone
relations normally require explicit higher-strength combinations.

Source, line, branch, and function coverage may diagnose whether code was
visited. They do not establish semantic combination coverage, authoritative
path selection, user-outcome coverage, or the absence of a rival path.

The admitted work authority selects the needed testing assurance under
[Risk and assurance selection](FOUNDATIONS.md#risk-and-assurance-selection).
Bind material failure consequences, coverage, uncertainty and action/acceptance
conditions when comparing candidate testing strategies. Include acquisition,
impact analysis, execution and assessment in the relevant cost boundary;
retain estimates separately from measurements. A numeric confidence claim
uses that owner's probability, dependence and calibration conditions, not
the testing-value index or test count as a substitute.

### Legitimate-Path And Technical-Debt Erasure

Every Product path claim requires two-sided evidence:

1. **required-path reachability**: each required authoritative composition has
   an exact witness in the deployed, installed, or otherwise runnable Product
   form through the supported ordinary path; and
2. **forbidden-path exclusion**: each material superseded, duplicate, fallback,
   bypass, or otherwise forbidden production path is absent, unreachable, or
   refused at its declared boundary.

A successor passing does not prove predecessor removal. Technical-debt erasure
evaluates two distinct, finite, subject-relative graphs:

1. **production closure**: the exact deployed, installed, or otherwise runnable
   Product form and configuration, including its transitive imports, exports,
   package paths, configuration switches, registries, fallbacks, consumers,
   generated runtime artifacts, recovery paths, and fresh-process
   reconstruction. No obsolete, bypass, fallback, or rival production path may
   remain reachable inside this graph for the claimed scope; and
2. **assurance/source closure**: the source consumers, fixtures, proof scripts,
   generators, mutations, and assurance tooling relied upon for the claim. No
   obsolete assurance consumer may falsely supply closure evidence or
   reintroduce the removed production path into the Product graph.

A test-only seam is lawful when it is isolated from the Product distribution,
excluded from ordinary-path evidence, and declared in the assurance subject.
Its mere presence outside the production graph is not a production-path
failure. A retained obsolete test or proof consumer remains an assurance defect
when it can falsely establish the claim or reintroduce the removed path.

Where proportionate and safe, assurance includes path-sensitive mutation or
sabotage:

- disabling the selected authoritative path prevents the Product scenario from
  succeeding;
- forcing or restoring a rival path causes refusal or a detected
  counterexample rather than silent success;
- corrupting a material interface or owner result is detected at the owning
  boundary; and
- removing an asserted obsolete path does not change the accepted Product
  outcome except through the declared deletion relation.

A Product outcome reached through a forbidden path is a falsified path claim,
not a passing Product test. A negative-path test that mutates the exact subject
without isolation, restoration, and subject revalidation invalidates its own
assurance basis.

### Testing Evidence Composition

One execution may provide several bound results. For example, a supported user
scenario may supply user-acceptance evidence for the outcome, end-to-end
evidence for the runnable causal path, integration evidence for selected
seams, and unit counterexamples for a module-owned algebra. Those claims remain
distinct and are combined only through declared Reference Frame Method
relations.

The default proof responsibilities are:

- user acceptance proves the outcome from the user's supported frame;
- end to end proves the complete authoritative runnable Product path;
- integration proves material participant composition; and
- unit proves module-owned laws, with evidence size and strategy proportional
  to their internal combinatorial complexity.

User acceptance alone may leave internal path singularity unevaluated.
End-to-end success alone may leave unselected user populations or combinations
unevaluated. Integration and unit results cannot substitute for either broader
claim. When the Product claim requires all of them, a conflict or missing result
remains visible to Executive disposition and cannot be hidden by aggregate
green status.

Apply [Parallel assurance and provenance](FOUNDATIONS.md#parallel-assurance-and-provenance)
when these results supply mutual assurance. Bind each expected predicate to
its own justified requirement/refinement path and each result to its actual
execution. Shared fixtures, tools, observations, interpretations and received
contributions remain material to dependence; overlapping claims from one run
do not create independent observations. Combine their logical results through
the existing conjunction owner, preserving the original failed and missing
claims. Required independent assessment retains its separate authorship rules.

### Assurance Subject Acquisition And Evaluation

Bind [Acquire](TRANSFORMATION_LIBRARY.md#acquire) and
[Evaluate](TRANSFORMATION_LIBRARY.md#evaluate) to two distinct inputs: the
actual owner-issued subject and an independently derived oracle from Product,
requirements and accepted design. Where the claim depends on Product, runtime,
lifecycle, admission, replay or projection truth, the source selector is its
exact runnable owner surface, validator, projection, receipt or reconstruction.
[Faithful projection](TRANSFORMATION_LIBRARY.md#faithful-projection) governs
transport of those observations to the testing frame.

The profile's additional subject condition excludes a parallel owner state
constructed by a harness, fixture, expected-value builder, proof script,
assurance evaluator or Reviewer from raw payloads, events, logs, filenames,
labels or implementation fragments.
Generic byte, digest, order, equality, membership, completeness and conjunction
checks may evaluate owner-issued evidence; they may not mint its carriers,
choose current history or the authoritative path, interpret owner lifecycle or
admission meaning, or supply a runtime fallback. A missing owner projection is
an assurance or design gap. The independent oracle judges the acquired subject;
the implementation under test need not be trusted as that oracle.

Apply [Assertions and observations](FOUNDATIONS.md#assertions-and-observations)
to this oracle and acquired subject. State the assertion's actual predicate,
its scope and the justified relation to the requirement or refinement being
claimed. A narrower assertion supplies only its supported conclusion; select
the required acceptable relation rather than assuming all valid outputs must
be equal. Support the actual observation acquisition and checker conformance,
including observations needed to distinguish material cases. Missing support
stays explicit in the core result on the original predicate; a reported test
pass or failure alone does not establish the broader obligation.

The existing source, test and evidence bindings carry assertion provenance
separately from execution provenance under
[Parallel assurance and provenance](FOUNDATIONS.md#parallel-assurance-and-provenance).
A common derivation may serve a declared test family. An implementation-derived
check can support its regression or local-property claim but cannot supply the
independently derived upstream oracle required by this profile merely by
repeating the implementation's answer.

### Testing Reassessment And Evidence Reuse

Apply [Change impact and evidence retention](FOUNDATIONS.md#change-impact-and-evidence-retention)
to the selected testing claim, changed subject/basis and material dependencies.
Bind source-to-assertion justification separately from implementation,
fixture/data, instrument, tool, environment and other evidence-validity
dependencies. Use the owner's conservative impact and exclusion conditions to
select reassessment. Unknown influence cannot justify dropping a test; new
obligations and uncovered cases require assessment even when no existing test
is selected. Applicable mandatory gates remain required.

Retain each old execution's subject and establish the applicability relation
needed to use its evidence on the new claim. Add actual reassessment results,
preserving failed, indeterminate and unperformed conditions. Selection itself
is no execution evidence. A changed requirement revisits dependent expected
answers through its owner; an implementation or environment correction revisits
the affected execution and integration under the applicable obligations.

Choose the assessment strategy under the governing assurance and risk policy,
including total relevant selection and execution costs. Supported unaffected
evidence need not be re-executed solely because another dependency changed;
broader testing remains available where the impact or policy requires it.
Retain residual combinations and known counterexamples in the existing evidence
account. This application introduces no fixed full-suite cadence or test ledger.

### Counterexample Localization

Apply [Spec's Counterexample Localization](SPEC_METHOD.md#counterexample-localization)
to the testing counterexample, exact runnable or design subject, declared causal
path, owner relations and seams. Its causal-frontier forms, evidence duties,
exact localization predicate and reason-sensitive core mapping govern this
profile application. Preserve the original testing result alongside the
localization result and use the supported frontier for the existing re-entry
relation. This application supplies neither repair authority nor an additional
always-required evaluation stage.

Before using an observed test failure as a counterexample to a broader
obligation, establish that relation through
[Evaluate](TRANSFORMATION_LIBRARY.md#evaluate). Otherwise retain the actual
bounded result and unresolved assertion or observation support. Diagnostic
work still follows Spec's owning relation; a test label supplies no repair
class, cause or authority.

---

## Derived End-To-End Interface Integration Frame

`urn:stdo:reference-frame:end-to-end-interface-integration:v1` is a composite
refinement in `urn:stdo:bounded-context:reference-frame-evaluation`. Acquire it
from this heading under the exact selected baseline basis. It relates
[Public Boundary, Design, Operator, Owner and Proof](#derived-generic-specialist-frame-set)
to [Integration](#derived-integration-frame),
[End To End](#derived-end-to-end-frame) and
[User Acceptance](#derived-user-acceptance-frame). It adds neither a thirteenth
generic family nor a fifth testing type, role or universal activation gate.

| Frame element | Derived application |
|---|---|
| evaluation family | Does one outcome remain constructable, understandable and correctly realized across its material interface chain, with sufficient participant context and conserved meaning, authority and cause? |
| subject and basis | one Product outcome and independently stated oracle; governing requirements and design basis, exact source/workspace checkpoint, contracts and finite case population; declared participant roles, functional path, dependencies, configuration and capabilities for design; actual participants, callable selection, supported entry/exit and exact runnable artifact/install for claims over their realization |
| material manifold | producers, consumers, transformations and effect owners as declared for design or actually selected for realized claims; functional preconditions/postconditions, value/reference domains, lifecycle/time, supplied context, mutable subject, refusals, observations and user-visible result at each material seam |
| coordinates and equality | distinct Product, artifact/install, workspace, observation, invocation, candidate, admitted result and evidence identities; exact revisions, domain, units, cardinality, ordering, empty/null/default meaning and validity interval; equal shape or output does not imply equal meaning, provenance or authority |
| governing invariants | selected Product/requirement/design/interface law; Reference Frame Method declaration, conjunction and translation law; the claim boundaries and obligations below; existing testing and assurance owners retain their laws |
| authority | existing owners retain semantic, operation, admission and reserved decision authority; the activation grants bounded evaluation, with construction only under its existing exact operation grant; the declared decision consumer disposes the closed result |
| evidence | source-linked contracts and both selected sides; design relations and explicitly unresolved realization facts for design claims; actual supplied request/context and response, callable/configuration identity, owner validation/effect/observation records and ordinary caller outcome for claims over those realized relations; independently derived expected relations and disclosed substitution limits |
| capability envelope | competence in the outcome, functional composition, domain/lifecycle semantics, participant capabilities and causal diagnosis; sufficient access to the exact subject and evidence without altering a reviewed subject; required independence remains claim-relative |
| exclusions | hidden context or privilege, rival contract truth, inferred authority, undeclared substitutes, private/test-only paths for ordinary-path claims, candidate output treated as admission, fixture success treated as real user evidence, and unsupported whole-Product or all-future-case conclusions |
| result and relations | each activated claim returns `satisfied`, `falsified`, `indeterminate`, `out_of_frame` or `invalid_basis` with its exact evidence, coverage, causal findings and residuals; shared evidence is referenced once and mandatory claims compose only through a declared same-basis or lawful-translation conjunction to the named decision consumer |
| invalidation | material contract, domain, participant, prompt/context, capability, callable path, configuration, translation, relevant workspace observation, lifecycle, oracle or evidence-population change invalidates affected conclusions; unchanged valid evidence and owner rulings remain reusable |
| qualification | representative sensitivity and refusal cases below, bound to actual subjects, actor envelopes and independently stated expected relations; mechanical source checks do not supply semantic or live-user qualification |

### Interface Integration Claim Boundaries

F2 and F4 require preservation across producer/consumer meanings and joins;
F3 distinguishes the actual subject from a view; F5 requires usable participant
context; F6 preserves each owner's grants. For a claimed complete user path,
those premises require evidence about its material interfaces, actual selection
and user outcome. This profile chooses the four claim boundaries and ordinary
real-path restrictions below. Product, interface and accepted-design owners
select applicability, source paths and permitted effects; a design-only claim
does not acquire a runtime obligation merely by using this frame.

| Claim | Evaluation and evidence boundary |
|---|---|
| Contract sufficiency | Can each participant determine and perform its responsibility from the declared interface and available context? Source-grounded design evaluation may establish this claim without an implemented runtime; unresolved realizability or actor-context questions remain explicit. |
| Boundary congruence | Do the actual selected producers, transformations and consumers preserve the declared domains, meanings, lifecycle and authority? Acquire both sides and their exchanges for an actual-composition claim; design correspondence alone does not prove implementation behavior. |
| Path realization | Does the exact runnable subject use the authoritative entry-to-outcome path through its material state, effect and observation boundaries? Matching output through another path is insufficient. |
| User usability | Can the ordinary human, LLM or software caller obtain the selected outcome using only its declared context, access and supported surface? Internal success or validator-aware fixtures cannot establish this claim. |

The activation selects claims from the work's applicability and states the
scope reason for unselected claims. Design-only work does not require
unavailable runtime evidence or report runtime/UAT satisfaction. An unknown
material condition keeps its dependent claim unresolved; omission cannot
close it. A full end-to-end usability claim requires all four distinct results
and their explicit conjunction. Transport, parse, admission, semantic
satisfaction, operation completion and user success are not interchangeable.

### Interface Integration Obligations

Reuse existing truth surfaces. The working record adds only missing
cross-interface relations; schemas, prompts, adapters, indexes and tests do
not become another contract owner. For each material seam:

1. Bind the functional input domain, producer success postconditions, consumer
   preconditions, permitted effects, refusals and observable exit. Direct
   successful handoff requires the producer guarantees to meet the consumer
   preconditions. An interface may instead emit candidates: candidate output,
   later admission and semantic assessment remain distinct declared stages.
   A normal model refusal or inadmissible candidate does not by itself falsify
   an adequately declared candidate interface; evaluate the exact promised
   outcome and refusal behavior.
2. Make material actor obligations and domains available through the actual
   interface/context or an exact locator the actor can lawfully resolve.
   Bind the LLM role, instructions, supplied context, tools and model/transport
   configuration where material. Generic governance access does not replace
   the Product-specific contract or authorize inference of hidden validator
   rules. Existing deterministic owners compute available facts and expose
   their owned relation to context and validation through reuse or proven
   equivalent projections. Semantic actors judge meaning within that domain;
   reserved owner rulings, eligibility, authority and admission are not
   inferred from an actor response or frame label.
3. Apply [Faithful projection](TRANSFORMATION_LIBRARY.md#faithful-projection)
   across serialization, parsing, normalization and adaptation. Bind producer
   and consumer contracts as the source/target meanings, preserving domain
   and temporal distinctions: proposed, admitted, assessed and completed;
   active input and historical context; current validity and byte availability.
4. Apply [Workspace and context](FOUNDATIONS.md#workspace-and-context) to the
   mutable subject of each later operation. Its observation is distinct from
   immutable authority, artifacts, history and prior candidates. For an ordinary
   real-path claim, a pre-step snapshot does not replace the actual current
   subject that the later operation must observe. This restriction on the
   mutable operational subject does not change an explicitly frozen authority
   or artifact basis or require repeating valid work merely because the actor
   changes.
5. Follow the actual callable path and existing effect owners through the
   selected exit and any required fresh observation. Hidden fallback, state
   injection, manually repaired output, private entry or undeclared retry
   cannot support an ordinary real-path claim. A pure function acquires no new
   event lifecycle merely because this frame evaluates it.
6. Preserve diagnostic cause through wrappers and projections. Apply
   [Counterexample Localization](#counterexample-localization): report the
   supported causal frontier, not merely the first log or clock occurrence.
   Retain the originating seam, bounded field/path, expected domain or basis,
   observed mismatch and evidence locator where available, plus downstream
   symptoms, successful work and declared continuation or block. Preserve
   joint causes, alternative frontiers and indeterminacy; do not invent a
   unique cause. Product redaction rules still govern sensitive content.
   Missing required diagnostic evidence remains a named gap. Return the
   smallest supported owner/re-entry; diagnosis grants no repair or retry.

Evidence acquisition follows
[Assurance Subject Acquisition And Evaluation](#assurance-subject-acquisition-and-evaluation).
Acquire owner facts through existing surfaces and evaluate them with an
independent contract-derived oracle. Computed facts, contextual judgments and
reserved owner rulings retain their distinct owners and validity scopes.

For an LLM-interface usability claim, use clean-room LLM UAT with the ordinary
supplied context and permitted tools, without private implementation knowledge
or fixture assistance. Expected outcomes precede response inspection. Include
the sunny case and ordinary ambiguity/negative cases material to the claim.
Disclose substitutes; replayed or fabricated responses prove only their stated
narrower relation, not live-provider usability. Do not edit responses or
silently retry until green. Live claims require live evidence under the
existing UAT law, not a new universal live-provider requirement during design.

Apply [Steel-Thread Delivery](#steel-thread-delivery): an early sunny thread
can establish bounded evidence while unexercised claims remain open. This
frame adds no exhaustive-hardening prerequisite, scenario quota, controller,
runtime, generator, routine human approval, new ledger or automatic extra
agent. Existing authority selects proportionate assurance and any further
operation. Return the four claim dispositions, exact exercised subject/path,
supported mismatch, retained work, substitutions, residuals and invalidators
in the existing work carrier; the result is not acceptance or a next-action
grant.

### Computational Whole-Path Evaluation

For material computational composition or recurrence work, compose the selected
interface claims with Operator, Owner, Reuse/Foundation and Proof to evaluate
one complete producer-to-consumer path under `DESIGN_MODULE_METHOD.md`
`STDO-UP-019` and recurrence law. Bind fact establishment, each consumer,
validity and invalidation, effects, retained alternatives and accumulated work.
Evaluate equivalent computation across different domain names without assuming
semantic equivalence. Qualification challenges the design's declared workload
and operational assumptions; it preserves independent scope, freshness and
effect checks that serve distinct supported obligations.

Return an identifiable complete-path result and its evidence to the declared
decision consumer. A collection of local successes cannot replace that result.
Design-only evidence establishes only the design claim; actual work claims
require observations on the selected path. Reuse valid unchanged results and
activate affected reassessment on material path, basis or workload change. This
is a bounded composition of existing frames, not a permanent actor, extra
specialist family, per-helper review or separate accounting ledger.

### Interface Integration Qualification

These are representative source-contract discriminators, not an executed
trial, universal test quota or whole-Product qualification. Each selected
case binds its own exact subject, oracle, evidence and claim scope.

| Case | Required discrimination |
|---|---|
| Empty and nonempty eligible domains | Ordinary context makes both domains usable; a universal empty-value workaround cannot replace the governing domain. A hidden required rule defeats contract sufficiency even if the validator correctly refuses. |
| Adequate candidate contract and rejected response | Distinguish legitimate refusal/admission filtering from an inadequate interface or a violated success guarantee; model variability alone is not frame failure. |
| Same-response or historical-only reference | Eligibility and lifecycle come from the owning domain; available or equal-looking references are not automatically current admissible inputs. |
| Individually valid but temporally mismatched carriers | Different observations or admission states can falsify boundary congruence despite matching shapes. |
| Meaning-changing translation | Loss of units, default, identity or ordering is detected against the independent outcome oracle, even when both shapes validate. |
| Fixture knows a hidden rule | Mechanical success leaves user usability unproved; it cannot conceal missing ordinary actor context. |
| Expected output through a forbidden path | Path realization is falsified; output equality does not discharge the actual-path obligation. |
| Changed workspace and reusable accepted work | Refresh affected context and dependent evidence while preserving unaffected valid work; history does not substitute for the current subject. |
| Wrapped or ambiguous failure | Preserve the supported originating causal frontier and uncertainty without replacing it with a downstream symptom or an invented unique cause. |
| Design-only sufficient contract | A bounded contract result can close while runtime and user claims remain unclaimed or unresolved according to their applicability; no runtime/UAT satisfaction is inferred. |

---

## Complete Engagement Transition

The following steps describe the coordinated branch selected under Engagement
Applicability. Direct Worker engagement preserves the same sufficient intake,
work-result refinement, closure conditions and owner boundaries without inserting
Executive appointment or a review that no applicable condition requires.

### 1. Existing Authority Selects The Basis

Goals, Product, requirements, accepted design, ticket, release, or an admitted
bounded proxy selects the outcome and work authority under its existing STDO
owner. The Product-owned Project Reference-Frame Basis projects that decision.

### 2. Executive Activates Worker

Executive binds the [Derived Worker Frame](#derived-worker-frame) and
[Baseline-Specific Activation Additions](#baseline-specific-activation-additions)
to the `STDO-UP-020` sufficient execution intake, then applies
[Select And Activate](REFERENCE_FRAME_METHOD.md#select-and-activate). The
selected action, computational relations, specialist inputs and applicable
testing claims are part of that intake. RF-012 admission refusal returns
directly to Executive, without a Worker activation or fabricated Worker result.

### 3. Worker Returns To Executive

Every completed coordinated Worker activation returns the
[Work result](#work-result) refinement and `STDO-UP-020` transition evidence
to Executive through [Handoff Projection](#handoff-projection). Direct work
uses its declared consumer. Interruption or actor loss remains unreturned work
under the core coverage, performance and effect rules; it cannot be recorded
as a completed activation. Worker stops after returning and cannot activate
Reviewer by handing over a candidate.

### 4. Executive Evaluates The Work Result

For `refused`, `incomplete`, or `re_entry_requested`, the Executive verifies
the exact basis and applies the existing authority relation. It records the
applicable `STDO-UP-020` disposition or reactivates work only when the current
authority already permits that action. None of these variants can be treated as
accepted progress merely because work occurred.

For `candidate_ready`, the Executive verifies the exact subject and determines
whether independent assessment is required by `STDO-UP-007`,
`STDO-UP-020`, `STDO-UP-022`, Product, release, risk, or the admitted work
contract. Green aggregate status cannot satisfy this step when a required
user-acceptance, end-to-end, integration, unit, or negative-path result is
missing, bound to another subject, or contradicted by a material frame result.

Apply [Result conjunction](FOUNDATIONS.md#result-conjunction) to that declared
required set and its material joins. Availability is one predicate; fitness,
required assessment and the disposition mandate retain their own conditions.
The work label supplies none of those missing conditions. An authenticated
failure remains visible alongside an absent result, and the combined result
retains actual performance and effect observations before any dependent action.

### 5A. Candidate Does Not Require Independent Review

In the coordinated branch, when independent review is not required, Executive
consumes the exact candidate, Worker self-review, transition evidence, and any mandatory
specialist-frame results. It applies `STDO-UP-020` disposition within its
decision envelope.

Self-review remains Worker evidence. The disposition does not relabel it as
independent.

### 5B. Candidate Requires Independent Review

Executive applies [Select And Activate](REFERENCE_FRAME_METHOD.md#select-and-activate)
to the [Derived Reviewer Frame](#derived-reviewer-frame), its
[activation additions](#baseline-specific-activation-additions) and the
[Exact candidate](#exact-candidate). Required testing results retain their
own claims and populations. The exact-candidate binding supplies the applicable
`STDO-UP-007/020/022` stabilization and reference-exposure conditions.

### 6. Reviewer Returns To Executive

Reviewer returns [RF-012's closed result](REFERENCE_FRAME_METHOD.md#rf-012-closed-results)
with the Derived Reviewer Frame's exact subject, population, independence,
assurance-path and invalidation coordinates. Findings, counterexamples,
adjacent observations and any re-entry owner use the triage projection below
and pass to Executive through Handoff Projection.

### Reviewer Result And Triage Projection

The Reviewer payload projection is total across the shared core verdicts as
bound by RF-012. `complete`, `indeterminate`, and `not_applicable` below classify
the finding-level triage payload; they are not new evaluation results,
dispositions, priorities, or lifecycle states.

`not_applicable` here means that finding-level triage is inapplicable to the
bound payload: satisfaction supplies no adverse finding, while an invalid
basis prevents a claim-relative technical finding. The latter still carries
the basis diagnostic and its actual performance; it is not a missing review or
a supported non-applicability judgment about the original review predicate.

| Core verdict for the review predicate | Finding and triage payload | Executive consumption constraint |
|---|---|---|
| `satisfied` | explicit no-finding state; triage `not_applicable`; evidence, residuals, and invalidation remain present | priority and current-boundary effect are `not_applicable` to this review result unless another exact consumed result supplies a finding |
| `falsified` | one or more exact findings; triage is `complete` where supported and preserves `indeterminate` fields where evidence cannot close them | apply Product-owned priority and boundary policy without mechanically mapping severity to disposition |
| `indeterminate` | partial finding or observation state; triage `indeterminate`; exact evidence gaps and residual uncertainty | retain uncertainty or reactivate a capable evaluation; do not consume it as satisfaction or a closed finding |
| `out_of_frame` | the evaluated claim requires an undeclared material relation or evaluator capability; triage `indeterminate`; name the missing relation or capability and exact reconfiguration pressure | refine or reconfigure a capable activation and retain the claim as unresolved; do not consume the result as satisfaction or falsification |
| `invalid_basis` | basis failure; triage `not_applicable`; invalidation evidence and basis-repair pressure | refuse result consumption and return through the declared basis re-entry relation |

An adjacent observation outside the evaluated claim does not replace the
claim-relative result. Reviewer returns it separately with triage
`not_applicable` to that claim and exact repricing or re-entry pressure. The
Executive returns it to its declared owner without creating a claim-relative
block or another review round from severity alone.

The Reviewer returns to Executive, not Worker. It does not edit the candidate,
direct the repair, or authorize continuation.

### 7. Executive Disposes And Checkpoints

The Executive verifies that every consumed result remains bound to the current
subject and basis, revalidates the sufficient bounded delivery view and current MVP or
release mandate, applies any declared result conjunction, assigns priority,
records the effect on the current promotion boundary, and acts on exactly one
`STDO-UP-020` disposition within its grant:

- `accept`;
- `local_repair`;
- `re_enter`; or
- `reject`.

`STDO-UP-020` remains the owner of each disposition, exact accepted checkpoint,
and next already-authorized bounded action. A repair creates a new candidate.
An affected review is reactivated against that candidate. Acceptance does not
widen the Product outcome or authorize an unselected successor.

Severity does not mechanically select priority or block promotion. Priority
does not erase severity or waive a hard stop. The Executive determines blocking
from the exact affected claim, current mandate, applicable hard stops, and
Product-owned cutoff policy. An unsupported technical assessment is returned
through a new or refined activation rather than silently rewritten.

### Executive Promotion Constraint Projection

| Consumed condition | Required Executive constraint |
|---|---|
| valid falsification of a mandatory claim governed by a non-waivable hard stop | current promotion boundary blocks regardless of assigned priority or decision cutoff |
| valid finding below the Product-owned decision cutoff with no hard stop | no mechanical block follows; apply the Product-owned policy and retain any accepted residual explicitly |
| observation outside the exact evaluated claim | treat as bounded repricing or re-entry input; do not create a claim-relative block or another review round by severity label |
| unsupported or materially incomplete technical assessment | reactivate a capable evaluation or retain `indeterminate`; do not rewrite Reviewer evidence |

---

## Handoff Projection

Each handoff applies [Faithful projection](TRANSFORMATION_LIBRARY.md#faithful-projection)
from its source contract below to the named consuming task. The exact candidate,
process, episode, configuration, evidence population and basis remain distinct
where material; required equality or translation uses the Frame Method.
Existing Goals, tickets, design, commentary, qualification, release evidence or
other admitted carriers can carry these bindings.

| Projection | Producer -> consumer | Bound source contract |
|---|---|---|
| Worker activation | Executive -> Worker | [Derived Worker Frame](#derived-worker-frame), [activation additions](#baseline-specific-activation-additions) and `STDO-UP-020` intake |
| activation refusal | activation relation -> Executive | [RF-012](REFERENCE_FRAME_METHOD.md#rf-012-closed-results) admission result and cause, with attempted frame, subject/basis, actor and reconfiguration pressure |
| work result | Worker -> Executive | [Work result](#work-result) plus `STDO-UP-020` transition evidence, non-changes and stop basis |
| Reviewer activation | Executive -> Reviewer | [Derived Reviewer Frame](#derived-reviewer-frame), activation additions and [Exact candidate](#exact-candidate) |
| review result | Reviewer -> Executive | [Reviewer return](#6-reviewer-returns-to-executive) and [triage projection](#reviewer-result-and-triage-projection) |
| specialist activation | Executive or declared parent relation -> capable evaluator | exact specialist owner and [Frame activation](REFERENCE_FRAME_METHOD.md#select-and-activate), with declared result consumer |
| specialist result | evaluator -> Executive, declared conjunction or exact parent relation | [Closed frame result](REFERENCE_FRAME_METHOD.md#return-a-closed-result); no implicit continuation |
| disposition/checkpoint | Executive -> existing work authority and any next activation | [Executive disposition](#7-executive-disposes-and-checkpoints), [promotion constraints](#executive-promotion-constraint-projection) and `STDO-UP-020` checkpoint/continuation |

Direct engagement carries the same material intake and result coordinates in
its existing work carrier. It substitutes the actual granting/result authority
for Executive where that branch has no Executive activation; it does not
silently activate Reviewer or acquire any new decision authority.

---

## Coverage Application

The three engagement frames do not claim to contain the complete STDO Product
or project workspace. They organize finite evaluations over specialist frames.

| Known evaluation | Primary engagement frame | Authority or specialist input |
|---|---|---|
| exact method, project, and work basis | Executive | complete STDO cut; current Goals/Product/requirements/design/work authority |
| affected causal cone and frame configuration | Executive, challenged by Worker and Reviewer | `STDO-UP-017..020`; domain, identity, dependency, implementation, and history frames |
| generic specialist-family coverage and cross-frame seam conservation | Executive for configuration; Worker and Reviewer for their exact evaluations | material Product, Product Composition, Design, Design Component, Public Boundary, Entity, Operator, Owner, Effect, Reuse/Foundation, Install, and Proof declarations or authoritative acquisition paths; explicit non-material and residual dispositions |
| bounded realization and self-review | Worker | accepted design; `STDO-UP-023` capability/foundation selection where material; capability/reuse, implementation, environment, and proof frames |
| candidate and transition evidence | Worker | `STDO-UP-020` and exact identity/evidence relations |
| user can obtain the Product-defined outcome through supported surfaces | Worker for execution and self-review; Reviewer where independent assurance is required | derived user-acceptance frame; Product, requirement, UX, identity, installed-subject, and acceptance inputs |
| complete authoritative installed path realizes the outcome | Worker for execution and self-review; Reviewer where independently assessed | derived end-to-end frame; composition, authority, lifecycle, persistence, recovery, replay, and negative-reachability inputs |
| material interfaces compose across their interaction population | Worker and Reviewer according to the claim | derived integration frames; actual participant, carrier, state, configuration, failure, and recovery inputs |
| module-owned laws hold | Worker and Reviewer according to the claim | derived unit frames; Ontology, IACS, public module contract, algebra, calculation, state-machine, invariant, and module-bounded combination inputs |
| obsolete and rival Product paths are absent, unreachable, or refused | Worker for deletion evidence; Reviewer for exact-subject challenge where required | distinct production-closure and assurance/source-closure graphs; package, consumer, mutation, sabotage, reconstruction, and history frames |
| independent exact-subject assessment and technical triage where required | Reviewer | `STDO-UP-007`, `STDO-UP-020`, `STDO-UP-022`, Product-selected severity scale, live implementation and assurance frames |
| result conjunction, priority, promotion-boundary effect, and disposition | Executive | exact closed Worker, Reviewer, and mandatory specialist results; current Product and MVP or release mandate; Product-owned triage policy |
| checkpoint and continuation | Executive under existing authority | `STDO-UP-020`; current Goals/Product/release boundary |
| missing-frame and topology-change response | Executive with pressure from any frame | Reference Frame Method coverage and revision functions |

The Executive derives the complete known evaluation inventory from the selected
STDO members, project domain, outcome, history, dependencies, and workspace.
It applies [Applicability And Required Results](REFERENCE_FRAME_METHOD.md#applicability-and-required-results)
to each material obligation; the table routes those obligations to frames but
does not replace their applicability predicates. It then applies
[Workspace Coverage](REFERENCE_FRAME_METHOD.md#workspace-coverage) to the
declared scope and conjunction to its required results. Frame availability,
inventory completeness and satisfaction of the outcome are distinct claims.
Operational full coverage retains every unknown, uncovered, conditional,
conflicted, or authority-excluded residual required by
`REFERENCE_FRAME_METHOD.md`.

Executive visibility is not coverage. Every material evaluation still requires
a capable frame, admissible evidence, and identified semantic and decision
owners. Every material construction, transformation, admission, publication,
or mutation also requires its existing operation owner and exact grant.

---

## Missing-Frame And Re-Entry Application

Any active frame may return `out_of_frame`, `indeterminate`, or
`invalid_basis` under the Reference Frame Method. The closed result identifies
the missing relation, coordinate, evidence, authority, capability, or
interaction capable of changing the evaluation.

Executive applies the [Frame Method diagnostic order](REFERENCE_FRAME_METHOD.md#diagnostic-order).
For this profile, its capability check includes required independence and its
material-variable check includes required specialist inputs. These bindings do
not create a second diagnostic sequence.

If the discovery changes Product, requirement, identity, lifecycle, authority,
public contract, or accepted design, `STDO-UP-020` returns `re_enter` to that
existing owner. The Executive does not repair an upstream authority gap by
making its frame larger.

---

## Product-Owned Adoption Or Project-Defined Configuration

### Existing Authority Selects The Configuration

The frame configuration is admitted by the smallest existing project authority
that owns the material decision:

- Goals or admitted work authority owns bounded work selection;
- Product owns Product-wide capability or acceptance meaning;
- requirements own constitutional behavior;
- accepted design owns realization structure and specialist design frames;
- identity and release owners retain their declared decisions; and
- an explicitly bounded proxy acts only inside its existing grant.

One configuration may derive from several governing owners. The Product-owned
Project Reference-Frame Basis defined by `SPEC_METHOD.md` cites all material
sources and does not collapse them into a new local-axiom authority.

### Adopt This Baseline

A baseline-adoption projection records the following content inside that
Product-owned basis:

- exact selected complete STDO, Reference Frame Method, and profile identities;
- existing authority admitting adoption;
- governed workspace, Product scope, outcome, basis, and time;
- local Executive, Worker, and Reviewer capability envelopes and actor-binding
  rules;
- generic specialist-frame declarations or authoritative acquisition paths,
  plus an authority-bound non-material or explicit residual disposition for
  each Product, Product Composition, Design, Design Component, Public Boundary,
  Entity, Operator, Owner, Effect, Reuse/Foundation, Install, and Proof family;
- specialist-frame declarations or authoritative acquisition paths;
- testing-frame declarations, exact Product and module claims, ordinary-path
  identities, combinatorial populations, scenario matrix, oracles, and
  forbidden-path inventory where testing evidence is material;
- local subject, evidence, checkpoint, and review-result coordinates;
- coverage ledger and accepted residual boundary; and
- invalidation and frame-set revision conditions.

### Define A Project Configuration

A project may define different frames, names, overlaps, sequences, and actor
bindings. The defining Product, requirement, Goals, or accepted-design
authority records:

- exact method and project basis;
- known evaluation inventory;
- each frame declaration and capability envelope;
- semantic, evaluation, operation where material, and decision authority;
- intentional overlap, separately activated evaluations, and required
  assurance independence;
- conjunction, translation, and composition actually used;
- mapping to applicable STDO construction, assessment, disposition, identity,
  and release obligations;
- coverage and residual uncertainty; and
- re-entry, invalidation, and revision conditions.

The project configuration need not preserve the labels Executive, Worker, and
Reviewer or map one local frame to each label. It must preserve every applicable
STDO relation and identify how its evaluations cover the claims it makes.

A local axioms document may carry this accepted configuration. Its authority is
the cited Goals, Product, requirement, or accepted-design decision, not the
document category.

### Extension Versus Replacement

Adding domain or specialist frames, additional separately activated or
assurance-independent coverage, or local evidence coordinates is an extension
of this profile. Changing the material Executive, Worker, Reviewer, handoff,
independence, or disposition configuration creates a project-defined profile.

Neither choice amends federal STDO execution law. A project intentionally
departing from that law records a separate method basis or non-conformance; it
does not describe the departure as local frame selection.

---

## Actor Binding And Independence

Frames and actors are separate identities. One actor may occupy several frames
across different activations where authority and any claimed independence are
preserved. Different humans, agents, deterministic tools, or mixed
configurations may occupy them. This profile prescribes no actor count.

Where independent review is required, `STDO-UP-007` controls. The activation
records the exact subject and verdict carrier, and the Reviewer is not the
author of that subject. `STDO-UP-022` adds its declared capability,
configuration, comparison-basis, reference-exposure, and freeze conditions for
generic method qualification.

An Executive may inspect a subject to adjudicate a result. That Executive
evaluation does not become an additional independent Reviewer result merely
because the actor used reviewer-like tools.

---

## Profile Qualification

Qualification of this derived profile applies `REFERENCE_FRAME_METHOD.md`
Frame Qualification and `STDO-UP-022`; it does not create another qualification
protocol.

The profile trial evaluates both this profile and its declared composition with
the exact Reference Frame Method basis without reproducing either as peer
authority. A valid pure-method trial does not prove this profile, and a valid
profile trial does not prove the method's complete function population.

Mechanical document checks may protect exact table shape, result cardinality,
source-digest congruence, and named refusal boundaries. They do not establish
semantic truth or replace a capable source-linked Reviewer evaluation. Profile
qualification binds both kinds of evidence without claiming one as the other.

A representative profile trial establishes at least:

1. existing project authority selects and projects the frame configuration;
2. a known incapable or unauthorized actor produces an activation refusal and
   no Worker result;
3. a fresh capable Worker reconstructs its intake without hidden conversation
   history;
4. every effectful Worker activation carries its exact inherited operation
   grant, subject, and write territory; an in-territory mutation succeeds only
   under that exact grant and an out-of-territory mutation refuses, without
   granting operation authority to another frame;
5. each qualified `(Worker work-result variant, cause)` maps to exactly one
   core verdict on the [Work result](#work-result) availability predicate,
   including missing-reason handling, and returns to its declared consumer,
   Executive in the coordinated branch; several cases may map to one verdict,
   so the original variant and cause remain required;
6. a sufficient direct local case starts and finishes as Writer in its existing
   carrier without Executive appointment or independent review; a coordinated
   `candidate_ready` also reaches disposition without Reviewer activation when
   independent review is not required;
7. review-required `candidate_ready` causes Executive, not Worker, to activate
   Reviewer;
8. Reviewer reacquires the exact subject and live production and assurance
   surfaces material to its claim;
9. changed candidate or basis invalidates the affected review result;
10. Worker self-review, Reviewer evaluation, Executive decision authority, and
   `STDO-UP-020` disposition remain distinguishable;
11. missing-frame pressure triggers bounded diagnosis or lawful re-entry;
12. a supported-surface user scenario binds one exact user, deployed,
    installed, or otherwise runnable Product form, configuration, ordinary
    path, and Product outcome without hidden
    capability or test-only entry;
13. the corresponding end-to-end frame observes the authoritative runnable
    causal path and falsifies equal output obtained through a forbidden path;
14. integration trials vary the material participant interaction dimensions
    and retain omitted higher-order combinations as residuals;
15. every coded module has a module-derived unit lane, and unit trials use
    evidence size and strategy proportional to the internal combinatorial
    complexity of the module-owned law while remaining unable to establish an
    integration, runnable-Product, user, or Product claim;
16. disabling the selected path or forcing a rival path produces the declared
    failure or refusal without mutating the assurance subject undetectably;
17. aggregate green status cannot hide a missing, conflicted, stale-subject, or
    wrong-path testing-frame result;
18. owner-issued runtime truth is acquired through the exact owner surface and
    evaluated with a separately derived oracle, while generic assurance
    mechanics remain authority-neutral;
19. a counterexample returns a causally minimal supported frontier represented
    as one unique locus, a jointly established incomparable set, unresolved
    alternative frontiers, or `indeterminate` evidence;
20. a project-defined configuration can replace the profile without changing
    the selected STDO law or inventing another authority layer;
21. every generic specialist-frame family is instantiated where material,
    evidenced as non-material by capable authority, or retained as an explicit
    residual rather than omitted by artifact or component absence;
22. a representative multi-frame claim refuses or returns non-satisfaction
    when an identity, coordinate, value/evidence, lifecycle, authority, or
    provenance seam is missing, stale, foreign, or non-commuting; and
23. the generic specialist set can be instantiated without importing a
    consumer-specific architecture, runtime object, or renamed local topology
    into the baseline;
24. Reviewer returns evidence-bound severity and technical implications while
    remaining unable to assign priority, block promotion, direct repair, or
    activate another frame;
25. Executive consumes the exact technical triage with the sufficient bounded
    delivery view and current MVP or release mandate, keeps severity, priority, frame
    result, and promotion-boundary effect distinct, and selects only an
    authorized disposition and action; and
26. a finding outside the exact claim boundary remains repricing input rather
    than creating a release block or another review round by severity label.

The claim is limited to the frame revisions, actor envelopes, result branches,
and evidence populations actually evaluated.

---

## Baseline-Specific Project-Basis Additions

An adopting Product starts from the Project Reference-Frame Basis binding owned
by `SPEC_METHOD.md` and projected by
`templates/PROJECT_REFERENCE_FRAME_BASIS_TEMPLATE.md`. This optional profile
adds only the following profile-specific content. It is not a competing basis
definition or adoption authority.

```markdown
# STDO Baseline Adoption Additions

- exact STDO Reference Frame Baseline identity:
- Executive, Worker, and Reviewer declaration or acquisition references:
- role-specific actor capability, authority, and independence bindings:
- Product-selected severity and priority scales, current-boundary cutoff,
  non-waivable hard stops, and Reviewer-to-Executive triage relation:
- Worker result to Frame Method result mapping:
- twelve generic specialist-family declarations, non-material evidence, or
  explicit residuals:
- Product-testing claims, frame topology, material combination populations,
  scenario matrix, oracles, and required and forbidden authoritative paths:
- profile-specific activation refusal, closed-result, conjunction, and return
  relations:
- profile-specific qualification evidence and residuals:
```

---

## Baseline-Specific Activation Additions

Every activation first carries the generic binding defined by
`REFERENCE_FRAME_METHOD.md#minimal-frame-activation-binding`.

For Worker activation, that binding is also the `STDO-UP-020` sufficient
execution intake and adds the exact inherited operation grant, mutation
subject, and write territory where applicable. Selected computational relations,
specialist inputs and qualification duties enter that intake. Where testing is
required, the selected testing frames bind claims, exact subjects, frame
topology, material combination populations, ordinary paths, oracles and
forbidden-path exclusions. For Reviewer activation, it
adds the exact claim, composition boundary, evaluated population, oracle,
ordinary or module path, falsification condition, and
`STDO-UP-007`/`STDO-UP-022` independence and assurance basis, Product-selected
severity scale, and required technical-triage capability. For Executive
activation, it adds the current Product-role map, MVP or release mandate,
evaluation frontier, closed-result and technical-triage ledger, priority and
boundary policy, conjunction rule, and exact disposition grant.

---

## Failure Classification

| Observation | First diagnosis |
|---|---|
| implementation produces a coherent capability that is not the selected Product | Product-frame falsification and Product re-entry |
| a Development Product's structure becomes the authored Product's meaning | Product-role or composition-basis drift |
| an authorized mutable Source Project is treated as one immutable review subject throughout construction | Source Project and candidate-checkpoint lifecycle collapse |
| one actor receives every specialist concern as one global context and repeatedly misses known violations | attention-surface or capability mismatch; refine and independently activate frames |
| every local frame is green but an affected Product edge is unevaluated | missing Product Composition activation |
| a child result directly starts repair, review, publication, or continuation | return-topology and decision-authority violation |
| a compression, summary, generated map, or prior result replaces current source authority | invalid basis or evidence substitution |
| Worker cannot see a material violation visible from another evaluation | missing or misactivated specialist frame, capability mismatch, or oversized frame |
| Reviewer asks assurance code to recreate Product or implementation meaning | Reviewer authority bleed or missing capability/reuse frame |
| a harness derives current owner state from raw events or payloads despite an installed owner projection | rival semantic interpreter and invalid assurance subject |
| a downstream symptom is assigned to one upstream owner without causal-frontier evidence | unsupported counterexample localization; determine whether evidence supports one locus, a joint incomparable set, alternative frontiers, or `indeterminate` |
| passing tests mask malformed fixtures or a false proof relation | test semantics omitted from Reviewer manifold |
| hundreds of green unit tests coexist with a failed Product outcome | unit-frame evidence was flattened into an unevaluated user-acceptance, end-to-end, or composition claim |
| the expected output is reached through an obsolete or bypass path | end-to-end path-conformance falsification despite output equality |
| a UAT scenario uses private APIs, injected state, hidden administrator capability, or a test-only endpoint | invalid user-frame subject or unsupported ordinary path |
| one sunny end-to-end path is reported as combinatorial coverage | undeclared interaction population and residual higher-order combinations |
| pairwise coverage is used for authority, persistence, recovery, migration, or historical multi-boundary failures without justification | insufficient interaction strength or invalid coverage basis |
| successor tests pass while obsolete exports, consumers, fallbacks, or proof scripts remain | technical-debt deletion and forbidden-path exclusion are unproved |
| a negative-path test overwrites the frozen install it is meant to qualify | assurance-subject invalidation and missing mutation isolation |
| review evaluates a moving tree or rebuilt artifact | invalid exact-subject basis under `STDO-UP-007`/`STDO-UP-022` |
| several episodes or stores are flattened into one apparent path | missing coordinate translation or interaction binding |
| Worker starts the next stage after self-review | violation of `STDO-UP-020` decision and continuation authority |
| Reviewer implements the fix while retaining its verdict | violation of `STDO-UP-007` independence and frame authority |
| Reviewer assigns priority, blocks promotion, directs repair, or activates another frame | Reviewer-to-Executive decision-authority bleed |
| Executive treats severity, priority, frame verdict, and release blocking as one value | triage-relation collapse; reapply the Product-owned policy to the exact claim and mandate |
| Executive rewrites semantics to close a local problem | decision outside proxy grant; `STDO-UP-020` re-entry required |
| repeated local repair creates another authority path | incomplete affected cone or missing owner/capability frame |
| long effort resets after local success | coverage, frame altitude, topology, evidence, or capability diagnosis required |

The table routes evaluation. It does not predetermine a verdict.

---

## Anti-Patterns

This profile is misapplied when:

1. Executive, Worker, or Reviewer is treated as a persona without a declared
   evaluation and authority relation;
2. the frames are treated as an organizational hierarchy;
3. Executive is made a universal context, semantic interpreter, or
   implementation controller;
4. Worker sends a candidate directly into an implied Reviewer activation;
5. an activation refusal is relabeled as a Worker result or any Worker result
   variant is selected without its required Reference Frame Method result;
6. refused, incomplete, or re-entry work results have no route to Executive;
7. Worker accepts its own result, infers continuation, or treats its role label
   or broad workspace access as mutation authority;
8. Reviewer relies on Worker narrative instead of acquiring the material live
   subject;
9. Reviewer trusts tests without reviewing their semantics where they can
   change the proof;
10. Reviewer edits or directs repair while retaining independent-review status;
11. changed candidate or basis reuses the predecessor verdict;
12. results from different coordinates are flattened into one relation;
13. a local axioms file is treated as authority without an owning
    Goals/Product/requirement/design decision;
14. this profile restates `STDO-UP-020`, `STDO-UP-007`, or `STDO-UP-022` as
    peer constitutional law;
15. a project-defined configuration silently changes selected STDO law;
16. consumer-specific realization machinery or a renamed architectural
    equivalent is presented as a universal requirement;
17. test labels or runner choice substitute for declaring the exact testing
    frame, subject, claim, population, oracle, path, and falsification condition;
18. unit-test, assertion, snapshot, line, branch, or function count is used as a
    Product-confidence or closure measure;
19. implementation-shaped unit tests are treated as independent design,
    architecture, integration, installed, or user-outcome assurance;
20. interface, persistence, orchestration, authority, configuration, or user
    complexity is mocked away and then counted as unit-test coverage;
21. helper-level tests become the canonical proof surface for a module-owned
    algebra or for a broader Product composition;
22. an expected output is accepted without proving the required authoritative
    path or while a material rival path remains reachable;
23. one end-to-end sunny path substitutes for a declared combinatorial
    population, interaction-strength justification, failure coverage, and
    residual set;
24. UAT gains capabilities, information, setup paths, or interfaces unavailable
    to the declared user;
25. a harness, fixture, proof script, or expected-value builder reconstructs
    owner-issued runtime meaning and treats that reconstruction as the assurance
    subject;
26. a downstream symptom is assigned to one owner when the evidence establishes
    a joint causal frontier, unresolved alternatives, or no bounded frontier, or
    localization is used to authorize wider repair;
27. a mutation, sabotage, fixture, or proof capture changes the exact assurance
    subject without isolation, restoration, and revalidation;
28. aggregate green status hides a missing or conflicting user-acceptance,
    end-to-end, integration, unit, or negative-path frame result;
29. a generic specialist-frame family is treated as a required component,
    actor, service, file, runtime type, stage, or new semantic owner; or
30. a material generic family is omitted because no artifact shares its name,
    or several families are flattened into one broad frame without preserving
    their distinct evaluation and result relations;
31. Reviewer assigns priority, decides promotion blocking, directs repair, or
    starts another activation; or
32. Executive collapses severity, priority, frame result, promotion-boundary
    effect, and disposition into one status value.

---

## Closure

The predicate is “this baseline has been applied to outcome `G` on basis `B`
under the selected engagement configuration”. Bind its required predicates and
joins to the applicable owning conditions below, then use
[Result conjunction](FOUNDATIONS.md#result-conjunction). Evidence reliance uses
[Contract application](TRANSFORMATION_LIBRARY.md#contract-application) with
this outcome, current basis, adopted configuration and actual grants. These
shared decisions are applied to the existing work evidence, not through an
additional closure pass or carrier.

The profile supplies no new execution authority, local constitutional layer,
actor topology, runtime or universal completeness claim. Its selected
configuration and effects remain within the existing owners' grants.

| Obligation group | Deciding conditions for this outcome |
|---|---|
| adopted basis and configuration | [Status And Authority Boundary](#status-and-authority-boundary), [Adopt This Baseline](#adopt-this-baseline), [Engagement Applicability](#engagement-applicability) and [Non-Hierarchical Frame Configuration](#non-hierarchical-frame-configuration) |
| activation, work result, operation grant and currentness | [Derived Worker Frame](#derived-worker-frame), [Work result](#work-result), [Executive Drift Locks](#executive-drift-locks) where coordinated, and [Frame activation](REFERENCE_FRAME_METHOD.md#select-and-activate) |
| required assessment | [Derived Reviewer Frame](#derived-reviewer-frame), [review activation](#5b-candidate-requires-independent-review), [triage projection](#reviewer-result-and-triage-projection) and [Actor Binding And Independence](#actor-binding-and-independence) |
| return, priority, disposition and continuation | [Handoff Projection](#handoff-projection), [Executive Attention](#executive-attention-evaluation-and-action), [Executive disposition](#7-executive-disposes-and-checkpoints) and [promotion constraints](#executive-promotion-constraint-projection), under the selected branch |
| specialist coverage and cross-frame seams | [Derived Generic Specialist Frame Set](#derived-generic-specialist-frame-set) and [Coverage Application](#coverage-application), using Frame Method coverage and composition |
| testing claims and their distinct evidence altitude | [Derived Product Testing Frame Set](#derived-product-testing-frame-set), its four frame declarations and [Testing Evidence Composition](#testing-evidence-composition) |
| interaction populations and useful discrimination | [Combinatorial Coverage And Testing-Value Index](#combinatorial-coverage-and-testing-value-index) |
| required/forbidden paths and exact assurance-subject preservation | [Legitimate-Path And Technical-Debt Erasure](#legitimate-path-and-technical-debt-erasure) |
| owner-issued subject, independent oracle and causal findings | [Assurance Subject Acquisition And Evaluation](#assurance-subject-acquisition-and-evaluation) and [Counterexample Localization](#counterexample-localization) |

[Applicability And Required Results](REFERENCE_FRAME_METHOD.md#applicability-and-required-results)
determines the required set; a listed family alone does not activate it.
[Condition-based closure](TICKET_METHOD.md#condition-based-closure-and-reuse)
requires valid evidence and required judgments/owner rulings with no active
non-closure condition. A returned indeterminate result or a review event does
not close an unresolved obligation. The retained residual boundary cannot
silently waive a mandatory predicate.

A project-defined frame configuration closes against
`REFERENCE_FRAME_METHOD.md`, the selected complete STDO cut, and its cited
existing project authorities. It need not claim conformance to this optional
baseline profile.
