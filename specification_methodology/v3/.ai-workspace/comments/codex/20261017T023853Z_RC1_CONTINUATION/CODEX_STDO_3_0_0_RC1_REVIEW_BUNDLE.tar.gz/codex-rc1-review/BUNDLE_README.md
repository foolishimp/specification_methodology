# Codex RC1 review bundle

This is a frozen review subject, not an immutable RC release or an adoption.
`candidate/` preserves the selected successor package. `dependencies/` carries
only its exact admitted construction-time encoding theory and checker. Existing
license files are included; the checker's declared Product subject carries no
license, and its release has none at axiom_indexer/LICENSE or root LICENSE.
No license is inferred from the neighbouring corpus. These dependencies supply
no candidate acceptance or final v3
encoding/cohort decision. Package inventories record source identities.

Runtime prerequisite: Python 3.13 was exercised for the binding command. The
shipped binding script and checker import only Python standard-library modules;
no Python runtime, native agent host, or environment provisioner is included.
On a machine with that runtime already available, the following local commands
require no network. Environment provisioning was not tested offline. The full
checker/project operation remains task-selected and was not run by packaging.

From the extracted bundle root, using an explicit scratch output directory:

```sh
python3.13 -B candidate/interpretation/bindings.py \
  --theory-root "$PWD/dependencies/encoding-theory" > "$REVIEW_OUTPUT/bindings.json"
python3.13 -B dependencies/axiom-indexer/build_tenants/core/code/ac.py project \
  --program candidate/interpretation/program.json \
  --map candidate/interpretation/map.json \
  --bindings "$REVIEW_OUTPUT/bindings.json" \
  --frame-index "$SELECTED_FRAME_INDEX" --mode materialized \
  --output "$REVIEW_OUTPUT/projection.json"
```

Select the frame index from candidate/interpretation/FRAMES.md for the actual
review task. Outputs stay outside the frozen bundle. Structural projection
does not prove interpretation fidelity, method acceptance or release readiness.
