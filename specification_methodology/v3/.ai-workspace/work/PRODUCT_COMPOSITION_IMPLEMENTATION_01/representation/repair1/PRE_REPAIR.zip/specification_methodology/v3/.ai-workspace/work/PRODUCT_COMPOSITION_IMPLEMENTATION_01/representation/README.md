# Bounded Product composition representation

This is the current Writer's F_P interpretation of **PC-01 through PC-07 only**
in the changed native PRODUCT_DEFINITION source. PLAN and SOURCE_SECTIONS bind
the exact file, section identities, full line ranges and source bytes. AUTHOR_ANSWER
retains the declared concept/obligation/latitude choices; AUTHORING identifies the
actual producer and instruction. Shared laws are referenced by the clauses and
remain outside this bounded representation; it is not a standalone whole-method model.

The existing `ac_generate.model_from_answers` adapter validates exact grounding
and packages those choices. Its generic interpreter/contract/provenance metadata
was rebound to the actual current Writer authorship before public validation;
no CLI actor output or admission evidence was fabricated. The actual finite
interpretation contract and tools are retained. The compiler's supported carrier
calculus basis is 2.5.1 RC2; the represented subject is this unreleased amendment
over 3.0.1. These are different basis roles, not an implicit method downgrade.

The existing public `ac_graph.py validate`, `materialize` and `decode` commands
produced and exactly recovered the model from both node-link and Graphify extraction
carriers. CHECKS records those actual commands and results. Materialization creates
an unaccepted proposal view; no supplied accepted judgment or carrier admission was
invented. Traversals, transformations and judgments are explicitly empty. Source
conditions remain inert statements, not executable policy predicates.

COVERAGE is seven-clause processing coverage, with semantic completeness and
acceptance still unassessed. It does not complete or relabel the older incomplete
3.0.1 whole-method interpretation. No compression optimum, actor benefit, cost gain
or general context-selection claim is made. Upstream Graphify compatibility, if
separately exercised, must name the exact upstream and resulting carrier bytes.
