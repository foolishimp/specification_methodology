# Requirements

Consumes the provider fixture contract as one exact diagnostic input.
The result is confined to observed schema, identity, locator and fragment behavior; no semantic-acceptance claim follows.
