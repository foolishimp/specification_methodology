# Goals

Observe the installed public fleet verifier on this synthetic fixture.
