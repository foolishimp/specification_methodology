# Implementation

Owns the fixture contract containing the literal value ready.
