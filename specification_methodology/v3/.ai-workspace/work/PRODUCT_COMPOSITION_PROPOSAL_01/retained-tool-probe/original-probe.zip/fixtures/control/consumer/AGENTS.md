# Synthetic fixture bootstrap

Select the adjacent stdo_consumer.json and its exact installed basis; this file authorizes no real work.
