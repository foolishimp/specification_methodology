# Synthetic fixture bootstrap

Select the adjacent stdo_provider.json and its exact installed basis; this file authorizes no real work.
