# Requirements

Owns the fixture contract containing the literal value ready.
The result is confined to observed schema, identity, locator and fragment behavior; no semantic-acceptance claim follows.
