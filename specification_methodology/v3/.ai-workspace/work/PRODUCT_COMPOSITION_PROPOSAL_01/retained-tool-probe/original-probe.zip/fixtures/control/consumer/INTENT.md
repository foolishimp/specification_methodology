# Intent

Consumes the provider fixture contract as one exact diagnostic input.
