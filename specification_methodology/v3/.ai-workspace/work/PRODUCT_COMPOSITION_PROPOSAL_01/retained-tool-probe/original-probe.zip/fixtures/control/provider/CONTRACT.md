# Provider contract

The provider exposes the literal fixture value `ready`. Its identity and meaning are owned by provider PRODUCT.md.
