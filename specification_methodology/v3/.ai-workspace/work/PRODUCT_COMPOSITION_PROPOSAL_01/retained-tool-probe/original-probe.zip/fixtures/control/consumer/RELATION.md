# Consumer relation

## Directed fixture dependency

Identity: urn:stdo:relation:composition-probe-consumes. Kind: fixture-contract-consumption. Source: urn:stdo:product-definition:composition-probe-consumer. Target: urn:stdo:product-definition:composition-probe-provider. Owner and admitting authority: consumer PRODUCT.md#fixture-authority. The source consumes only provider CONTRACT.md as a diagnostic input.

This is one directed relation between mutable synthetic definitions, not an immutable Product release binding. It grants no target write, execution, acceptance or release authority. The relation is valid only during this fixed diagnostic snapshot. A missing or mismatched target, unresolved relation or contract refuses use; any change to a bound definition, relation, contract or exact method basis invalidates the result. Evidence is the raw command and referential audit captured outside both Products.
