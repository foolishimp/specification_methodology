# Design

Local textual realization of the bounded synthetic Product.
