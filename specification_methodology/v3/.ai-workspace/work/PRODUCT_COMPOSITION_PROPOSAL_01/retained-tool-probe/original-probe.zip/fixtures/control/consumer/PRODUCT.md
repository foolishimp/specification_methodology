# Product

Consumes the provider fixture contract as one exact diagnostic input.

## Fixture authority

This synthetic Product and its local frame basis exist only for the bounded verifier diagnostic. The fixture constructor owns these synthetic declarations under the diagnostic grant. No real Product acceptance or release is represented. Each Product retains its own meaning. Only the consumer has the declared directed dependency.
