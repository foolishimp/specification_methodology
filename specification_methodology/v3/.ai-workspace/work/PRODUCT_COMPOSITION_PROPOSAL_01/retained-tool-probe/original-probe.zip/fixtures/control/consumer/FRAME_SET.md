# Fixture frame basis

Basis: stdo://releases/v3.0.1-rc.1/standards/REFERENCE_FRAME.md. Admitting authority: PRODUCT.md#fixture-authority. Scope: urn:stdo:product-definition:composition-probe-consumer.

One diagnostic Worker inspects the selected definition, the exact installed schema and release, local bound files, and the consumer relation and provider contract when the declared edge applies. It may run read-only fleet verify and record results only in this temporary probe root. It has no authority over a real Product, release, or acceptance. No LLM actor is launched.

The consumer and provider remain distinct Product roles. Their one directed edge is owned by the consumer RELATION.md and consumes provider CONTRACT.md. No provider implementation or mutation authority is imported. Outputs retain status, evidence and limits; schema and referential observations do not imply semantic acceptance. The diagnostic stops on a missing selected basis or an unexpected control failure. A change to the exact definitions, references, schema, CLI or install invalidates reuse.
