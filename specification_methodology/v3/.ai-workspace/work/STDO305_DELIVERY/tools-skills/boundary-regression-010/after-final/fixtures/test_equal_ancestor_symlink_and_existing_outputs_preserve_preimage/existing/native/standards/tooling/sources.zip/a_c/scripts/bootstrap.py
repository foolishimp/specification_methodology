from pathlib import Path
import sys
Path('/Users/jim/src/apps/specification_methodology/specification_methodology/v3/.ai-workspace/work/STDO305_DELIVERY/tools-skills/boundary-regression-010/after-final/fixtures/test_equal_ancestor_symlink_and_existing_outputs_preserve_preimage/existing/bootstrap-invoked.marker').write_text("selected fixture bootstrap invoked\n")
print("marker-only fixture; no Lean or downloads")
raise SystemExit(23)
