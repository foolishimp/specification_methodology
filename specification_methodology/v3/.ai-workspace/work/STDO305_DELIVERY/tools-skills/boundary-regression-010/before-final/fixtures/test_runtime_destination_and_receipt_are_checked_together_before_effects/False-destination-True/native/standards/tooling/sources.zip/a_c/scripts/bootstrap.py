from pathlib import Path
import sys
Path('/Users/jim/src/apps/specification_methodology/specification_methodology/v3/.ai-workspace/work/STDO305_DELIVERY/tools-skills/boundary-regression-010/before-final/fixtures/test_runtime_destination_and_receipt_are_checked_together_before_effects/False-destination-True/bootstrap-invoked.marker').write_text("selected fixture bootstrap invoked\n")
print("marker-only fixture; no Lean or downloads")
raise SystemExit(23)
