# Goals

[T-019](../.ai-workspace/tickets/active/T-019-code-representation.md) is the current
bounded delivery: the public code-overlay workflow, shared offline reader and
both Skills consumer routes are implemented and independently reviewed. The common
[CR-01–CR-07 requirements](requirements/code-realization.md) preserve the native
model/carrier and separate structural observations from caller-attributed F_P
trace mappings. The [delivery handoff](../.ai-workspace/work/T019_CODE_REPRESENTATION/DELIVERY.md)
links the four-file ABIogenesis demonstration and
[closed review](../.ai-workspace/work/T019_CODE_REPRESENTATION/review/INDEPENDENT_REVIEW.md),
with no open actionable S0–S4 finding. Actual source extraction, currentness,
reuse and requirement→code→test-source navigation are evidenced. Semantic and
benefit qualification, fresh Skills-host use and actual browser/WebGL remain
open; no ABIogenesis test result, overlay Lean verdict, owner acceptance or
release is asserted. The starting checkpoint is `c034593eea08`; this delivery
changes no installed method or STDO 3.0.3 distribution/release standing.

[T-018](../.ai-workspace/tickets/active/T-018-static-layered-renderer.md) supplies
one offline reader with a 3D / 2D / Layered middle-panel switch. All renderers
consume one unchanged representation and preserve selection and navigation state.
Implementation, finite checks and independent repair review are complete;
browser visual qualification remains open. The current repairs are checkpointed
on `main` with a [closed independent repair review](../../specification_methodology/v3/.ai-workspace/work/STDO303_DELIVERY/review-repairs-001/INDEPENDENT_REVIEW.md).

[T-017](../.ai-workspace/tickets/active/T-017-source-navigation.md) adds source
folder/file navigation to the portable reader under PU-03, with transitions
between source documents and logical traversals. The existing ABIogenesis model
is the unchanged demonstration subject; prior run and review evidence remain frozen.

[T-016](../.ai-workspace/tickets/active/T-016-project-build-entry.md) implements
the first T-015 public workflow slice: a nominated-project CLI consumed by both
Skills tenants. It binds the project's exact definition and source scope, accepts
honestly identified host-session authoring, reuses common representation checks
and produces model/carrier/coverage/reader artifacts. This does not close the
broader composed-project/Worker-delivery qualification in T-015. Its
[delivery record](../.ai-workspace/work/T016_PROJECT_BUILD/DELIVERY.md) links the
reviewed implementation and separate native consumer evidence.

The next Product increment is
[T-015](../.ai-workspace/tickets/active/T-015-user-project-product.md): make the
existing representation, documentation, verification and actor-support
capabilities usable on a user's own STDO project. The common
[PU-01–09 requirements](requirements/project-use.md) and
[ordered delivery plan](../.ai-workspace/work/T015_USER_PROJECT_PRODUCT/PLAN.md)
are recorded. The integrated user workflow and installed qualification remain
open. First demonstrate one non-STDO leaf through public interfaces, then its
composition with an independently owned provider. Existing component evidence
below retains its original scope.

The [T-014 explorer](../applications/stdo-constraint-explorer/README.md) is locally
implemented and independently reviewed. STDO 3.0.3 documentation integration is
a separately selected distribution of that exact artifact; it does not change
the represented historical source or complete T-015.

The completed bounded practical-gate increment is
[T-013](../.ai-workspace/tickets/active/T-013-practical-formal-gate.md), a
`goal_reprice` and `design_reframe` under unchanged FR-001–FR-014. Cold verification
of the exact 1,987-record/1,021-external subject now includes the actual 29-record
Worker view under the current repaired generator. Fresh proof, kernel replay and
runtime correspondence succeed; actual dispatch and supervisor checks reuse the
exact current proof through its selected origin. Both allowed native F_P Worker
calls are complete with exact received inputs and authenticated returns.
Independent quality review found an S2 numeric-fidelity defect in the ungated
helper and an S3 exponent-error defect in the gated helper. Both are retained,
uncorrected evaluation observations; neither is an adopted Product feature.
No further actor call or output repair is selected.

The [operational review](../.ai-workspace/work/T013_PRACTICAL_FORMAL_GATE/review/matched-operation-001/REVIEW.md)
finds no new actionable defect. Discriminators 1, 2, 4 and 5 are discharged within
their stated boundaries; 3 has measured path/bounds evidence with overall economics
open; 6 completes the bounded experiment without establishing positive benefit.
The [final package/transport review](../.ai-workspace/work/T013_PRACTICAL_FORMAL_GATE/review/package-final-002/REVIEW.md)
finds no actionable defect. Bounded T013 delivery and its experiment are complete:
exact transport preserves all 24 oversized proof files, and the local source
archive passes an installed full-view cold check. Fresh-host/cross-platform
qualification remains open. The [delivery handoff](../.ai-workspace/work/T013_PRACTICAL_FORMAL_GATE/DELIVERY.md)
binds usable entry points, current versus historical identities, scoped costs and
remaining decisions. Full data correspondence, current authority and actual
received bytes remain independent obligations. The
[execution contract](../.ai-workspace/tickets/active/T-013-practical-formal-gate.md#ordered-execution)
binds the sequence and retained limits. The
[reviewed-increment checkpoint](../.ai-workspace/work/T013_PRACTICAL_FORMAL_GATE/checkpoint/reviewed-increment-002/RETURN.md)
preserves the earlier source and closed evidence before actual runtime trials.
The selected compiler option remains `-M4096`, with 90 seconds per checking
process and 600 seconds per public invocation. The reaped-child high-water RSS
field reached 14.61 GB in the current full-view check; the compiler option is not a
physical-memory cap. The pair establishes neither causal quality benefit nor
lower total cost; underlying Worker model identity and monetary totals were not reported.
Owner acceptance, public release, method adoption and wider calculus claims
remain unselected.

The delivered reusable-gate increment is
[T-012](../.ai-workspace/tickets/active/T-012-reusable-formal-gate.md), under
[FR-008–FR-014](requirements/formalisation.md#reusable-formal-verification-gate).
All five ordered increments are delivered with bounded independent qualification:
checked adapters for unseen supported subjects, exact model/carrier and supplied
projection verification, portable current-proof evidence, and optional required
gating through ordinary generation and actual Worker preflight/dispatch/delivery.
The [final review](../.ai-workspace/work/T012_FORMAL_GATE/review/final-assessment-001/REVIEW.md)
supports the declared fragment, resolves all three findings and leaves no blocking
finding. The [handoff](../.ai-workspace/work/T012_FORMAL_GATE/DELIVERY.md) binds usable
commands, exact source/review identities, costs and preserved history. The actual
1,987-record case was incomplete at that predecessor cut; T-013 now supplies the
separately reviewed cold-scale result. No efficiency gain is established. The installed builder,
existing authority owners and historical T-011 evidence remain unchanged.
This predecessor is checkpointed and pushed on `main`; its historical records
retain the standing observed at their closure. Semantic/owner acceptance,
adoption and release remain unselected.

The completed formalisation increment is
[T-011](../.ai-workspace/tickets/active/T-011-lean-formalisation.md): an independent
Lean/Mathlib tenant implementing the selected
[FR-001–FR-007](requirements/formalisation.md) fragment. Generic checked proofs
establish exact declared dependency closure, retained-record projection and
insufficient-budget refusal. The exact 32-record STDO 3.0.2 composition subject
and 14-record all-family toy supply 46 concrete selections. Independent final
review is satisfied with no findings or required repairs; its public-path run
checks 46 actual projections, 46 underbudget refusals and 204 deciding theorem
reports. The [delivery handoff](../.ai-workspace/work/T011_LEAN_FORMALISATION/DELIVERY.md)
binds runnable commands, frozen source, review evidence and retained trust
boundaries. The builder remains v2.5.1-rc.2. The preserved implementation is
checkpointed on `main`; F_P fidelity, owner acceptance and release are not issued
by these checks.

The selected composition increment implements
[FC-01–FC-07](requirements/fd-composition.md) in the existing Graphify support
tenant. It adds optional source-bound actor/edge information declarations to
ordinary mediated acquisition, Context, dispatch and return paths. The
[design](../build_tenants/graphify/design/fd-composition.md) and
[execution record](../.ai-workspace/work/PRODUCT_COMPOSITION_01/README.md)
bound its supported fragment and evidence. Construction does not reopen the
published methodology or establish semantic acceptance, host isolation or
complete Product qualification.

The current implementation increment is
[T-008](../.ai-workspace/tickets/active/T-008-fd-tenant-implementation.md#current-provisional-implementation):
the existing Graphify tenant now contains the provisional public F_D support
implementation for F_P Executives, Workers and Reviewers. Root selected its exact
current realization after bounded implementation, independent code review and
technical integration. The [handoff](../.ai-workspace/qualification/t008/handoff-001/README.md)
binds the current sources, fresh versus carried checks and explicit gaps.
T-008 remains active for partial actual-actor/variant qualification; the failed
and partial live trials remain evidence. FDV-003 benefit is Deferred/unqualified.
There is no Product acceptance, installed/RC/release or full-calculus claim.

Jim's work-scoped selection remains exact Claude RC9 source
`c2cfa9b908d1722ae3f26c32fa4ece691083bdc3` and its Executive/software-design
profiles. The [operative tenant HOW](../build_tenants/graphify/design/fd-support.md)
and [exact RC9 profile](../build_tenants/graphify/design/fd-method-claude-rc9.json)
leave the installed v2.5.1-rc.2 builder and empty composition unchanged. Executive,
Writer/Worker, independent assessment and owner disposition retain their roles.

The completed specification increment is
[T-007](../.ai-workspace/tickets/active/T-007-executive-lifecycle-tooling.md):
it authored the common deterministic-support Product requirements and their
[historical source-owner derivation](requirements/fd-source-owner-map.md).
Design, realization and qualification were pending (Deferred) at that exact
specification-only cut. T-008 supplies the later operative work and progress;
this chronology does not rewrite the T-007 instruction or its historical result.
Existing source-to-model authoring and frozen comparison studies are unchanged.

The completed comparison-preparation increment is
[T-006](../.ai-workspace/tickets/active/T-006-rc9-rebuild-comparison.md):
[fresh Codex/Claude RC9 representations](../dogfood/stdo-v3-generation-rc9/README.md)
use the checkpointed implementation and settings, preserving the entire older
study at `efae9c74`. The [eight-model index](../dogfood/stdo-v3-generation-rc9/COMPARISON.md)
binds older/newer source cuts, both Graphify/direct paths and exact artifact
identities. All new input chunks and carriers pass mechanical verification.
Their semantic evaluation and the owner's planned overall-performance tests
have not been performed. No acceptance or release claim is added.

The completed source-creation increment is
[T-005](../.ai-workspace/tickets/active/T-005-source-first-graphify-generation.md):
the [Graphify/F_P workflow and four new representations](../dogfood/stdo-v3-generation/README.md)
use frozen Codex RC5 and Claude RC8 owner corpora, excluding existing candidate
a_c programs and reviews from authoring input. Direct and Graphify paths both
preserve all 24 sampled distinctions per candidate in independent assessments.
The [review](../dogfood/stdo-v3-generation/REVIEW.md) records all construction and
repair work, with no general cost-saving or compression claim. The previous
increment below tested model consumption. Source custody, bounded fidelity and
resource evidence remain separate from acceptance and release.

The current usefulness increment is
[T-004](../.ai-workspace/tickets/active/T-004-direct-llm-versus-graphify.md):
the [completed direct/Graphify dogfood evaluation](../dogfood/stdo-v3-i5-evaluation/README.md).
Paired native baselines, eight availability runs and four prescribed-use
probes provide source-grounded quality, acquisition, usage and timing evidence.
The actual-use probes preserve the tested meaning with both approaches;
quality improvement and lower total cost were not demonstrated. Broader
F-USEFULNESS, correction/acceptance cost and owner disposition remain open.

The current consumer increment is
[T-003](../.ai-workspace/tickets/active/T-003-v3-i5-two-graphify-representations.md):
separate [Graphify versions of both completed V3 candidates](../dogfood/stdo-v3-i5/README.md).
Their frozen input custody, exact program recovery, all 737 selector closures,
actual pinned-upstream trials, readable record views and local search/inspection/
selection paths are verified. The independent v3 reviews and each candidate's
authored coverage limits remain separate from this transport result.

The current candidate provides an independently usable Graphify build tenant
of `a_c`, with exact model identity, preserved typed content, inspection,
discovery, declared governing acquisition and explicit unsupported-operation
refusals. [T-001](../.ai-workspace/tickets/active/T-001-graphify-realization.md)
records the owner instruction, completed implementation and local verification.

The deciding evidence is a usable encode/decode and acquisition path, adversarial
preservation checks and a trial against exact upstream Graphify code. Passing
those checks establishes their declared mechanical properties. Semantic fidelity,
full-calculus conformance, practical cost reduction, Product acceptance and
release require their own evidence and decisions.

The [implementation record](../.ai-workspace/comments/codex/20261015_AC_GRAPHIFY_IMPLEMENTATION.md)
retains the initial nonauthor review, supported repairs, 41 passing unit tests,
strict typing and actual pinned-upstream boundary evidence for that frozen
candidate. The generic candidate is available for owner disposition.

The completed consumer trial is
[T-002](../.ai-workspace/tickets/active/T-002-v3-i3-representation.md): transport
the completed Codex v3 iteration-3 authored interpretation at exact
checkpoint `c29b2be37f9a12e050478be97793927d99c01781` into a separate proposed
Graphify representation. The candidate and its independent review remain
untouched. Input custody, acquisition-role preservation, all 725 selector
closures, nonauthor review and actual upstream Graphify use pass. The current
codec passes 47 tests; the corpus binding passes 18. Runnable commands,
artifacts and exact evidence are in the
[representation](../dogfood/stdo-v3-i3-c29b2be/README.md). Original interpretation
fidelity, semantic acceptance and accepted-result efficiency remain open.
