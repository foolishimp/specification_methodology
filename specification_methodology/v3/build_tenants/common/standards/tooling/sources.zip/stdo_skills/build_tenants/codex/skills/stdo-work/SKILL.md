---
name: stdo-work
description: Apply a selected STDO method to governed software work, or build an a_c representation of a user's nominated project and trace requirements to selected code and tests. Use for project representation builds, tasks in an STDO workspace or explicit STDO setup, including changes, review, recovery and release preparation; do not impose STDO on unrelated requests.
---

# STDO work

Help the user complete the requested work under the selected Product and exact method. This package targets STDO v3.0.1-rc.1; its manifest and source routes are in [basis](references/basis.md). It supplies instructions, not authority.

For a request to build or resume an a_c representation of a nominated project,
follow [representation](references/representation.md). Execute its complete
prepare → task → author → submit → build loop and return the actual artifacts.
The current session authors each supplied chunk; preparing instructions alone
does not complete the request. To extend an existing representation into selected
code/tests, take the [code-overlay branch](references/representation.md#add-code-and-test-traces)
instead. Both branches treat the target's method as subject data, with no
lifecycle admission under another method. For governed changes and lifecycle
operations, use the following workflow.

1. Identify the outcome and changed owner: requirement, design, implementation, assessment or release. Select exactly one applicable Product Definition, or an explicitly authorized cross-Product relation. Read the applicable local bootstrap and deciding sources. If an activated Context already supplies the exact binding, use it and acquire only its missing material sources.
2. Verify the pinned installation and operation compatibility through [basis](references/basis.md) and [tools](references/tools.md). Preserve sufficient existing authorization. Ask only for a material missing decision, not repeated consent for already granted work.
   For cross-Product work or a required composition-controlled view, follow
   [composition](references/composition.md) at acquisition, child handoff and recovery.
   It resolves actual edges, inspects the trusted a_c binding and preserves per-route
   information eligibility; a graph path is not a grant.
3. Choose the smallest sufficient path. For an authorized one-file correction with adequate requirement/design, enter the bound direct Writer path: acquire current preimage, make only that effect through its declared tool, perform focused proof and return to its consumer. Do not require a new ticket, Executive or independent reviewer solely because work exists.
4. Use [delegation](references/delegation.md) when a material context, capability, ownership or required independence boundary calls for it. An Executive coordinates without mutating; a separately granted Worker/Writer implements. Do not launch actors unless the current grant permits them.
5. Make the requested change and inspect actual responses and postimages. Read [recovery](references/recovery.md) on continuation, interruption, refusal or stale evidence. An unsupported required tool withholds the dependent claim. An uncertain effect must be reconciled before repeating it.
6. Return the exact candidate, source/basis identities, actual proof, failures, remaining obligations and invalidators. Keep availability, author assessment, independent review and owner acceptance separate. For release/install work use [release and installation](references/release-install.md); for behavior qualification use [qualification](references/qualification.md).

Normal invocation: ask for the relevant task in a governed workspace. Explicit invocation: `$stdo-work Correct the named file under the existing grant`. The host may discover the description automatically; acquisition and success must be observed separately. If explicit invocation works after failed automatic discovery, retain both attempts.

Read only the reference needed for the current branch. Common requirements and method owners remain external authority; [source routes](source-routes.json) identify this package's construction basis. A target workspace supplies its own Product Definition, sources and grants.
